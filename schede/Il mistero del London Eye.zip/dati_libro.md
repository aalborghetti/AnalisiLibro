[[FILE: dati_libro.md]]
# Dati del Libro
- **Titolo:** Il mistero del London Eye (*The London Eye Mystery*)
- **Autore:** Siobhan Dowd
- **Anno di pubblicazione:** 2007 (prima edizione italiana: 2011)
- **Editore:** Uovonero
- **Genere:** Romanzo giallo / d'indagine per ragazzi
- **Ambientazione:** Londra (Inghilterra), contemporanea (maggio)
- **Target scolastico:** Scuola secondaria di primo grado (11-13 anni)
- **Unità didattiche:** 12

## Piano delle Unità Didattiche
- **Blocco 1** — Capitoli: Capitoli 1–3 · Nucleo tematico: Neurodiversità, percezione della realtà e rottura della routine quotidiana · Attività speciale: Mappa Topografica o Tattica
- **Blocco 2** — Capitoli: Capitoli 4–5 · Nucleo tematico: Incontro con l'altro, identità multiculturale e condivisione delle fragilità · Attività speciale: Processo in Aula / Dibattito (Debate)
- **Blocco 3** — Capitoli: Capitoli 6–8 · Nucleo tematico: L'enigma della sparizione, violazione delle regole e il dilemma della menzogna · Attività speciale: Dossier Investigativo / Caccia all'Indizio
- **Blocco 4** — Capitoli: Capitoli 9–11 · Nucleo tematico: Il peso del senso di colpa, l'angoscia familiare e l'interrogatorio con le autorità · Attività speciale: Redazione Giornalistica d'Epoca
- **Blocco 5** — Capitoli: Capitoli 12–14 · Nucleo tematico: Il pensiero laterale, il metodo scientifico e la formulazione delle ipotesi · Attività speciale: Taccuino Naturalistico / Storico / Tecnico
- **Blocco 6** — Capitoli: Capitoli 15–17 · Nucleo tematico: L'attenzione ai dettagli nascosti, la cooperazione tra fratelli e l'analisi visiva · Attività speciale: Codice Segreto, Stemma o Simbologia
- **Blocco 7** — Capitoli: Capitoli 18–21 · Nucleo tematico: Il superamento dei pregiudizi, l'esplorazione urbana e la tenacia investigativa · Attività speciale: Mappa Topografica o Tattica
- **Blocco 8** — Capitoli: Capitoli 22–25 · Nucleo tematico: L'impatto dei mass media sul dolore privato e la gestione dell'ansia da separazione · Attività speciale: Processo in Aula / Dibattito (Debate)
- **Blocco 9** — Capitoli: Capitoli 26–29 · Nucleo tematico: Il coraggio dell'azione sul campo, la sfida ai limiti sensoriali e il confronto col sospettato · Attività speciale: Dossier Investigativo / Caccia all'Indizio
- **Blocco 10** — Capitoli: Capitoli 30–33 · Nucleo tematico: La gestione del fallimento apparente, l'ascolto interiore e la folgorazione razionale · Attività speciale: Redazione Giornalistica d'Epoca
- **Blocco 11** — Capitoli: Capitoli 34–37 · Nucleo tematico: Lo svelamento della verità, la vulnerabilità dei pari e i rischi della fuga · Attività speciale: Taccuino Naturalistico / Storico / Tecnico
- **Blocco 12** — Capitoli: Capitoli 38–41 · Nucleo tematico: La solidarietà familiare nella corsa contro il tempo e il riconoscimento del valore della neurodiversità · Attività speciale: Codice Segreto, Stemma o Simbologia

[[FINE]]
