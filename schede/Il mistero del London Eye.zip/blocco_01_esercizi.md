[[FILE: blocco_01_esercizi.md]]
# SCHEDA DIDATTICA DI LETTURA E COMPRENSIONE
## *Il mistero del London Eye* di Siobhan Dowd
### Unità Didattica 1 (Blocco 1): *Una gigantesca ruota di bicicletta nel cielo* – *L'uragano si avvicina*

---

> ### 🌊 Un cervello con un sistema operativo speciale
> «La gente dice spesso che sul mio cervello gira un sistema operativo diverso da quello delle altre persone. Non è peggiore, è solo differente.»  
> Benvenuto nel mondo di Ted Spark, un ragazzo che sa guardare la realtà con una precisione straordinaria: dove gli altri vedono solo confusione, lui scorge schemi, numeri e correnti atmosferiche. In questi primi capitoli farai la sua conoscenza, scoprirai il fascino imponente della ruota panoramica del London Eye e assisterai all'annuncio di una vera e propria tempesta familiare: la zia Gloria e il cugino Salim, pronti a sconvolgere ogni sua rassicurante routine quotidiana.

---

## 1. Comprensione del Testo

*Rispondi alle domande sul tuo quaderno in modo completo, motivando con riferimenti precisi al testo.*

1. **Il sistema operativo di Ted:** Nel descrivere se stesso, Ted afferma che il suo cervello funziona con un «sistema operativo diverso» da quello degli altri. In che modo questa sua caratteristica influenza la comprensione del linguaggio quotidiano (ad esempio quando il padre usa modi di dire come «lasciare una scia di devastazione») e il suo modo di osservare la città dall'alto?
2. **Lo sguardo dall'alto sul Tamigi:** Durante il giro sul London Eye, Ted nota che dall'alto il fiume Tamigi si rivela pieno di curve e anse, mentre quando si cammina a terra tutti sono convinti che sia rettilineo. Quale significato assume questa osservazione rispetto alla capacità di Ted di cogliere la realtà oltre le apparenze comuni?
3. **La tensione mattutina e il segreto di Kat:** Durante la colazione descritta nel Capitolo 2, per quale motivo Kat cerca freneticamente di sottrarre la posta a Ted e nascondere la busta della scuola? Che cosa rivela questo episodio sul rapporto tra i due fratelli e sul loro diverso modo di porsi di fronte alle regole e all'autorità dei genitori?
4. **Le due versioni della lettera:** Nel Capitolo 3, Ted e Kat ricordano e interpretano in modo completamente diverso il testo della lettera inviata da zia Gloria. Quali differenze emergono tra il ricordo letterale e pratico di Ted e la versione emotiva e drammatica ricostruita da Kat?
5. **L'ansia per la rottura della routine:** Alla notizia che il cugino Salim dormirà nella sua stanza su un materassino gonfiabile, Ted avverte un forte malessere fisico e la sua mano inizia a sventolare. Quali abitudini intime e rassicuranti teme vengano compromesse dall'intrusione di un ragazzo sconosciuto nel suo spazio vitale?

---

## 2. Vero o Falso? (Attenzione ai dettagli)

*Indica nella tabella se l'affermazione è Vera (V) o Falsa (F). Correggi e motiva sul tuo quaderno le affermazioni false.*

| Affermazione | V | F |
| :--- | :---: | :---: |
| 1. Quando osserva Londra dall'alto del London Eye, Ted concorda con Kat sul fatto che la città assomigli a un paese di giocattoli e le auto a palline di un abaco. | | |
| 2. Il padre di Ted viene soprannominato scherzosamente "demolitore" perché è sbadato in casa, ma in realtà svolge un normale lavoro d'ufficio in banca. | | |
| 3. Ted intuisce che Kat ha marinato la scuola (è rimasta "AWOL") riconoscendo la busta con lo stemma scolastico che la sorella tenta di nascondere. | | |
| 4. Zia Gloria e suo figlio Salim hanno deciso di trasferirsi a New York poiché alla donna è stato offerto un incarico prestigioso come curatrice d'arte. | | |
| 5. All'idea che Salim dorma nella sua camera, Ted è subito entusiasta perché finalmente avrà qualcuno con cui commentare il bollettino meteorologico notturno. | | |

---

## 3. Analisi dei Personaggi e Riflessione

*Rifletti sulle scelte e sulle emozioni dei protagonisti e rispondi sul quaderno.*

1. **La barriera del senso letterale:** Ted prende alla lettera espressioni figurate come «essere un tipo sopra le righe», «lasciare una scia di devastazione» o la battuta di Salim di «poter dormire sull'asse da stiro». Quando la famiglia ride di queste sue interpretazioni letterali, Ted prova un doloroso disagio fisico. Da dove nasce questa difficoltà comunicativa e in quale equilibrio, tra affetto spontaneo e fatica quotidiana, si muovono i familiari nei suoi confronti?
2. **Kat, tra ribellione e intuito emotivo:** Pur mostrandosi spesso scontrosa, sprezzante e insofferente verso Ted e i genitori, Kat dimostra una spiccata intelligenza emotiva nel comprendere le motivazioni adulte della zia Gloria e nel difendere la propria indipendenza. Quali contraddizioni tipiche dell'adolescenza emergono nei suoi comportamenti durante le prime scene familiari?

---

## 4. Officina di Scrittura Creativa ed Empatia

*Mettiti nei panni di uno dei protagonisti e svolgi l'attività sul tuo quaderno.*

Immagina di essere **Ted** la sera prima dell'arrivo di zia Gloria e Salim. Ti trovi a letto nella tua stanza, con la luce spenta, e fissi il pavimento dove l'indomani verrà posizionato il materassino per tuo cugino.  
Scrivi una pagina del tuo diario personale:
- Descrivi l'evento imminente attraverso la lente della tua passione per la meteorologia, paragonando l'arrivo dei parenti a una perturbazione o a un fronte ciclonico che incombe sulla casa;
- Racconta l'ansia provocata dalla violazione della tua intimità (sentire il respiro di uno sconosciuto al buio, cambiarsi i vestiti in sua presenza, il timore di non poter ascoltare il bollettino dei naviganti alla radio);
- Stabilisci tre "regole di sicurezza logica" che ti impegni a seguire per mantenere la calma e impedire che il tuo sistema operativo vada in sovraccarico sensoriale.

---

## 5. Laboratorio Lessicale e Modi di Dire

*Associa ciascun vocabolo o espressione d'autore al suo significato nel contesto del racconto (indica sul quaderno la combinazione corretta numero-lettera).*

| Termine o Modo di Dire | Abbinamento | Significato Contestuale |
| :--- | :---: | :---: |
| 1. **Struttura a sbalzo** | | A. Metafora informatica che indica il peculiare modello cognitivo con cui un individuo elabora le informazioni e interpreta il mondo circostante. |
| 2. **Sistema operativo** | | B. Sigla di origine militare (Absent Without Leave) usata per indicare chi si allontana senza permesso, equivalente a marinare la scuola. |
| 3. **Scia di devastazione** | | C. Opera ingegneristica o architettonica ancorata a un solo estremo e sospesa nel vuoto senza pilastri verticali di sostegno sottostanti. |
| 4. **AWOL** | | D. Bollettino meteorologico radiofonico con dati su venti e pressione marina, che fornisce sicurezza e scandisce ritualmente il tempo. |
| 5. **Bollettino dei naviganti** | | E. Espressione metaforica che indica lo scompiglio emotivo e il caos relazionale provocati dal passaggio di una persona travolgente e impulsiva. |

---

## 6. Attività Speciale "Fuori dagli Schemi"

**Mappa Topografica: La casa di Ted e l'avvicinamento dell'Uragano Gloria**  
Nei primi capitoli l'autore ci introduce negli spazi quotidiani di Ted, un ambiente regolato da precise coordinate fisiche e mentali che l'imminente arrivo dei parenti minaccia di sconvolgere.  
Sul tuo quaderno, realizza una pianta topografica e tattica della casa di Ted e dello spazio circostante:
- Disegna la pianta del piano superiore e della zona giorno (la cucina della colazione col tavolo della posta, la stanza di Ted con l'ingombro del materassino gonfiabile per Salim, la stanza di Kat destinata a zia Gloria e il divano del soggiorno);
- Evidenzia graficamente con colori o tratteggi differenti le **zone di sicurezza e routine** (la postazione radio di Ted, il tragitto verso scuola attraverso il parco con lo stagno) e le **zone di perturbazione / intrusione** (lo spazio del materassino accanto al letto di Ted, l'ingresso della casa);
- Inserisci una **rosa dei venti o banderuola meteo** orientata verso il quadrante da cui Ted immagina arrivare la tempesta emotiva della zia;
- Crea una **legenda con almeno 4 simboli tattici** (es. la radio meteorologica, la fessura della posta, il confine letto-materassino, la sagoma del Casermone Barrington Heights sullo sfondo).

[SPAZIO PER IL TUO DISEGNO / RILIEVO GRAFICO]

---

### GUIDA E RIASSUNTO PER IL DOCENTE

#### Riassunto sintetico dei capitoli
I primi tre capitoli impostano la voce narrante, le coordinate psicologiche del protagonista e l'incidente scatenante che precede l'azione vera e propria:
- **Capitolo 1 (*Una gigantesca ruota di bicicletta nel cielo*):** Ted Spark introduce la sua grande passione per il London Eye, descrivendone con esattezza scientifica la struttura a sbalzo, le forze gravitazionali e il moto orbitale delle capsule. Anticipa l'evento traumatico centrale attraverso un prolessi drammatica: lunedì 24 maggio, alle 11:32, il cugino Salim sale da solo su una capsula grazie a un biglietto regalato da uno sconosciuto; alle 12:02, allo sbarco dei passeggeri, Salim è svanito nel nulla. Ted introduce la metafora fondamentale della propria neurodivergenza: possiede un «sistema operativo diverso», che gli consentirà di decifrare l'enigma.
- **Capitolo 2 (*La notizia dell'uragano*):** Descrizione della vita domestica in una mattina qualunque a South London. Emergono i caratteri dei familiari: la madre Faith, il padre (operaio specializzato in demolizioni, al momento impegnato sul cantiere del Casermone Barrington Heights) e la sorella Kat, adolescente ribelle che ascolta musica a tutto volume e cerca di occultare una lettera della scuola che denuncia la sua assenza ingiustificata (definita da Ted con la sigla militare AWOL). L'arrivo di una lettera della zia Gloria porta scompiglio: il padre la ribattezza "Uragano Gloria" perché lascia dietro di sé una scia di devastazione emotiva. Ted si interroga letteralmente su tali espressioni mentre attraversa il parco per andare a scuola.
- **Capitolo 3 (*L'uragano si avvicina*):** La sera la madre legge ad alta voce la lettera di zia Gloria: reduce dalla separazione dal padre di Salim e da un periodo caotico, la donna ha ottenuto un lavoro come curatrice d'arte a New York e chiede ospitalità per due notti prima del volo transoceanico. Emerge il contrasto tra la memoria letterale di Ted (che ricorda la battuta iperbolica di Salim sul dormire sull'asse da stiro, prendendola sul serio e suscitando le risate dei parenti) e quella sfumata ed emotiva di Kat. La redistribuzione logistica delle stanze innesca il panico sensoriale di Ted: dovrà condividere la propria camera con il cugino, rinunciando alla privacy e al rito notturno dell'ascolto del bollettino meteo.

#### Soluzioni ed elementi chiave di correzione
- **1. Comprensione del Testo:**
  1. *Il sistema operativo di Ted:* Ted elabora i dati in modo iper-razionale e privo di filtri sociali o metaforici. Prende i modi di dire alla lettera (chiedendosi se la zia sia fisicamente goffa o malvagia) e rifiuta le analogie poetiche (rifiuta l'idea di Londra come città-giocattolo, vedendo le cose esattamente per ciò che sono).
  2. *Lo sguardo dall'alto sul Tamigi:* L'osservazione sottolinea che la percezione limitata da terra inganna la vista, mentre solo una prospettiva rialzata e scientifica restituisce la reale complessità e le curvature del fiume. È una metafora del metodo investigativo di Ted, che non si ferma all'apparenza lineare degli eventi.
  3. *La tensione mattutina e il segreto di Kat:* Kat vuole sottrarre la notifica scolastica per evitare la punizione dei genitori. L'episodio delinea la contrapposizione tra Kat (che sfida le regole, mente per convenienza ed è guidata da impulsi sociali) e Ted (che rispetta rigorosamente le norme e dichiara la verità oggettiva senza calcoli opportunistici).
  4. *Le due versioni della lettera:* Ted memorizza informazioni anagrafiche, logistiche e quantificabili, soffermandosi sulla menzione dell'asse da stiro che reputa assurda sul piano volumetrico. Kat registra il registro drammatico, l'enfasi spirituale e le sofferenze relazionali della zia, dimostrando una spiccata capacità di decodificare il sottotesto emotivo.
  5. *L'ansia per la rottura della routine:* Ted teme la perdita del controllo sul proprio ambiente sicuro: la presenza fisica ravvicinata di un estraneo, il rumore del respiro durante il sonno, la violazione del pudore nel cambiarsi d'abito e soprattutto l'impossibilità di ascoltare alla radio il bollettino dei naviganti, suo fondamentale strumento di autoregolazione emotiva.
- **2. Vero o Falso:**
  1. **FALSO.** Ted rifiuta l'analogia di Kat: per lui Londra somiglia a Londra e le macchine sono macchine, soltanto viste più piccole per effetto della distanza ottica.
  2. **FALSO.** Il padre è realmente un professionista delle demolizioni controllate ed è al lavoro sull'abbattimento di Barrington Heights (il Casermone).
  3. **VERO.** Ted riconosce lo stemma scolastico sulla busta (la X schiacciata con la mitria vescovile) e associa l'assenza al termine militare AWOL.
  4. **VERO.** La zia ha ottenuto un incarico professionale come curatrice d'arte a New York e intende iniziare una nuova vita con il figlio tredicenne.
  5. **FALSO.** Ted reagisce con profonda angoscia, avverte un dolore allo stomaco e sventola la mano al solo pensiero di dover condividere la stanza e non poter ascoltare il bollettino meteo.
- **3. Analisi dei Personaggi:**
  1. *La barriera del senso letterale:* Ted fatica a decodificare le figure retoriche perché il suo pensiero è strutturato su base logico-denotativa. Il riso dei familiari, seppur privo di malizia, lo fa sentire esposto e inadeguato («colto in fallo»), scatenando reazioni psicosomatiche (bruciore all'esofago, agitazione motoria). La famiglia manifesta un affetto sincero ma non sempre comprende quanto queste battute risultino faticose per il ragazzo.
  2. *Kat, tra ribellione e intuito emotivo:* Kat incarna la tipica turbolenza adolescenziale: rifiuta i consigli, marina la scuola, tratta il fratello con apparente durezza («chiudi il becco, verme»). Tuttavia, sa leggere con grande precisione le dinamiche affettive degli adulti (comprende il dramma della zia e la separazione dal marito) e funge da contraltare empatico alla rigidità razionale di Ted.
- **4. Officina di Scrittura:** Criteri di valutazione: rispetto del punto di vista in prima persona di Ted; impiego coerente del lessico scientifico/meteorologico (isobare, fronti freddi, perturbazioni, scale di intensità); resa vivida delle paure sensoriali e dell'ipersensibilità agli stimoli ambientali; originalità e plausibilità logica delle regole di sopravvivenza escogitate dal protagonista.
- **5. Laboratorio Lessicale:** Combinazione corretta: `1-C, 2-A, 3-E, 4-B, 5-D`.
- **6. Attività Speciale:** Criteri di osservazione: correttezza delle proporzioni e chiarezza della planimetria; coerenza e originalità nell'identificazione grafica delle aree di sicurezza rispetto a quelle di intrusione; pertinenza della rosa dei venti/simbolo meteorologico; completezza, leggibilità e pertinenza della legenda con almeno 4 simboli.

[[FINE]]
