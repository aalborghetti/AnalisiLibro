[[FILE: blocco_04_esercizi.md]]
# SCHEDA DIDATTICA DI LETTURA E COMPRENSIONE
## *Il mistero del London Eye* di Siobhan Dowd
### Unità Didattica 4 (Blocco 4): *Il dodo, il brigantino e il lord* – *Margini d'errore*

---

> ### 🌊 Quando svanire non è un'illusione
> «La sola cosa che collegava il dodo, Lord Lucan, le persone a bordo della Mary Celeste e Salim era che erano tutti scomparsi. [...] "La gente non evapora, Ted. Salim dev'essere da qualche parte. Se è colpa mia se è sparito, devo trovarlo. Ma ho bisogno del tuo aiuto. Ho bisogno del tuo cervello, Ted. Nessuno pensa meglio di te."»  
> Rientrati dal South Bank, la casa di Ted è soffocata dal silenzio e dal rimorso. Mentre gli adulti sprofondano nell'angoscia e la polizia varca la soglia di casa, nella camera da letto avviene un miracolo silenzioso: la barriera tra Kat e Ted si sgretola di fronte alla tragedia. Ma un ritrovamento inaspettato nella tasca della giacca di Ted trasforma il mistero in un segreto bruciante: la macchina fotografica di Salim è ancora lì, con ventuno scatti pronti a svelare la verità.

---

## 1. Comprensione del Testo

*Rispondi alle domande sul tuo quaderno in modo completo, motivando con riferimenti precisi al testo.*

1. **I modelli storici di sparizione:** Rifugiandosi nella sua stanza dopo la crisi familiare, Ted consulta le enciclopedie e riflette su tre celebri casi di scomparsa (l'estinzione del dodo, la fuga misteriosa di Lord Lucan e la nave fantasma *Mary Celeste*). Per quale motivo la mente di Ted sente il bisogno di ricondurre il dramma di Salim a questi precedenti storici e scientifici?
2. **Un gesto inedito di vicinanza:** Ted prova una naturale repulsione per il contatto fisico, eppure quando Kat entra disperata nella stanza compie lo sforzo di posarle una mano sulla spalla. Che cosa rende questo momento una svolta fondamentale nel rapporto tra i due fratelli?
3. **L'indizio inaspettato nella giacca:** Frugando distrattamente nella tasca della propria giacca, Ted trova un oggetto appartenente a Salim che non dovrebbe essere lì: la sua macchina fotografica. Come è finita quell'apparecchio nella giacca di Ted e quale dilemma si apre tra i due fratelli sul consegnarla o meno alla polizia?
4. **Il calcolo del margine d'errore:** Durante l'interrogatorio con l'ispettrice Pearce, perché Ted rifiuta di dichiararsi sicuro al 100% di aver seguito la capsula giusta, affermando di esserlo solo al 98%? Come spiega il concetto scientifico di «margine d'errore» e del metodo induttivo?
5. **I limiti delle indagini ufficiali:** Quali difficoltà pratiche e tecniche espone l'ispettrice Pearce riguardo all'analisi dei filmati delle telecamere a circuito chiuso (CCTV) e all'identificazione degli oltre trecento passeggeri saliti sul London Eye in quella fascia oraria?

---

## 2. Vero o Falso? (Attenzione ai dettagli)

*Indica nella tabella se l'affermazione è Vera (V) o Falsa (F). Correggi e motiva sul tuo quaderno le affermazioni false.*

| Affermazione | V | F |
| :--- | :---: | :---: |
| 1. Il contatore della macchina fotografica di Salim, ritrovata nella giacca di Ted, indica che sono stati impressi 21 scatti su un totale di 24 fotogrammi disponibili. | | |
| 2. Quando Kat entra nella camera di Ted, lo trova rilassato e disteso sul letto mentre ascolta musica con le cuffie. | | |
| 3. L'ispettrice di polizia Pearce si presenta a casa Spark in abiti civili e accoglie con pacata curiosità il ragionamento di Ted sul margine d'errore del 2%. | | |
| 4. Dalle verifiche condotte dalla polizia sui biglietti del London Eye, risulta che tutti i trecento passeggeri della mattinata avevano pagato con carta di credito nominativa. | | |
| 5. Al termine del colloquio, la madre incoraggia calorosamente Ted a rimanere nel soggiorno per assistere alle domande private rivolte a zia Gloria. | | |

---

## 3. Analisi dei Personaggi e Riflessione

*Rifletti sulle scelte e sulle emozioni dei protagonisti e rispondi sul quaderno.*

1. **La solitudine condivisa e il patto fraterno:** Kat ammette per la prima volta la propria vulnerabilità («Sei tutto quello che mi è rimasto... ho bisogno del tuo cervello, nessuno pensa meglio di te») e Ted compie l'enorme sforzo sensoriale di toccarle la spalla. In quale modo il senso di colpa e il terrore per la sorte di Salim trasformano la rivalità tra Kat e Ted in una vera alleanza investigativa?
2. **La razionalità scientifica contro l'urgenza dell'angoscia:** Nel soggiorno si consuma lo scontro tra la mente analitica di Ted (che disquisisce filosoficamente sull'impossibilità della certezza assoluta) e la disperazione viscerale di zia Gloria (che rifiuta ogni astrattezza pretendendo risposte concrete per ritrovare il figlio). Quale riflessione pedagogica suggerisce questo contrasto sui diversi modi in cui gli esseri umani reagiscono al dolore e all'ignoto?

---

## 4. Officina di Scrittura Creativa ed Empatia

*Mettiti nei panni di uno dei protagonisti e svolgi l'attività sul tuo quaderno.*

Immagina di essere **Ted** nel momento in cui, allontanato dal soggiorno dalla madre («Pussa via»), ti ritrovi in cucina accanto a Kat che piange disperata con la testa contro il frigorifero. Stringi tra le dita, dentro la tasca della giacca, la macchina fotografica di Salim con i suoi 21 scatti non sviluppati.  
Scrivi una pagina del tuo **diario personale**:
- Descrivi la frustrazione fisica e sensoriale (il peso nello stomaco, lo sfarfallio della mano) provata nell'essere escluso dagli adulti che ti trattano come un peso anziché come una mente capace di ragionare;
- Confessa il conflitto etico che provi per aver taciuto all'ispettrice Pearce la presenza della fotocamera e l'esistenza dell'uomo del biglietto, combattuto tra il tuo bisogno innato di dire sempre la verità e il patto segreto con Kat;
- Spiega per quale motivo, secondo la tua logica scientifica, quel rullino fotografico rappresenta una prova materiale decisiva che voi due dovrete decifrare prima della polizia.

---

## 5. Laboratorio Lessicale e Modi di Dire

*Associa ciascun vocabolo o espressione d'autore al suo significato nel contesto del racconto (indica sul quaderno la combinazione corretta numero-lettera).*

| Termine o Modo di Dire | Abbinamento | Significato Contestuale |
| :--- | :---: | :---: |
| 1. **Margine d'errore** | | A. Modo di dire figurato che denota un'atmosfera di tensione relazionale così densa, carica di silenzio e ostilità da sembrare quasi solida e tangibile. |
| 2. **Metodo induttivo** | | B. Procedimento logico-scientifico che formula conclusioni o previsioni probabilistiche universali partendo dall'analisi empirica di casi particolari ripetuti. |
| 3. **Tagliare con il coltello** | | C. Categoria descrittiva impiegata per identificare un sentimento acuto di rabbia e impotenza generato dall'incapacità di raggiungere uno scopo o modificare gli eventi. |
| 4. **Pussa via** | | D. Intervallo di tolleranza statistica che quantifica la probabile percentuale di inesattezza o fallibilità di una rilevazione sperimentale o sensoriale. |
| 5. **Frustrazione estrema** | | E. Esclamazione colloquiale o ordine imperativo impartito in modo sbrigativo per intimare a qualcuno di allontanarsi rapidamente da un luogo. |

---

## 6. Attività Speciale "Fuori dagli Schemi"

**Redazione Giornalistica: Prima Pagina dell'Evening Standard**  
La notizia della scomparsa di un ragazzo da una delle attrazioni più celebri e sorvegliate al mondo è destinata a conquistare le prime pagine della stampa britannica.  
Assumi il ruolo di caporedattore del quotidiano londinese *London Evening Standard* e realizza sul tuo quaderno la prima pagina dell'edizione straordinaria del 24 maggio:

1. **La Titolazione della Notizia:**
   - Elabora un titolo di apertura a caratteri cubitali (Headline) asciutto, incisivo e privo di sensazionalismo volgare;
   - Scrivi un catenaccio (sottotitolo) di due righe che riassuma l'enigma della capsula sigillata.

2. **L'Articolo di Cronaca (La Regola delle 5 W):**
   - Redigi un articolo di apertura strutturato sui cinque pilastri del giornalismo:
     - *Who (Chi):* Salim Malik, 13 anni, in procinto di trasferirsi a New York;
     - *What (Cosa):* Salito sulla ruota alle 11:32, non è mai ridisceso alle 12:02;
     - *Where (Dove):* London Eye, sponda sud del Tamigi;
     - *When (Quando):* Mezzogiorno di lunedì 24 maggio;
     - *Why / How (Come/Perché):* Le ipotesi della polizia, i controlli sui filmati CCTV e il mistero dell'assenza di testimoni oculari.

3. **Box Informativo e Appello della Polizia:**
   - Inserisci un riquadro con l'appello ufficiale di Scotland Yard e dell'Ispettrice Pearce rivolto a chiunque abbia notato movimenti sospetti nella fila d'attesa.

[SPAZIO PER IL TUO DISEGNO / RILIEVO GRAFICO]

---

### GUIDA E RIASSUNTO PER IL DOCENTE

#### Riassunto sintetico dei capitoli
I capitoli 9, 10 e 11 mostrano l'impatto emotivo della crisi sulla famiglia e l'inizio della collaborazione tra fratelli:
- **Capitolo 9 (*Il dodo, il brigantino e il lord*):** Rifugiatosi nella sua camera, Ted scarica l'angoscia riattivando un vecchio schema motorio ripetitivo (saltare ritmicamente tra letto, pavimento e parete), poi consulta le sue enciclopedie analizzando storiche sparizioni irrisolte (il dodo estinto, la fuga misteriosa di Lord Lucan, il brigantino abbandonato *Mary Celeste*). Kat entra in camera sconvolta: sentendosi isolata e colpevolizzata dai genitori, cerca rifugio nel fratello. Ted compie lo sforzo immenso di posarle una mano sulla spalla per consolarla; Kat ricambia scoppiando in lacrime e pronuncia il suo primo elogio sincero («Ho bisogno del tuo cervello, nessuno pensa meglio di te»). Mettendosi le mani in tasca, Ted scopre con stupore di avere ancora con sé la macchina fotografica di Salim, infilata distrattamente nella giacca dopo l'ultimo scatto alla ruota.
- **Capitolo 10 (*Amore-odio*):** Kat esamina l'apparecchio: il contatore segna 21 scatti. I due comprendono che quel rullino contiene la documentazione visiva dell'intera mattinata, inclusa l'area dei biglietti. Kat impone di non consegnarla alla polizia, temendo che la rivelazione del biglietto omaggio sveli la loro menzogna e le loro responsabilità. Discutendo di affetti e risentimenti reciproci, Kat ammette di provare sentimenti contrastanti di "amore-odio". Il campanello annuncia l'arrivo delle forze dell'ordine: un agente in divisa e l'ispettrice Pearce, detective in borghese incaricata delle indagini sui minori.
- **Capitolo 11 (*Margini d'errore*):** Nel salotto l'atmosfera è plumbea. L'ispettrice Pearce interroga i ragazzi per verificare se siano certi al 100% di aver seguito la capsula di Salim. Con rigore logico-filosofico, Ted risponde di esserlo al 98%, spiegando che la percezione sensoriale umana è sempre soggetta a un 2% di margine d'errore e illustrando il principio di induzione. Gloria sbotta esasperata contro queste digressioni teoriche, esigendo risposte immediate. L'ispettrice illustra le difficoltà investigative: i filmati CCTV della ruota non mostrano anomalie; degli oltre trecento passeggeri imbarcati a quell'ora si possono rintracciare solo i pagamenti con carta di credito, mentre quelli in contanti restano ignoti, e nessuno finora ricorda il ragazzo. L'ispettrice chiede di parlare in privato con Gloria; la madre allontana bruscamente Ted con un «Pussa via». In cucina, Ted e Kat condividono un'estrema e dolorosa frustrazione.

#### Soluzioni ed elementi chiave di correzione
- **1. Comprensione del Testo:**
  1. *I modelli storici di sparizione:* Di fronte a un evento imprevedibile e caotico che manda in tilt le sue certezze, Ted cerca un rifugio cognitivo catalogando il fenomeno. Confrontare la sparizione di Salim con casi storici noti gli permette di razionalizzare l'angoscia, cercando schemi logici e precedenti documentati in grado di rendere comprensibile l'incomprensibile.
  2. *Un gesto inedito di vicinanza:* Per Ted il contatto corporeo è fonte di disturbo e sovraccarico sensoriale. Superare questa barriera fisica per appoggiare la mano sulla spalla della sorella denota una maturazione empatica straordinaria: Ted percepisce il dolore disperato di Kat e sceglie deliberatamente di accoglierlo, suggellando un patto di solidarietà inedito.
  3. *L'indizio inaspettato nella giacca:* Ted aveva scattato l'ultima foto a Salim in coda e aveva riposto la fotocamera nella giacca per automatismo, dimenticandosene. Il dilemma nasce dal fatto che consegnare l'apparecchio alla polizia costringerebbe i fratelli a confessare di aver preso il biglietto dallo sconosciuto, infrangendo la menzogna concordata con gli adulti.
  4. *Il calcolo del margine d'errore:* Ted rifiuta l'assolutismo acritico: da scienziato riconosce i limiti fisiologici dell'apparato visivo umano e cita il metodo induttivo (fondato sull'esperienza pregressa ma mai privo di fallibilità statistica). Il suo 98% non è insicurezza, ma massima onestà intellettuale e rigore metodologico.
  5. *I limiti delle indagini ufficiali:* L'ispettrice rivela che le telecamere CCTV presentano angoli ciechi e non possono inquadrare ogni singolo passeggero; inoltre, il pagamento in contanti rende anonima e irrintracciabile gran parte dei visitatori della ruota, vanificando la raccolta immediata di testimonianze dirette.
- **2. Vero o Falso:**
  1. **VERO.** Il contatore analogico della macchina fotografica indica chiaramente 21 pose utilizzate.
  2. **FALSO.** Ted sta compiendo il suo rituale fisico ripetitivo saltando dal letto alla parete per ritrovare concentrazione.
  3. **VERO.** Pearce indossa abiti civili («plain clothes») e sorride con sottile compiacimento di fronte alla spiegazione scientifica di Ted sul 2% di margine d'errore.
  4. **FALSO.** Più di trecento persone sono salite a quell'ora e molti hanno pagato in contanti, motivo per cui la polizia non può risalire alla loro identità.
  5. **FALSO.** La madre gli intima bruscamente di allontanarsi («Pussa via» / «Scoot») per lasciarle sole con la detective.
- **3. Analisi dei Personaggi:**
  1. *La solitudine condivisa e il patto fraterno:* Il dramma azzera le barriere quotidiane. Kat riconosce finalmente l'eccezionalità del fratello, non più deriso come «neek» ma invocato come guida intellettuale. Ted, a sua volta, scopre che la sorella ha bisogno di lui. L'alleanza nasce dalla consapevolezza che nessun altro, nel mondo degli adulti in preda al panico, possiede la combinazione di coraggio (Kat) e lucidità deduttiva (Ted) per affrontare la ricerca.
  2. *La razionalità scientifica contro l'urgenza dell'angoscia:* La scena contrappone due reazioni umane primarie alla catastrofe: la via della ragione (Ted analizza variabili, margini di tolleranza e probabilità) e la via del sentimento materno (Gloria reagisce con rabbia, rigetto delle astrazioni e disperazione fisica). L'episodio mostra come l'eccesso di freddezza razionale possa risultare incomprensibile o crudele per chi soffre, ma rimanga al contempo l'unico strumento efficace per non cedere all'isteria.
- **4. Officina di Scrittura:** Criteri di valutazione: resa puntuale della voce monologante di Ted (terminologia precisa, osservazioni sensoriali, metafore alimentari/fisiche sulla frustrazione); profondità nell'esporre il dilemma morale tra verità e lealtà fraterna; formulazione di un'ipotesi investigativa originale incentrata sul valore probatorio dei 21 scatti della fotocamera.
- **5. Laboratorio Lessicale:** Combinazione corretta: `1-D, 2-B, 3-A, 4-E, 5-C`.
- **6. Attività Speciale:** Criteri di osservazione: applicazione corretta della struttura giornalistica (Headline, catenaccio, lead basato sulle 5 W); equilibrio tra rigore documentario e capacità di catturare l'attenzione del lettore; qualità grafica dell'illustrazione o del rilievo della prima pagina.

[[FINE]]
