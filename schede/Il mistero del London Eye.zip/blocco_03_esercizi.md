[[FILE: blocco_03_esercizi.md]]
# SCHEDA DIDATTICA DI LETTURA E COMPRENSIONE
## *Il mistero del London Eye* di Siobhan Dowd
### Unità Didattica 3 (Blocco 3): *Andiamo al London Eye* – *Non tutto ciò che sale necessariamente scende*

---

> ### 🌊 Trenta minuti per svanire nel nulla
> «La capsula atterrò. Le porte si aprirono e i passeggeri uscirono a due a due e a tre a tre. Si allontanarono in direzioni diverse. I loro volti sorridevano. I loro cammini probabilmente non si sarebbero mai più incrociati. Ma Salim non era tra loro.»  
> Una mattina di sole splendido, una coda chilometrica sulle rive del Tamigi e un misterioso sconosciuto che regala un biglietto d'ingresso: sembra l'inizio di una perfetta giornata di vacanza londinese. Eppure, allo scoccare delle 12:02, l'impossibile si compie sotto gli occhi sbigottiti di Ted e Kat. Una capsula d'acciaio e vetro sigillata nel cielo si svuota completamente, ma Salim non ne esce. Come può un ragazzo di tredici anni evaporare nell'aria senza lasciare traccia?

---

## 1. Comprensione del Testo

*Rispondi alle domande sul tuo quaderno in modo completo, motivando con riferimenti precisi al testo.*

1. **La trappola del biglietto gratuito:** Quando un ragazzo sconosciuto in coda offre un biglietto omaggio per il London Eye, Ted richiama la regola di sicurezza scolastica («non accettare regali dagli sconosciuti»). Per quale motivo Kat e Salim decidono di ignorare il suo avvertimento e quali giustificazioni razionali adducono per sentirsi del tutto al sicuro?
2. **Il tracciamento cronometrico:** In che modo Ted e Kat riescono a non perdere mai di vista la cabina di Salim durante l'intero arco dei trenta minuti di rotazione della ruota? Quale gesto condiviso al culmine dell'ascesa dà loro la certezza assoluta di aver seguito la capsula corretta?
3. **Il patto della menzogna:** Appena constatata la sparizione del cugino alle 12:02, Kat afferra violentemente il polso di Ted intimandogli di mentire alla madre e alla zia sulla provenienza del biglietto. Quale profondo conflitto interiore vive Ted di fronte a questa imposizione e da quale timore nasce la disperata reazione di Kat?
4. **L'intuizione al banco fotografico:** Di fronte allo smarrimento generale, è Ted a suggerire che Salim potrebbe essersi trattenuto al banco delle fotografie souvenir. Quale catena di osservazioni logiche guida questa ipotesi e quale rapida alternanza di speranza e delusione vivono i protagonisti subito dopo?
5. **Lo sfogo e il capro espiatorio:** Una volta tornati a casa, mentre l'attesa si fa insostenibile, zia Gloria punta il dito contro Ted accusandolo di essere la causa della sparizione («tu e la tua maledetta ruota di bicicletta nel cielo»). Da quali sentimenti incontrollabili scaturisce questo attacco ingiusto e come reagisce Ted di fronte al rifiuto degli adulti?

---

## 2. Vero o Falso? (Attenzione ai dettagli)

*Indica nella tabella se l'affermazione è Vera (V) o Falsa (F). Correggi e motiva sul tuo quaderno le affermazioni false.*

| Affermazione | V | F |
| :--- | :---: | :---: |
| 1. La macchina fotografica che Salim porta con sé per immortalare il panorama dall'alto è un moderno apparecchio digitale acquistato dalla zia la mattina stessa. | | |
| 2. La coda per accedere alla ruota panoramica è lunga quasi mezzo miglio e Ted calcola che l'attesa richiederebbe circa un'ora e quarantacinque minuti. | | |
| 3. Il ragazzo che cede il biglietto a Salim racconta di non poter salire perché la sua fidanzata è stata colta da una crisi di panico dovuta alla claustrofobia. | | |
| 4. Il poliziotto in servizio sulla riva del Tamigi prende immediatamente sul serio la tesi della sparizione misteriosa e organizza una battuta di ricerca con le squadre speciali. | | |
| 5. Al ritorno a casa, la prima telefonata che fa sobbalzare la famiglia è una richiesta di riscatto formulata da una banda di rapitori professionisti. | | |

---

## 3. Analisi dei Personaggi e Riflessione

*Rifletti sulle scelte e sulle emozioni dei protagonisti e rispondi sul quaderno.*

1. **La rigidità della regola contro la tentazione dell'opportunità:** Di fronte all'offerta dello sconosciuto, Ted applica alla lettera l'insegnamento preventivo («Stranger Danger»), mentre Kat e Salim cedono alla tentazione di saltare una fila estenuante, convinti che in pieno giorno e tra la folla non possa accadere nulla di male. Rifletti sul valore delle regole: quando una norma di prudenza viene considerata superflua dai ragazzi e qual è il confine tra fiducia nel prossimo e ingenuità pericolosa?
2. **Il crollo degli adulti e la ricerca della colpa:** Di fronte all'angoscia per l'irreperibilità del figlio, zia Gloria perde il controllo e scarica la propria disperazione su Ted, colpevole soltanto di aver proposto la visita al London Eye. Quali meccanismi psicologici spingono gli individui sotto shock a cercare un capro espiatorio innocente e come si manifesta la solitudine di Ted in questo clima di tempesta emotiva?

---

## 4. Officina di Scrittura Creativa ed Empatia

*Mettiti nei panni di uno dei protagonisti e svolgi l'attività sul tuo quaderno.*

Immagina di essere **Kat** nel momento in cui, rientrata a casa dopo le vane ricerche sul South Bank, ti siedi al tavolo della cucina con le cuffie spente sulla testa e la fronte premuta sulle braccia, incapace di sostenere lo sguardo di tua madre e di zia Gloria.  
Scrivi il tuo **monologo interiore**:
- Racconta il terrore agghiacciante provato nel vedere la capsula aprirsi alle 12:02 senza che Salim comparisse tra i passeggeri, e il senso di colpa soffocante per aver accettato quel biglietto da un perfetto sconosciuto pur di non fare la coda;
- Confessa le vere motivazioni per cui hai costretto Ted a mentire afferrandogli il braccio: volevi proteggere lui, te stessa o nascondere la vergogna per la tua leggerezza?
- Descrivi il tormento nel sentire i lamenti disperati della zia nella stanza accanto e formula una promessa solenne a te stessa per rimediare all'errore e ritrovare tuo cugino.

---

## 5. Laboratorio Lessicale e Modi di Dire

*Associa ciascun vocabolo o espressione d'autore al suo significato nel contesto del racconto (indica sul quaderno la combinazione corretta numero-lettera).*

| Termine o Modo di Dire | Abbinamento | Significato Contestuale |
| :--- | :---: | :---: |
| 1. **Mappa topologica** | | A. Modo di dire iperbolico che descrive un agitarsi disordinato, frenetico e del tutto privo di lucidità a seguito di un evento sconvolgente. |
| 2. **Parlare a raffica** | | B. Rappresentazione grafica schematica che evidenzia le connessioni di una rete trascurando le distanze metriche e le fedeli coordinate geografiche. |
| 3. **Foto ricordo automatica** | | C. Minaccia figurata tipica del lessico familiare inglese usata per promettere una punizione severissima e memorabile a chi ha combinato un disastro. |
| 4. **Come galline sgozzate** | | D. Scatto fotografico catturato da un obiettivo fisso lungo un percorso turistico, programmato per immortalare i visitatori in un punto strategico. |
| 5. **Pelle per bretelle** | | E. Espressione idiomatica per definire un chiacchierare ininterrotto, vorticoso e totalizzante, tale da isolare chi parla da tutto il contesto circostante. |

---

## 6. Attività Speciale "Fuori dagli Schemi"

**Dossier Investigativo: Il mistero della Capsula Sigillata**  
Alle 12:02 del 24 maggio si è consumato un evento apparentemente inspiegabile: un ragazzo è salito a bordo di una cabina d'osservazione chiusa e non ne è più disceso.  
Vesti i panni di un giovane detective e redigi sul tuo quaderno la prima scheda del **Dossier del Caso Salim Malik**:

1. **Scheda Cronologica dell'Evento:**
   - Orario e data esatta di ingresso nella capsula;
   - Orario di arrivo al punto più alto (culmine dell'orbita a 135 metri) e orario esatto di apertura porte;
   - Condizioni di visibilità e meteo sul Tamigi;
   - Numero stimato di passeggeri a bordo insieme a Salim.

2. **Identikit e Rilievi del "Donatore del Biglietto":**
   - Descrizione fisica dell'uomo misterioso (statura, abbigliamento, scarpe, oggetti tenuti in mano);
   - Alibi fornito per giustificare la cessione del biglietto;
   - Tre elementi sospetti o incongruenze nel suo comportamento che meritano ulteriori verifiche.

3. **Schema Tecnico della Banchina di Imbarco/Sbarco:**
   - Disegna la pianta della capsula e della piattaforma d'uscita con il flusso dei passeggeri;
   - Posiziona la fotocamera per le foto souvenir e l'angolo di visuale da cui Ted e Kat osservavano la scena;
   - Formula due ipotesi razionali su come una persona possa eludere la sorveglianza in un ambiente a flusso continuo.

[SPAZIO PER IL TUO DISEGNO / RILIEVO GRAFICO]

---

### GUIDA E RIASSUNTO PER IL DOCENTE

#### Riassunto sintetico dei capitoli
I capitoli 6, 7 e 8 rappresentano l'incidente scatenante e il motore propulsivo dell'intera vicenda gialla:
- **Capitolo 6 (*Andiamo al London Eye*):** Mattina di lunedì 24 maggio. Salim scherza radendosi la prima peluria col rasoio dello zio. I ragazzi partono per il London Eye accompagnati dalle madri, che camminano parlando fitto fitto. Durante il tragitto a piedi e in metropolitana, Ted illustra la differenza tra mappe topologiche e topografiche e osserva ammirato la passione di Salim per i grattacieli (le Torri di Barrington Heights e Guy's Tower). Arrivati all'imbarcadero sul Tamigi, la fila per i biglietti è sterminata (oltre 100 minuti di attesa). All'improvviso uno sconosciuto (alto, giacca mimetica, scarpe da ginnastica nuove e caffè da asporto) propone un biglietto omaggio, sostenendo che la fidanzata è stata colta da claustrofobia. Ted obietta ricordando la regola di non fidarsi degli sconosciuti, ma Kat e Salim insistono e accettano. Alle 11:32 Salim varca i tornelli ed entra da solo in una cabina sigillata con altri venti turisti.
- **Capitolo 7 (*La ruota gira*):** Ted e Kat seguono minuziosamente il tragitto della capsula camminando a ritroso per conservare la visuale. Alle 11:47 la cabina tocca il punto di massima elevazione (135 metri) e i fratelli gridano all'unisono «ORA!». Durante la discesa notano i passeggeri raggrupparsi verso nord-est per la foto ricordo. Alle 12:02 la capsula attracca e si apre: i passeggeri escono sorridenti a gruppetti, ma Salim non c'è. Ted e Kat ispezionano anche le cabine successive: Salim è svanito nel nulla.
- **Capitolo 8 (*Non tutto ciò che sale necessariamente scende*):** Presa dal panico, Kat costringe Ted a mentire ai genitori sulla provenienza del biglietto. Si cerca Salim al banco delle fotografie souvenir (intuizione geniale di Ted), ma il cugino non si trova. Quando Gloria tenta di chiamarlo sul cellulare, la voce automatica informa che l'apparecchio è spento. Seguono ricerche frenetiche sul South Bank e la denuncia alla polizia fluviale: un agente raccoglie i dati con sufficienza, affermando che i ragazzi non evaporano. Tornati a casa in un clima di angoscia crescente, una telefonata commerciale esaspera Gloria, che esplode in una crisi isterica arrivando a incolpare ingiustamente Ted per aver suggerito la gita. La madre allontana Ted per calmare la sorella; Kat si isola disperata in cucina e Ted si ritira in solitudine nella sua camera.

#### Soluzioni ed elementi chiave di correzione
- **1. Comprensione del Testo:**
  1. *La trappola del biglietto gratuito:* Kat e Salim ritengono che la luce del giorno, la presenza di centinaia di testimoni e la brevità dell'interazione azzerino qualsiasi rischio, considerando l'avvertimento di Ted una rigidità infantile e un ostacolo pratico per evitare un'attesa estenuante sotto il sole.
  2. *Il tracciamento cronometrico:* I due fratelli si muovono camminando all'indietro lungo la banchina per non perdere il contatto visivo con la cabina. Il segnale condiviso avviene alle 11:47, quando la capsula raggiunge il vertice massimo dell'arco (la sommità dell'orbita a 135 metri) e i due esclamano contemporaneamente «ORA!».
  3. *Il patto della menzogna:* Ted prova un rifiuto quasi fisico per la menzogna, che per la sua mente logica rappresenta una violazione intollerabile dell'ordine dei fatti. Kat lo costringe con la forza per paura della punizione e del senso di colpa: ammettere di aver preso il biglietto da un estraneo significherebbe confessare la propria imprudenza davanti alle madri.
  4. *L'intuizione al banco fotografico:* Ted deduce razionalmente che, essendosi i passeggeri raggruppati verso la fotocamera automatica all'uscita, la prima tappa naturale dopo lo sbarco fosse il monitor dei souvenir per ammirare il proprio scatto. La speranza crolla subito dopo, quando il telefono di Salim risulta staccato.
  5. *Lo sfogo e il capro espiatorio:* L'isteria di Gloria nasce dal terrore dell'impotenza, dall'incertezza sul destino del figlio e dal rimorso per non aver vigilato. La mente sotto shock cerca un bersaglio immediato su cui scaricare la colpa; Ted reagisce ritirandosi silenziosamente nella propria stanza, abituato a essere frainteso ed escluso nelle crisi emotive degli adulti.
- **2. Vero o Falso:**
  1. **FALSO.** È una fotocamera analogica a rullino regalatagli dalla madre per abituarlo alla cura dello scatto.
  2. **VERO.** La fila è descritta come lunga quasi mezzo miglio con un tempo stimato di circa un'ora e tre quarti.
  3. **VERO.** La motivazione addotta dallo sconosciuto è la claustrofobia improvvisa della compagna.
  4. **FALSO.** L'agente mostra scetticismo, minimizza la situazione affermando che i minori non si dissolvono nel nulla e rimanda le verifiche a più tardi.
  5. **FALSO.** Si tratta unicamente di una telefonata pubblicitaria di un venditore di verande e serramenti.
- **3. Analisi dei Personaggi:**
  1. *La rigidità della regola contro la tentazione dell'opportunità:* Il brano mostra il contrasto tra l'aderenza deontologica e inflessibile di Ted e il pragmatismo opportunista di Kat e Salim. Gli adolescenti tendono a considerare le regole di sicurezza come fastidiosi divieti genitoriali, sottovalutando che il contesto apparentemente protetto della folla urbana può offrire una copertura ideale per inganni e manipolazioni.
  2. *Il crollo degli adulti e la ricerca della colpa:* La dinamica del capro espiatorio scatta quando il dolore diventa intollerabile e non si hanno spiegazioni razionali. Zia Gloria proietta su Ted l'angoscia della propria negligenza genitoriale. La reazione di Ted evidenzia la vulnerabilità dei ragazzi neurodivergenti, che spesso non dispongono degli strumenti emotivi per difendersi dalle tempeste affettive degli adulti.
- **4. Officina di Scrittura:** Criteri di valutazione: capacità di esprimere l'angoscia e il rimorso di Kat in prima persona; spiegazione psicologica credibile della costrizione a mentire imposta al fratello; resa efficace del conflitto tra senso di colpa e desiderio di redenzione; impegno morale ad agire attivamente per ritrovare Salim.
- **5. Laboratorio Lessicale:** Combinazione corretta: `1-B, 2-E, 3-D, 4-A, 5-C`.
- **6. Attività Speciale:** Criteri di osservazione: accuratezza cronologica dei dati raccolti dal testo; pertinenza dell'identikit dello sconosciuto e identificazione delle anomalie comportamentali; chiarezza descrittiva e grafica dello schema della capsula e dell'area di sbarco; coerenza logico-deduttiva delle prime ipotesi investigative.

[[FINE]]
