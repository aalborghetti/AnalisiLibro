[[FILE: blocco_10_esercizi.md]]
# SCHEDA DIDATTICA DI LETTURA E COMPRENSIONE
## *Il mistero del London Eye* di Siobhan Dowd
### Unità Didattica 10 (Blocco 10): *La strada verso il nulla* – *Il rumore della tempesta*

---

> ### 🌊 Nel frastuono della tempesta, la voce della ragione
> «Quando cerchi di parlare con le persone nel bel mezzo di una tempesta, non possono sentirti. Non riescono ad afferrare le tue parole per via del rumore del temporale. Tuoni, pioggia e vento. [...] Il tempo aveva un rumore. Non l'avevo mai sentito prima. Mi misi le mani sulle orecchie: era assordante.»  
> Il drammatico faccia a faccia con Christy sembra condurre Kat e Ted in un vicolo cieco: l'uomo del biglietto si dilegua su un autobus affollato lasciando dietro di sé solo parole confuse su una ragazza mora in coda. Al rientro a casa scoppia la tempesta perfetta tra rimproveri materni, bugie scoperte e lacrime disperate. Ma è proprio quando tutti cedono al caos che Ted, isolandosi nel giardino tra il vento solare e le forme cangianti delle nubi, ha la folgorazione decisiva: la realtà cambia a seconda di come la si guarda. Mentre la casa è sorda e cieca, Ted compie il gesto più coraggioso della sua vita componendo il numero della polizia.

---

## 1. Comprensione del Testo

*Rispondi alle domande sul tuo quaderno in modo completo, motivando con riferimenti precisi al testo.*

1. **La rivelazione di Christy e il nuovo vicolo cieco:** Nel Capitolo 30, messo alle strette da Kat e Ted, quale spiegazione fornisce Christy sulla provenienza del biglietto omaggio? In che modo la sua confessione sulla «ragazza mora in coda» sembra far precipitare l'indagine in un vicolo cieco («la strada verso il nulla»)?
2. **La tempesta familiare al rientro:** Nel Capitolo 31, quando i due fratelli tornano a casa con i capelli completamente asciutti, la madre scopre la loro bugia sventolando i costumi da bagno mai usati. Quali reazioni a catena e quali conflitti repressi esplodono tra madre e figlia fino alla rottura violenta?
3. **L'illuminazione razionale nel giardino:** Nel Capitolo 32, mentre cerca rifugio sensoriale in giardino tra i panni stesi e il vento solare, quale folgorazione logica colpisce Ted? In che modo l'idea della realtà che cambia «a seconda di come la si guarda» gli permette di capire il trucco con cui Salim è uscito dalla capsula?
4. **Il richiamo de *La tempesta*:** Nel Capitolo 33, entrando nella stanza dove zia Gloria dorme sotto l'effetto dei sedativi, Ted nota una copia della commedia di Shakespeare *La tempesta*. Quale frase mormorata nel sonno dalla zia sul personaggio del «principe Ferdinando» tocca profondamente la sensibilità di Ted?
5. **La sordità degli adulti e la chiamata all'ispettrice:** Ted tenta di comunicare la sua scoperta prima alla madre e poi allo zio Rashid, ma entrambi lo ignorano trattandolo con sufficienza. Quale coraggiosa decisione assume allora Ted per farsi ascoltare e perché sceglie di telefonare personalmente all'ispettrice Pearce?

---

## 2. Vero o Falso? (Attenzione ai dettagli)

*Indica nella tabella se l'affermazione è Vera (V) o Falsa (F). Correggi e motiva sul tuo quaderno le affermazioni false.*

| Affermazione | V | F |
| :--- | :---: | :---: |
| 1. Christy racconta ai ragazzi di aver sottratto il biglietto del London Eye dal portafoglio di un turista addormentato su una panchina. | | |
| 2. Al termine del confronto con Christy, Kat sfoga la sua disperazione e frustrazione pestando e schiacciando con lo stivale una lattina di Coca-Cola fino a renderla piatta. | | |
| 3. La madre accoglie il rientro dei ragazzi con un abbraccio affettuoso, congratulandosi con loro per aver fatto una nuotata rinfrescante in piscina. | | |
| 4. Nel giardino sul retro, Ted riflette sulla direzione del flusso particellare del vento solare e intuisce la chiave logica con cui Salim ha potuto lasciare la cabina del London Eye. | | |
| 5. Quando Ted dice allo zio Rashid di aver risolto il mistero, lo zio si siede immediatamente con lui prendendo appunti dettagliati sul proprio taccuino. | | |

---

## 3. Analisi dei Personaggi e Riflessione

*Rifletti sulle scelte e sulle emozioni dei protagonisti e rispondi sul quaderno.*

1. **La solitudine dell'ascolto nel «rumore della tempesta»:** Ted constata amaramente che «quando cerchi di parlare con le persone nel bel mezzo di una tempesta, non possono sentirti». In quale modo il dolore, la paura e il senso di colpa degli adulti creano una barriera acustica ed emotiva che impedisce loro di vedere le risorse e le intuizioni dei ragazzi?
2. **L'autonomia decisionale e l'iniziativa civile:** Di fronte all'indifferenza dei genitori, Ted non si rifugia nella passività ma prende in mano il ricevitore del telefono, vincendo la sua fobia per le telefonate per rivolgersi direttamente a Scotland Yard. Cosa dimostra questo atto sull'evoluzione del personaggio e sul suo senso di responsabilità verso la verità e la giustizia?

---

## 4. Officina di Scrittura Creativa ed Empatia

*Mettiti nei panni di uno dei protagonisti e svolgi l'attività sul tuo quaderno.*

Immagina di essere **Ted** nel momento esatto in cui ti siedi sul bracciolo del divano, schiacci la mano che sfarfalla sotto la coscia per tenerla ferma, e con l'altra componi il numero dell'Ispettrice Pearce impresso sul biglietto da visita.  
Scrivi il tuo **monologo interiore**:
- Racconta il rumore assordante del silenzio della casa, dove il battito del tuo cuore e il ticchettio dell'orologio scandiscono il tempo che stringe per la vita di Salim;
- Spiega la frustrazione per essere stato trattato come un'ombra trasparente da tua madre e da zio Rashid, pur avendo in mano la chiave per risolvere il caso;
- Descrivi cosa provi mentre ascolti il segnale di libero al telefono, preparando nella tua mente le parole scientifiche ed esatte con cui spiegherai alla detective come Salim è uscito dalla capsula.

---

## 5. Laboratorio Lessicale e Modi di Dire

*Associa ciascun vocabolo o espressione d'autore al suo significato nel contesto del racconto (indica sul quaderno la combinazione corretta numero-lettera).*

| Termine o Modo di Dire | Abbinamento | Significato Contestuale |
| :--- | :---: | :---: |
| 1. **La strada verso il nulla** | | A. Servizio telefonico di assistenza pubblica per la ricerca di recapiti, impiegato come esercizio pratico di riabilitazione comunicativa per Ted. |
| 2. **Vento solare** | | B. Flusso continuo di particelle ionizzate emesse dalla corona solare nello spazio a centinaia di chilometri al secondo. |
| 3. **Rumore della tempesta** | | C. Percezione interiore angosciosa del trascorrere inesorabile dei secondi, vissuta come una pulsazione fisica opprimente durante un'emergenza. |
| 4. **Il rumore del tempo** | | D. Espressione metaforica usata per denotare un vicolo cieco investigativo o un tentativo infruttuoso che non porta ad alcun esito. |
| 5. **Informazioni abbonati** | | E. Immagine figurata che definisce il caos emotivo e le urla disperate che impediscono agli individui di prestare ascolto alla voce della ragione. |

---

## 6. Attività Speciale "Fuori dagli Schemi"

**Redazione Giornalistica: L'Intervista Esclusiva all'Ispettrice Pearce**  
La svolta delle indagini e l'impatto mediatico della vicenda richiedono un'analisi giornalistica rigorosa.  
Assumi il ruolo di reporter di giudiziaria del settimanale britannico *The Observer* e realizza sul tuo quaderno un'**Intervista d'Approfondimento all'Ispettrice Pearce**:

1. **Testata, Titolazione e Catenaccio:**
   - Inventa un titolo a tutta pagina che metta in luce il paradosso della scomparsa da una capsula ermetica in una giornata di sole;
   - Scrivi un catenaccio (occhiello esplicativo) di due righe sul ruolo delle segnalazioni civili e delle telecamere CCTV.

2. **Il Corpo dell'Intervista (Quattro quesiti d'inchiesta):**
   - *Domanda 1 (Sul mistero della capsula):* Chiedi all'ispettrice come Scotland Yard spieghi l'assenza di testimoni oculari all'uscita delle 12:02;
   - *Domanda 2 (Sulla pista della sicurezza privata):* Domanda quali riscontri siano emersi sull'addetto alla sorveglianza Christy e sulla presunta ragazza mora della fila;
   - *Domanda 3 (Sul ruolo dei media):* Chiedi un parere professionale sull'appello televisivo dei familiari e sui rischi di depistaggio;
   - *Domanda 4 (Sull'apporto dei testimoni minori):* Interroga la detective sul valore delle osservazioni cronometriche fornite dai giovanissimi cugini dello scomparso.

3. **Box Investigativo con l'Identikit dei Testimoni Chiave:**
   - Inserisci un riquadro con la sintesi delle caratteristiche somatiche e degli abiti del donatore del biglietto e della ragazza cercata dalla polizia.

[SPAZIO PER IL TUO DISEGNO / RILIEVO GRAFICO]

---

### GUIDA E RIASSUNTO PER IL DOCENTE

#### Riassunto sintetico dei capitoli
I capitoli 30–33 rappresentano la cesura fondamentale del romanzo: dal fallimento apparente dell'azione sul campo alla folgorazione intellettuale solitaria di Ted:
- **Capitolo 30 (*La strada verso il nulla*):** Faccia a faccia con Christy fuori dal pub. L'uomo, visibilmente agitato dopo aver visto la TV, ammette di non aver comprato lui il biglietto: lo ha ricevuto in fila da una ragazza mora che affermava di non voler perdere il turno dopo il mancato arrivo del fidanzato. Christy salta al volo su un autobus che chiude le porte in faccia a Kat. Disperata per l'ennesimo vicolo cieco, Kat sfoga la sua rabbia prendendo a calci una lattina di bibita e schiacciandola con lo stivale, gridando che l'intera pista era solo «una strada verso il nulla».
- **Capitolo 31 (*Il momento in cui tocca terra il tornado*):** Rientro a casa Spark. I fratelli hanno i capelli perfettamente asciutti: la madre li attende sulla soglia brandendo i costumi da bagno puliti. Scoppia una violentissima lite familiare: la madre aggredisce verbalmente i figli per la bugia; Kat ribatte urlando che gli adulti non stanno facendo nulla per ritrovare Salim. La tensione degenera: la madre schiaffeggia Kat, che si barrica in camera urlando. Ted si rifugia in giardino per fuggire dal sovraccarico acustico.
- **Capitolo 32 (*Vento solare*):** In giardino, Ted calma le proprie onde cerebrali osservando il cielo e visualizzando il vento solare (il flusso di particelle cariche che viaggia a 400 km/s). Fissando i panni stesi e riflettendo sulle polarità opposte (orario/antiorario, destra/sinistra, apparenza/realtà), Ted collega la dichiarazione di Christy («la ragazza mora col biglietto del fidanzato») alla foto ricordo n. 2.903 e alle teorie scartate. All'improvviso intuisce il meccanismo dell'inganno: Salim non è svanito nel nulla; è uscito dalla cabina perfettamente visibile ma con un aspetto ingannevole che ha eluso lo sguardo di tutti.
- **Capitolo 33 (*Il rumore della tempesta*):** Ted rientra in casa, ma trova tutti immersi nel «rumore della tempesta» emotiva: Kat piange chiusa a chiave, la madre piange in cucina, zia Gloria giace addormentata dai sedativi stringendo una copia de *La tempesta* di Shakespeare (rievocando il figlio nei panni del principe Ferdinando). Ted cerca di annunciare la soluzione prima alla madre e poi a Rashid, ma viene ignorato e trattato come un'ombra trasparente. Comprende che nessun adulto in casa è disposto ad ascoltarlo: va in salotto, prende il biglietto da visita dell'ispettrice Pearce, blocca la mano tremante sotto la gamba e compone risolutamente il numero di Scotland Yard.

#### Soluzioni ed elementi chiave di correzione
- **1. Comprensione del Testo:**
  1. *La rivelazione di Christy e il nuovo vicolo cieco:* Christy dichiara di essere stato un semplice intermediario: ha ceduto il biglietto ricevuto da una sconosciuta in coda. La pista sembra fallire perché introduce una figura anonima e svanita nel traffico, lasciando i ragazzi senza nomi, indirizzi o punti di contatto utili.
  2. *La tempesta familiare al rientro:* La vista dei costumi asciutti fa crollare l'alibi della piscina. La lite mette a nudo l'esasperazione della madre (travolta dall'angoscia per il nipote e dal peso dell'ospitalità) e il senso di colpa di Kat, culminando nello schiaffo e nella chiusura ostile tra generazioni.
  3. *L'illuminazione razionale nel giardino:* Ted applica il principio della relatività della prospettiva: un oggetto può apparire stazionario o in moto a seconda del punto di osservazione. Ricordando che in cabina c'era una ragazza con un ragazzo e collegando le parole di Christy, Ted intuisce che Salim è sceso dalla cabina travestito o scambiato di ruolo: l'evaporazione era in realtà un gioco di illusionismo ottico e sociale.
  4. *Il richiamo de *La tempesta*:* La zia associa il figlio al principe Ferdinando della commedia shakespeariana, il naufrago creduto annegato nella tempesta ma in realtà vivo e nascosto sull'isola. La frase tocca Ted perché rinforza la certezza che la morte presunta di Salim sia solo un'illusione teatrale orchestrata ad arte.
  5. *La sordità degli adulti e la chiamata all'ispettrice:* Sopraffatti dal panico e dalle convenzioni sociali, i familiari considerano Ted un bambino incapace di pensiero autonomo. Rifiutando la rassegnazione, Ted aggira l'ostacolo domestico e contatta l'unica figura istituzionale che ne aveva riconosciuto l'intelligenza logica: l'ispettrice Pearce.
- **2. Vero o Falso:**
  1. **FALSO.** Christy dichiara di aver avuto il biglietto gratis da una giovane donna mora in coda al London Eye.
  2. **VERO.** Kat calpesta rabbiosamente la lattina vuota sul marciapiede gridando che la ricerca è stata solo un vicolo cieco.
  3. **FALSO.** La madre accoglie i figli con un'esplosione di collera e schiaffeggia Kat dopo aver scoperto la menzogna della piscina.
  4. **VERO.** Fissando il cielo e pensando alle particelle del vento solare, Ted comprende la combinazione ottica con cui Salim ha lasciato la ruota.
  5. **FALSO.** Lo zio Rashid è assente e disperato; saluta Ted distrattamente e lo ignora andando a bere in cucina.
- **3. Analisi dei Personaggi:**
  1. *La solitudine dell'ascolto nel «rumore della tempesta»:* L'immagine della tempesta illustra come le crisi emotive acute rendano le persone autoreferenziali e impermeabili ai fatti. Il dolore degli adulti si nutre di drammatizzazione e pianti, finendo per soffocare la voce calma della razionalità. Ted sperimenta la solitudine del testimone lucido, costretto a rompere il cerchio dell'incomunicabilità familiare.
  2. *L'autonomia decisionale e l'iniziativa civile:* La telefonata a Scotland Yard è l'atto fondativo della maturità di Ted. Vincere una fobia radicata (parlare al telefono con estranei) per salvare una vita dimostra che la determinazione etica può superare le barriere dell'ansia sociale, trasformando un ragazzo ritenuto "invalido" nel vero salvatore della famiglia.
- **4. Officina di Scrittura:** Criteri di valutazione: espressione vivida e accurata del flusso di coscienza di Ted; resa tangibile della percezione acustica del silenzio e del tempo che scorre; contrasto emotivo tra la frustrazione per l'indifferenza familiare e la risolutezza nel comporre il numero della detective.
- **5. Laboratorio Lessicale:** Combinazione corretta: `1-D, 2-B, 3-E, 4-C, 5-A`.
- **6. Attività Speciale:** Criteri di osservazione: correttezza dell'impaginazione giornalistica d'inchiesta; pertinenza e incisività dei quesiti rivolti all'Ispettrice Pearce; accuratezza dei riferimenti testuali alle telecamere CCTV e ai testimoni nel box informativo.

[[FINE]]
