[[FILE: blocco_05_esercizi.md]]
# SCHEDA DIDATTICA DI LETTURA E COMPRENSIONE
## *Il mistero del London Eye* di Siobhan Dowd
### Unità Didattica 5 (Blocco 5): *Un nuovo imbroglio* – *Le otto teorie*

---

> ### 🌊 Nell'occhio della tempesta alla ricerca di un metodo
> «Salim è uscito dalla capsula ma noi per sbaglio non l'abbiamo visto e lui non ha visto noi. Questo è ciò che pensano i genitori e la polizia. Ma noi crediamo che ci sia solo il due per cento di probabilità. [...] Ci sono otto teorie diverse. Una di esse deve essere corretta, a meno che non ci sia una teoria che mi sfugge.»  
> La sera scende su Londra e a casa Spark la disperazione lascia il posto a una calma fragile e carica di tensione: l'occhio del ciclone. Mentre gli adulti si rifugiano nei sedativi o si preparano allo scontro familiare per l'arrivo imminente del padre di Salim, nella penombra della camera da letto Ted e Kat danno inizio alla loro vera indagine. Applicando il pensiero laterale e una ferrea logica deduttiva, Ted detta alla sorella le sue celebri "Otto Teorie", aprendo la strada a un'intuizione formidabile che potrebbe cambiare tutto.

---

## 1. Comprensione del Testo

*Rispondi alle domande sul tuo quaderno in modo completo, motivando con riferimenti precisi al testo.*

1. **La probabilità matematica della fuga:** Durante il colloquio in giardino con il padre (Capitolo 12), Ted prova a quantificare il mistero di Salim attraverso percentuali statistiche (60/40 o 70/30 tra smarrimento e allontanamento volontario). Quali argomenti oppone il padre all'ipotesi che Salim sia scappato e come spiega l'espressione secondo cui madre e figlio sono legati da un affetto "stretto"?
2. **I limiti del codice delle emozioni:** Per decodificare le espressioni facciali altrui, Ted fa ricorso a uno schema rigido a cinque punti insegnatogli a scuola. Per quale motivo questo modello teorico fallisce nell'interpretare i comportamenti complessi di Salim e quale illuminante paragone propone Ted con la mescolanza dei colori primari e secondari?
3. **L'occhio del ciclone e l'ombra del padre:** Nel Capitolo 13, la quiete apparente di zia Gloria viene paragonata all'«occhio del ciclone». Quale violenta reazione esplode quando il padre di Ted telefona a Rashid a Manchester, e per quale motivo Gloria rifiuta con terrore l'arrivo dell'ex marito a Londra?
4. **La catalogazione delle Otto Teorie:** Nel Capitolo 14, Ted detta a Kat un elenco dettagliato di otto teorie per spiegare la scomparsa dalla capsula. In che modo queste ipotesi si suddividono tra scenari realistici, spiegazioni statistiche e teorie scientificamente bizzarre o fantascientifiche scartate dalla sorella?
5. **L'ispirazione della Nona Teoria:** Proprio mentre Kat esprime delusione per la fragilità delle otto teorie e teme di dover dare ragione alle conclusioni sbrigative della polizia, Ted ha una folgorazione («la Nona Teoria»). Come definisce Ted il concetto di «ispirazione» e quale evento improvviso impedisce la formulazione della nuova idea?

---

## 2. Vero o Falso? (Attenzione ai dettagli)

*Indica nella tabella se l'affermazione è Vera (V) o Falsa (F). Correggi e motiva sul tuo quaderno le affermazioni false.*

| Affermazione | V | F |
| :--- | :---: | :---: |
| 1. Per essere sicuro della precisione del proprio orologio da polso durante la gita, Ted ne ha verificato l'ora per ben cinque volte confrontandola con il Big Ben. | | |
| 2. Nella descrizione ufficiale fornita alla polizia, i familiari ricordano che al momento della salita Salim indossava una giacca di pelle nera, scarponi pesanti e una camicia a quadri. | | |
| 3. Avvisato telefonicamente della scomparsa del figlio, Rashid dichiara con freddezza di non voler intervenire ritenendo la madre l'unica responsabile dell'accaduto. | | |
| 4. Tra le otto teorie formulate da Ted, la quinta ipotesi prende in esame l'autocombustione umana spontanea, un fenomeno raro che il ragazzo paragona a un temporale circoscritto. | | |
| 5. Nella teoria numero 8, Ted ipotizza che Salim sia uscito dalla capsula mimetizzato sotto gli abiti di altri turisti, ispirandosi a una scena comica di Stanlio e Ollio nella Legione Straniera. | | |

---

## 3. Analisi dei Personaggi e Riflessione

*Rifletti sulle scelte e sulle emozioni dei protagonisti e rispondi sul quaderno.*

1. **La complessità delle relazioni familiari: vicinanza e combustione:** Il padre di Ted descrive il rapporto tra Gloria e il figlio come «stretto» ma al contempo «combustibile come il meteo». Come possono coesistere all'interno dello stesso nucleo affetti profondi e continui contrasti distruttivi? Quale riflessione propone il racconto sulle fatiche comunicative tra genitori separati e figli adolescenti?
2. **Il pensiero laterale come strumento investigativo:** Mentre gli adulti e le autorità accettano passivamente l'ipotesi più banale (che i ragazzi si siano semplicemente distratti tra la folla), Ted rifiuta le risposte superficiali e spinge la mente verso ipotesi insolite attraverso il pensiero laterale. Perché considerare anche le possibilità apparentemente assurde o estreme è una fase fondamentale del metodo scientifico per scoprire la verità?

---

## 4. Officina di Scrittura Creativa ed Empatia

*Mettiti nei panni di uno dei protagonisti e svolgi l'attività sul tuo quaderno.*

Immagina di essere **Kat** nel cuore della notte, seduta sul pavimento della stanza di Ted con in mano il foglio su cui hai appena finito di annotare le "Otto Teorie". La casa è avvolta nell'oscurità, zia Gloria riposa stordita dai sonniferi e tuo fratello ha appena annunciato con aria trionfante di avere una Nona Teoria, prima di essere interrotto dallo squillo improvviso del telefono.  
Scrivi una pagina del tuo **diario segreto**:
- Ripercorri l'elenco delle teorie dettate da Ted, raccontando l'oscillazione tra l'esasperazione per le sue idee strambe (come i viaggi nel tempo o l'autocombustione) e l'ammirazione segreta per la sua precisione metodica;
- Confessa l'angoscia che provi all'idea che zio Rashid stia per salire sul treno da Manchester, temendo il rancore e le recriminazioni che esploderanno tra gli adulti;
- Descrivi cosa provi nel trovarti improvvisamente a fare da "braccio operativo" e interprete terrena delle intuizioni scientifiche di tuo fratello.

---

## 5. Laboratorio Lessicale e Modi di Dire

*Associa ciascun vocabolo o espressione d'autore al suo significato nel contesto del racconto (indica sul quaderno la combinazione corretta numero-lettera).*

| Termine o Modo di Dire | Abbinamento | Significato Contestuale |
| :--- | :---: | :---: |
| 1. **Un nuovo imbroglio** | | A. Celebre battuta comica di una nota coppia cinematografica, divenuta locuzione comune per descrivere un guaio serio, confuso e di difficile soluzione. |
| 2. **Occhio del ciclone** | | B. Criterio logico e matematico impiegato nell'indagine deduttiva per misurare e ordinare il grado di plausibilità di ciascuna ipotesi formulata. |
| 3. **Spettro di probabilità** | | C. Intuizione intellettuale folgorante e improvvisa che affiora nella mente all'apparenza dal nulla, aprendo una via risolutiva a un problema complesso. |
| 4. **Autocombustione spontanea** | | D. Fase o punto di bonaccia transitoria e carica di quiete ingannevole situata al centro di una bufera emotiva, destinata a riprendere con violenza. |
| 5. **Ispirazione** | | E. Fenomeno ipotetico in cui un corpo vivente brucerebbe misteriosamente senza innesco esterno, scambiato popolarmente per un'evaporazione istantanea. |

---

## 6. Attività Speciale "Fuori dagli Schemi"

**Taccuino Tecnico e Scientifico: L'architettura e la dinamica del London Eye**  
Per comprendere l'enigma della sparizione di Salim è indispensabile analizzare con rigore le caratteristiche ingegneristiche dell'imponente struttura sul Tamigi, un'opera unica al mondo per concezione statica e meccanica.  
Realizza sul tuo quaderno una tavola monografica del tuo **Taccuino di Scienze e Tecnologia**:

1. **La Struttura Statica e i Pesi:**
   - Descrivi la configurazione a sbalzo (cantilever) ancorata al solo lato sud tramite l'imponente telaio ad "A", spiegando la differenza rispetto alle ruote sostenute da entrambi i lati;
   - Rappresenta lo schema dei cavi e tiranti d'acciaio che collegano il mozzo alla corona circolare, illustrando l'analogia con i raggi di una ruota da bicicletta.

2. **La Cinematica delle Capsule Sigillate:**
   - Illustra il montaggio esterno delle 32 cabine passeggeri (con una capacità di 25 persone ciascuna e peso di circa 10 tonnellate l'una);
   - Spiega il principio del bilanciamento gravitazionale e del controllo computerizzato che mantiene il pavimento delle capsule in perfetto piano orizzontale durante la rotazione;
   - Calcola la velocità lineare di avanzamento costante (circa 0,26 m/s, ossia meno di 1 km/h) e illustra perché consente l'imbarco continuo senza interruzioni.

3. **I Rilievi di Sicurezza e Flusso:**
   - Mappa i punti di visuale delle telecamere interne ed esterne e identifica i potenziali angoli morti durante il varco delle porte scorrevoli.

[SPAZIO PER IL TUO DISEGNO / RILIEVO GRAFICO]

---

### GUIDA E RIASSUNTO PER IL DOCENTE

#### Riassunto sintetico dei capitoli
I capitoli 12, 13 e 14 segnano il passaggio dall'incredulità passiva alla strutturazione logico-investigativa del caso:
- **Capitolo 12 (*Un nuovo imbroglio*):** Attraverso la sottile parete divisoria, in cucina si sentono i lamenti disperati di Gloria («Salim non scapperebbe mai da me!»). Kat piange convulsamente mentre il padre cerca goffamente di confortarla citando Stanlio e Ollio («Un altro bell'imbroglio»). Ted e il padre escono in giardino: Ted prova a calcolare razionalmente le probabilità tra allontanamento volontario e smarrimento accidentale (stimate 70 a 30 dal padre). Il padre analizza la natura ambivalente del rapporto tra Gloria e Salim: un legame strettissimo ma instabile e «combustibile» come l'aria prima di un temporale. Ted riflette sul proprio codice facciale a 5 punti insegnatogli a scuola (dal sorriso alla sorpresa), constatando come le micro-espressioni sfuggenti e contraddittorie di Salim non rientrino nei parametri base, proprio come i colori secondari nati dall'unione di tinte primarie.
- **Capitolo 13 (*L'occhio del ciclone*):** Richiamati in soggiorno, i ragazzi trovano Gloria sprofondata in una calma innaturale («l'occhio del ciclone»). L'ispettrice Pearce raccoglie la descrizione dettagliata dell'abbigliamento del ragazzo: felpa grigia col logo del Manchester United, jeans scuri, maglietta arancione vivo e scarpe sportive. Gloria ha un crollo emotivo, ricordando la nascita del figlio come unico raggio di luce della propria vita. Dopo la partenza della detective, il padre di Ted telefona a Manchester all'ex marito Rashid: sconvolto, l'uomo annuncia il suo arrivo immediato a Londra con il primo treno dell'alba. La reazione di Gloria è furiosa e disperata, temendo il giudizio e le accuse dell'uomo. Per la notte, la madre seda la sorella con dei sonniferi sistemandola nella camera di Kat, mentre quest'ultima riposa sul divano.
- **Capitolo 14 (*Le otto teorie*):** A tarda notte, Kat raggiunge furtivamente Ted nella sua stanza armata di taccuino. Di fronte al rischio che la polizia archivi il caso come un banale smarrimento tra la folla, Ted propone una rigorosa trattazione scientifica articolata in otto teorie: 1) Salim è rimasto nascosto sotto i sedili della cabina compiendo più giri; 2) L'orologio di Ted era sfasato (ipotesi esclusa: verificato 5 volte col Big Ben); 3) I ragazzi lo hanno mancato per una coincidenza sfortunata (stimata solo al 2%); 4) Salim ha evitato deliberatamente i cugini o è stato colto da amnesia/trauma cranico; 5) Autocombustione umana spontanea (teoria teorica da temporale locale); 6) Salim è uscito travestito; 7) Varco temporale o dimensione parallela (probabilità zero); 8) Salim è uscito occultato sotto gli abiti ampi di altri passeggeri (sul modello di Stanlio e Ollio in missione nella Legione Straniera). Mentre Kat scuote la testa per l'inadeguatezza dell'elenco, Ted annuncia con solennità di aver intuito la "Nona Teoria", la più brillante ed esatta di tutte. Ma prima che possa svelarla, il trillo improvviso del telefono squarcia il silenzio.

#### Soluzioni ed elementi chiave di correzione
- **1. Comprensione del Testo:**
  1. *La probabilità matematica della fuga:* Il padre considera poco verosimile una fuga deliberata in una metropoli sconosciuta, senza denaro sufficiente né appoggi logistici. Spiega che madre e figlio hanno un legame simbiotico («close»), dove litigi aspri e rivendicazioni verbali non cancellano una dipendenza affettiva fortissima, rendendo improbabile un abbandono pianificato.
  2. *I limiti del codice delle emozioni:* Lo schema standard (1. Molto felice, 2. Moderatamente allegro, 3. Contrariato/perplesso, 4. Arrabbiato, 5. Sorpreso) decodifica unicamente stati d'animo primari, statici e stereotipati. Salim esprime sentimenti complessi, contraddittori e mutevoli (ansia, nostalgia, ribellione, affetto, sarcasmo) che si fondono simultaneamente, proprio come il giallo e il blu generano il verde.
  3. *L'occhio del ciclone e l'ombra del padre:* L'annuncio dell'arrivo di Rashid rompe la calma apparente. Gloria reagisce con terrore perché l'ex marito rappresenta il fallimento del suo progetto genitoriale e familiare: la donna teme di essere accusata di negligenza e incapacità protettiva, vedendo riaffiorare i risentimenti del divorzio mai elaborato.
  4. *La catalogazione delle Otto Teorie:* L'elenco si articola su tre registri: a) Teorie empiriche e verificabili (1, 2, 3, 4: permanenza nella cabina, sfasamento orario, errore visivo, amnesia); b) Teorie basate sull'inganno o mimetismo (6 e 8: travestimento, occultamento sotto abiti altrui); c) Teorie parascientifiche o fantastiche (5 e 7: autocombustione, salto quantico/temporale), inserite da Ted per completezza tassonomica ma scartate come irricevibili sul piano della probabilità.
  5. *L'ispirazione della Nona Teoria:* Ted definisce l'ispirazione come una folgorazione logica improvvisa, un pensiero inedito che sembra soffiare nella mente dall'esterno ma che in realtà è il prodotto di un'inconscia elaborazione dei dati reali. La rivelazione viene bruscamente interrotta dallo squillo del telefono di casa nel cuore della notte.
- **2. Vero o Falso:**
  1. **VERO.** Nel testo della teoria n. 2 si precisa che Ted ha sincronizzato l'orologio cinque volte sul Big Ben per azzerare lo scarto cronometrico.
  2. **FALSO.** La descrizione comprende felpa grigia con cappuccio del Manchester United, jeans scuri, maglietta arancione e scarpe da ginnastica.
  3. **FALSO.** Rashid si dimostra sconvolto e premuroso, partendo all'istante con il primo convoglio ferroviario per prestare soccorso.
  4. **VERO.** Ted include la combustione spontanea nella teoria n. 5 correlandola a fenomeni atmosferici rari.
  5. **VERO.** Ted cita espressamente il film natalizio *The Flying Deuces* (*I diavoli volanti*) con Stan Laurel e Oliver Hardy.
- **3. Analisi dei Personaggi:**
  1. *La complessità delle relazioni familiari: vicinanza e combustione:* L'analogia meteorologica del padre mostra che l'intimità familiare non è sempre sinonimo di armonia serena. Nelle famiglie segnate da rotture traumatiche, l'affetto viscerale si manifesta spesso attraverso attriti continui («combustione»): l'adolescente cerca l'emancipazione provocando il genitore, mentre il genitore riversa sul figlio ansie di controllo. La comprensione di queste dinamiche è indispensabile per non liquidare la scomparsa come una semplice marachella.
  2. *Il pensiero laterale come strumento investigativo:* Il metodo scientifico autentico non si limita a confermare le tesi più probabili o comode, ma richiede di testare metodicamente ogni ipotesi scartando ciò che è impossibile. Ted insegna che anche le ipotesi bizzarre (l'occultamento o il travestimento) contengono frammenti di verità logica (il fatto che Salim non possa essere uscito con le sue sembianze ordinarie), guidando l'intelletto verso la soluzione reale attraverso strade non battute.
- **4. Officina di Scrittura:** Criteri di valutazione: originalità e vivacità della voce interiore di Kat; capacità di descrivere l'ambivalenza emotiva tra derisione e rispetto per le teorie di Ted; espressione verosimile del timore per l'arrivo dello zio paterno da Manchester; consapevolezza del proprio ruolo di mediazione pratica nell'indagine.
- **5. Laboratorio Lessicale:** Combinazione corretta: `1-A, 2-D, 3-B, 4-E, 5-C`.
- **6. Attività Speciale:** Criteri di osservazione: accuratezza terminologica e concettuale dei principi costruttivi a sbalzo; precisione nella descrizione dei meccanismi di orientamento orizzontale continuo delle capsule; qualità, chiarezza e rigore geometrico del rilievo grafico sul taccuino tecnico.

[[FINE]]
