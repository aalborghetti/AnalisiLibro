[[FILE: blocco_11_esercizi.md]]
# SCHEDA DIDATTICA DI LETTURA E COMPRENSIONE
## *Il mistero del London Eye* di Siobhan Dowd
### Unità Didattica 11 (Blocco 11): *Fumo* – *Salim il magnifico*

---

> ### 🌊 Quando la maschera cade sul binario della stazione
> «L'ispettrice Pearce entrò guidando un ragazzo con il cappuccio della felpa tirato sulla testa. "Tu!" ansimò zia Gloria. "Ciao, Marcus", dissi io. [...] Il trucco era la parrucca e la giacca rosa. Salim era sceso dalla ruota travestito da ragazza. Era passato sotto il nostro naso e noi non l'avevamo riconosciuto.»  
> La verità bussa alla porta di casa Spark scortata dalla polizia. Grazie alla telefonata segreta di Ted, l'ispettrice Pearce rintraccia a Manchester Marcus Flood, l'amico del cuore di Salim e fratello minore di Christy. Davanti alla famiglia riunita in un silenzio di piombo, cade finalmente il velo sull'enigma della capsula: un audace cambio d'abito in volo e una parrucca castana avevano trasformato Salim in una ragazza qualunque sfuggita allo sguardo di tutti. Ma la lettura della confessione scritta di Marcus gela il sangue: dopo un'intera giornata di festa clandestina per le strade di Londra, Salim ha rifiutato di fuggire a Manchester ed è salito sul treno verso casa... senza mai arrivarvi.

---

## 1. Comprensione del Testo

*Rispondi alle domande sul tuo quaderno in modo completo, motivando con riferimenti precisi al testo.*

1. **La promessa nel fumo di sigaretta:** Nel Capitolo 34, durante la cena a base di cibo indiano da asporto, zia Gloria lascia consumare l'ennesima sigaretta senza fumarla. Quale promessa solenne fa a Ted e alla famiglia nel caso in cui Salim ritorni sano e salvo, e cosa rivela questo momento sulla sua disperata vulnerabilità?
2. **L'identità svelata del complice:** Alla fine del Capitolo 35, l'ispettrice Pearce entra in casa scortando un ragazzo col cappuccio calato sul volto. Chi è questo giovane e quale legame di parentela lo unisce a Christy, la guardia della Frontline Security?
3. **La dinamica dell'illusione ottica:** Nel Capitolo 36, Ted espone a tutti la sua brillante ricostruzione deduttiva. Come hanno fatto Salim e Marcus a realizzare l'invisibilità apparente all'uscita dalla capsula del London Eye? In che modo la parrucca e la giacca rosa di Shannon hanno ingannato la vista di Ted e Kat?
4. **L'ultimo giorno di libertà a Londra:** Dalla confessione scritta di Marcus (Capitolo 37), quali attività hanno condiviso i due amici per festeggiare la loro ribellione (il rullino usa e getta, i musicisti di strada, i pianoforti elettrici)? Perché questa giornata rappresentava per entrambi un rito d'addio irripetibile?
5. **Il dilemma morale alla stazione di Euston:** Arrivati davanti ai binari della stazione ferroviaria di Euston, per quale motivo Salim rifiuta categoricamente di salire sul treno per Manchester con Marcus, decidendo di tornare dagli zii? Quale nuovo e angoscioso interrogativo si apre subito dopo la lettura della confessione?

---

## 2. Vero o Falso? (Attenzione ai dettagli)

*Indica nella tabella se l'affermazione è Vera (V) o Falsa (F). Correggi e motiva sul tuo quaderno le affermazioni false.*

| Affermazione | V | F |
| :--- | :---: | :---: |
| 1. Marcus Flood è il compagno di scuola di Manchester con cui Salim aveva recitato nella commedia *La tempesta* ed è il fratello minore della guardia giurata Christy. | | |
| 2. Durante la permanenza nella capsula del London Eye, Salim è rimasto nascosto nel condotto di aerazione del soffitto fino alla chiusura serale dell'impianto. | | |
| 3. Ted riesce a far localizzare Marcus spiegando alla detective Pearce il trucco del travestimento e spingendo la polizia di Manchester a perquisire la camera dell'amico. | | |
| 4. Nel suo verbale scritto, Marcus ammette di aver costretto Salim con minacce e violenza fisica a fuggire e di averlo poi abbandonato in una fabbrica dismessa. | | |
| 5. Dopo essersi separato da Marcus alla stazione di Euston per tornare a casa Spark, Salim svanisce nuovamente senza arrivare mai a destinazione. | | |

---

## 3. Analisi dei Personaggi e Riflessione

*Rifletti sulle scelte e sulle emozioni dei protagonisti e rispondi sul quaderno.*

1. **La lealtà tra pari e il senso di responsabilità filiale:** Salim architetta una beffa grandiosa per regalarsi un giorno di evasione con Marcus prima dell'esilio a New York, ma davanti al treno sceglie di rinunciare alla fuga per non gettare nella disperazione la madre e non far punire Kat e Ted. Cosa rivela questo ripensamento sulla maturità etica di Salim e sulla complessità del suo carattere, diviso tra ribellione e profondo affetto?
2. **Il trionfo della mente atipica di Ted:** Gli adulti e le forze dell'ordine cercavano rapitori spietati o cadaveri nel fiume, lasciandosi sviare dai propri pregiudizi. Ted, grazie al suo "sistema operativo" privo di preconcetti sociali, ha decifrato l'enigma come un puro problema geometrico di scambio e rifrazione. Quale lezione pedagogica offre questo snodo narrativo sul valore inclusivo della neurodiversità nei processi di indagine e problem solving?

---

## 4. Officina di Scrittura Creativa ed Empatia

*Mettiti nei panni di uno dei protagonisti e svolgi l'attività sul tuo quaderno.*

Immagina di essere **Marcus Flood** mentre scrivi di tuo pugno la dichiarazione per Scotland Yard nella cucina di casa Spark, sotto gli occhi severi dell'Ispettrice Pearce e lo sguardo sbigottito di zia Gloria e dei cugini.  
Scrivi una pagina del tuo **diario personale** o una memoria difensiva:
- Racconta il rimorso lacerante per aver trasformato una bravata tra compagni di scuola in un incubo nazionale, spiegando l'affetto fraterno che ti legava a Salim e il desiderio di regalargli un ultimo giorno indimenticabile;
- Descrivi cosa hai provato quando Salim, sul marciapiede della stazione di Euston, ti ha abbracciato rifiutandosi di salire sul treno per proteggere sua madre e i suoi cugini;
- Esprimi la tua disperazione nel non sapere dove sia finito Salim dopo quel saluto sul binario, implorando Ted di usare la sua mente straordinaria per ritrovarlo prima che sia troppo tardi.

---

## 5. Laboratorio Lessicale e Modi di Dire

*Associa ciascun vocabolo o espressione d'autore al suo significato nel contesto del racconto (indica sul quaderno la combinazione corretta numero-lettera).*

| Termine o Modo di Dire | Abbinamento | Significato Contestuale |
| :--- | :---: | :---: |
| 1. **Travestimento** | | A. Termine colloquiale che definisce gli intrattenitori e artisti urbani che offrono spettacoli musicali e circensi all'aperto nelle piazze. |
| 2. **Artisti di strada** | | B. Locuzione figurata usata per paragonare le capacità, l'audacia o il valore di un individuo a quelli di un modello di riferimento ritenuto irraggiungibile. |
| 3. **Ritirata del treno** | | C. Artificio visivo, scenico e sartoriale impiegato per alterare radicalmente i tratti esteriori di una persona ingannando il riconoscimento oculare. |
| 4. **Essere all'altezza** | | D. Espressione metaforica (*being let down*) che descrive il doloroso crollo psicologico provocato dalla smentita improvvisa di un'aspettativa carica di speranze. |
| 5. **Essere delusi** | | E. Piccolo vano igienico di un convoglio ferroviario impiegato clandestinamente come nascondiglio per viaggiare senza titolo di viaggio. |

---

## 6. Attività Speciale "Fuori dagli Schemi"

**Taccuino Tecnico e Architettonico: Il Cantiere di Barrington Heights ("Il Casermone")**  
La confessione di Marcus svela che Salim è scomparso dopo essersi allontanato da Euston. Nei pensieri dei ragazzi riaffiora l'ossessione del cugino per l'architettura monumentale e per Barrington Heights, il grattacielo di 24 piani in cui lavora il padre di Ted, destinato a essere demolito con le cariche esplosive all'alba seguente.  
Realizza sul tuo quaderno una tavola monografica del tuo **Taccuino di Ingegneria e Tecnica Edile**:

1. **La Struttura Architettonica del Casermone:**
   - Tipologia costruttiva: torre residenziale intensiva in cemento armato a 24 piani, costruita negli anni Sessanta e dichiarata inagibile per degrado strutturale;
   - I punti ciechi dell'edificio: gli alloggi murati, i condotti dell'immondizia dismessi, le scale antincendio e il tetto panoramico accessibile solo dai lucernari.

2. **La Dinamica dell'Implosione Controllata:**
   - Illustra il lavoro di un esperto di demolizioni (la professione del padre di Ted);
   - Spiega la disposizione delle micro-cariche di dinamite sui pilastri portanti inferiori e il collasso per gravità verso l'interno (implosione) per proteggere il quartiere circostante;
   - Disegna la sequenza temporale del cantiere: l'intervento dei frantumatori idraulici e delle ruspe previsto per l'indomani mattina.

3. **La Mappa dei Varchi e dei Piani Superiori:**
   - Disegna la sezione verticale schematica della torre con i 24 livelli;
   - Evidenzia le transenne di sicurezza perimetrali e l'ultimo piano residenziale (il 24° piano), punto panoramico più alto del distretto.

[SPAZIO PER IL TUO DISEGNO / RILIEVO GRAFICO]

---

### GUIDA E RIASSUNTO PER IL DOCENTE

#### Riassunto sintetico dei capitoli
I capitoli 34–37 costituiscono il momento culmine dello svelamento razionale del mistero della ruota:
- **Capitolo 34 (*Fumo*):** Martedì sera. Cena a base di cibo indiano; l'atmosfera è plumbea e il cibo resta intatto nei piatti. Gloria guarda consumarsi la sigaretta e promette solennemente che smetterà di fumare per sempre se Salim tornerà vivo. Poi esplode nell'ennesima crisi d'angoscia, accusando i presenti di credere che il figlio sia fuggito per colpa sua. Ted tace sulla telefonata alla polizia per non alimentare false speranze.
- **Capitolo 35 (*Ancora il ragazzo sul treno*):** Il campanello interrompe la tensione: è l'ispettrice Pearce, accompagnata da un ragazzo con la felpa a cappuccio. Gloria sobbalza: è Marcus Flood, il compagno di scuola di Manchester di Salim. Ted lo saluta con calma: «Ciao, Marcus».
- **Capitolo 36 (*Indagine meteorologica*):** Ted espone alla famiglia la ricostruzione che ha consegnato alla polizia: Salim e Marcus avevano architettato un piano per trascorrere insieme un'ultima giornata di libertà prima del trasferimento in America. Sapendo che il fratello di Marcus, Christy, lavorava per la Frontline Security, lo avevano coinvolto per cedere il biglietto alla coda. Nella capsula, Marcus aveva passato a Salim una parrucca castana e la giacca rosa confetto della sorella Shannon: Salim è sbarcato alle 12:02 vestito da ragazza, passando indisturbato accanto a Ted e Kat. La polizia ha perquisito la casa di Marcus a Manchester trovando il cellulare di Salim sotto il materasso.
- **Capitolo 37 (*Salim il magnifico*):** L'ispettrice legge la confessione autografa di Marcus: i due ragazzi hanno vissuto una giornata spensierata tra busker, fotografie sul Tamigi e negozi di musica. Arrivati a Euston, Marcus voleva che Salim salisse sul treno per Manchester, ma Salim si è rifiutato categoricamente: per senso di lealtà verso la madre e per non far passare guai ai cugini Ted e Kat, ha deciso di tornare a casa Spark. Marcus è salito sul treno portando con sé la giacca rosa (in cui era rimasto il telefono di Salim). La confessione si chiude con una rivelazione scioccante: Marcus ha visto Salim per l'ultima volta sul marciapiede della stazione di Euston mentre il treno partiva. Salim intendeva tornare a casa, ma non è mai arrivato.

#### Soluzioni ed elementi chiave di correzione
- **1. Comprensione del Testo:**
  1. *La promessa nel fumo di sigaretta:* Gloria promette di rinunciare al fumo se il figlio tornerà incolume. Il gesto rivela il suo voto interiore di espiazione: la donna comprende che il proprio egoismo e la propria nevrosi hanno contribuito all'allontanamento del figlio ed è pronta a sacrificare le proprie abitudini pur di riabbracciarlo.
  2. *L'identità svelata del complice:* Il ragazzo è Marcus Flood, compagno di scuola di Salim a Manchester e co-protagonista della recita scolastica. È il fratello minore di Christy, la guardia giurata della Frontline Security immortalata nelle fotografie del London Eye.
  3. *La dinamica dell'illusione ottica:* Salim è salito a bordo come un ragazzo con felpa grigia e maglietta arancione; a bordo ha indossato una parrucca castana e la giacca rosa di Shannon, uscendo a braccetto con Marcus come una coppia di turisti qualunque. Ted e Kat cercavano un ragazzo asiatico e il loro cervello ha scartato la figura femminile in rosa, cadendo nella trappola del preconcetto visivo.
  4. *L'ultimo giorno di libertà a Londra:* I due amici hanno visitato i parchi del Tamigi, scattato foto ricordo, ascoltato saltimbanchi e suonato pianoforti elettrici a Tottenham Court Road. La giornata era un rito di congedo dall'infanzia e dalla loro amicizia prima dello sradicamento verso New York.
  5. *Il dilemma morale alla stazione di Euston:* Davanti al treno, Salim capisce che fuggire a Manchester distruggerebbe sua madre e farebbe ricadere colpe ingiuste sui cugini Ted e Kat. Sceglie la responsabilità filiale e decide di rientrare; tuttavia, il fatto che non sia mai giunto a destinazione riapre il terrore di un incidente occorso lungo la strada.
- **2. Vero o Falso:**
  1. **VERO.** Marcus è l'amico del cuore di Manchester nonché fratello minore di Christy.
  2. **FALSO.** Salim ha scambiato i propri vestiti nella cabina indossando la parrucca e la giacca rosa di Shannon.
  3. **VERO.** Ted ha illustrato la dinamica all'ispettrice Pearce, che ha fatto perquisire l'abitazione di Marcus trovando il telefono di Salim.
  4. **FALSO.** Marcus dichiara che la fuga era un piano concordato e che Salim si è separato volontariamente a Euston per tornare dagli zii.
  5. **VERO.** La dichiarazione certifica che Marcus lo ha visto l'ultima volta sul marciapiede di Euston e da quel momento il ragazzo è scomparso.
- **3. Analisi dei Personaggi:**
  1. *La lealtà tra pari e il senso di responsabilità filiale:* Il rifiuto di salire sul treno a Euston nobilita la figura di Salim. La sua ribellione non nasceva dall'odio verso la famiglia, ma dal bisogno disperato di vivere un momento di autodeterminazione. Di fronte al bivio tra la fuga egoistica e il dovere verso chi lo ama, sceglie il sacrificio personale, dimostrando una statura morale superiore a quella degli adulti che lo circondavano.
  2. *Il trionfo della mente atipica di Ted:* Ted risolve l'enigma perché non cerca moventi psicologici o drammatici, ma analizza i fatti fisici come variabili di un sistema logico. La sua capacità di osservare l'assenza di simmetria e di collegare indizi eterogenei (le parole di Christy, i colori degli abiti, il teatro) dimostra che la neurodivergenza è una risorsa cognitiva preziosa, capace di superare la cecità del pensiero convenzionale.
- **4. Officina di Scrittura:** Criteri di valutazione: resa credibile della voce tormentata di Marcus (registro giovanile e sincero); espressione del senso di colpa per aver partecipato alla beffa; rievocazione toccante dell'addio a Euston; appello disperato alle capacità di Ted per localizzare l'amico.
- **5. Laboratorio Lessicale:** Combinazione corretta: `1-C, 2-A, 3-E, 4-B, 5-D`.
- **6. Attività Speciale:** Criteri di osservazione: correttezza terminologica e ingegneristica nella descrizione della torre a 24 piani; precisione tecnica nella spiegazione dei principi di demolizione e implosione gravitazionale; accuratezza del rilievo della sezione verticale con i varchi e i piani superiori.

[[FINE]]
