[[FILE: blocco_06_esercizi.md]]
# SCHEDA DIDATTICA DI LETTURA E COMPRENSIONE
## *Il mistero del London Eye* di Siobhan Dowd
### Unità Didattica 6 (Blocco 6): *Infinito* – *Il fulmine colpisce*

---

> ### 🌊 Tra l'ombra della morte e la luce di un rullino
> «La morte. Capii che era reale. Un giorno sarei morto anch'io. Kat sarebbe morta. Mamma sarebbe morta. Papà sarebbe morto. Zia Gloria sarebbe morta. [...] La vita è come una semiretta in geometria: parte dalla nascita e prosegue verso l'infinito.»  
> Una drammatica telefonata nel cuore della notte trascina la famiglia Spark nel baratro: un corpo senza vita è stato ripescato nel Tamigi. Ma il sollievo per lo scampato pericolo dura poco. Con l'arrivo da Manchester di Rashid, il padre di Salim, riaffiorano rancori mai sopiti e la verità sembra allontanarsi. Mentre il cielo si carica di elettricità annunciando un violento temporale, Kat e Ted passano all'azione: con un piano audace e rischioso, riescono a sviluppare in segreto il rullino della macchina fotografica di Salim.

---

## 1. Comprensione del Testo

*Rispondi alle domande sul tuo quaderno in modo completo, motivando con riferimenti precisi al testo.*

1. **La telefonata dall'obitorio:** Nella notte tra lunedì e martedì, la polizia informa del ritrovamento del corpo di un giovane ragazzo asiatico nei pressi del fiume. Quale sconvolgimento emotivo provoca la notizia su zia Gloria e su quale profonda riflessione geometrica e filosofica sulla Morte e sull'«Infinito» conduce la mente di Ted durante i 54 interminabili minuti di attesa del padre?
2. **L'arrivo di Rashid e i due fuochi del conflitto:** Nel Capitolo 16 fa il suo ingresso a Londra Rashid, il padre di Salim. Quale contrasto emerge tra il suo contegno dignitoso e affettuoso e l'atteggiamento difensivo di zia Gloria? Di che cosa continuano ad accusarsi reciprocamente i due genitori anche nel culmine dell'angoscia?
3. **Lo stratagemma del rullino fotografico:** Prima di recarsi nuovamente al London Eye insieme al padre, Kat si ferma con un pretesto in un negozio di fotografia del centro commerciale. Quale operazione segreta compie all'insaputa degli adulti e perché quel rullino costituisce il cuore dell'indagine autonoma dei due fratelli?
4. **La verifica sperimentale della Teoria n. 1:** Salendo per la seconda volta sulla ruota panoramica con il padre, in quale modo Kat e Ted verificano l'ipotesi che Salim sia rimasto nascosto sotto i sedili per compiere più giri consecutivi? Quale rigida procedura di sicurezza del personale porta allo smantellamento definitivo di questa teoria?
5. **La metafora dei cormorani sul Tamigi:** Passeggiando lungo il fiume poco prima dello scoppio del temporale, il padre indica a Ted due cormorani che si immergono, spariscono a lungo nei flutti e riemergono a grande distanza. Quale valore simbolico assume questo dettaglio naturale rispetto alla speranza di ritrovare Salim sano e salvo?

---

## 2. Vero o Falso? (Attenzione ai dettagli)

*Indica nella tabella se l'affermazione è Vera (V) o Falsa (F). Correggi e motiva sul tuo quaderno le affermazioni false.*

| Affermazione | V | F |
| :--- | :---: | :---: |
| 1. Il corpo del ragazzo asiatico ritrovato sulle rive del Tamigi appartiene a Salim, spingendo la polizia a dichiarare ufficialmente chiuse le indagini. | | |
| 2. Durante i 54 minuti in cui il padre è all'obitorio per il riconoscimento, Kat dà prova di grande coraggio preparando il tè per tutti nonostante le mani le tremino visibilmente. | | |
| 3. Rashid si presenta a casa Spark vestito con un elegante completo scuro e cravatta, mantenendo un atteggiamento pacato e rispettoso verso tutta la famiglia. | | |
| 4. Durante il secondo giro sul London Eye, Kat e Ted scoprono che è estremamente facile eludere i controlli e nascondersi sotto i sedili della capsula senza essere notati dal personale. | | |
| 5. Uscendo dal negozio dopo il temporale, Kat mostra trionfante al padre sia la bottiglia di olio rilassante per la zia sia la busta con le ventuno fotografie appena sviluppate. | | |

---

## 3. Analisi dei Personaggi e Riflessione

*Rifletti sulle scelte e sulle emozioni dei protagonisti e rispondi sul quaderno.*

1. **La Morte come retta verso l'Infinito:** Durante l'attesa notturna del verdetto dell'obitorio, Ted sperimenta per la prima volta la vertigine dell'effimero, contrapponendo la perfetta ciclicità chiusa della ruota del London Eye alla retta geometrica dell'esistenza umana, che ha un punto d'origine e prosegue verso l'ignoto. In che modo il pensiero scientifico e astratto consente a Ted di metabolizzare la paura del lutto e della perdita?
2. **La complicità clandestina tra fratelli:** Nel corso della giornata, Kat e Ted agiscono come una vera squadra investigativa all'insaputa del padre: Kat gestisce le relazioni sociali, la dissimulazione e le azioni sul campo (lo sviluppo rapido e l'alibi dell'olio da bagno), mentre Ted osserva i dettagli impercettibili (la scansione delle cabine, la busta che spunta dalla tasca). In che modo le diverse abilità dei due fratelli si completano a vicenda colmando le rispettive debolezze?

---

## 4. Officina di Scrittura Creativa ed Empatia

*Mettiti nei panni di uno dei protagonisti e svolgi l'attività sul tuo quaderno.*

Immagina di essere **Rashid**, il padre di Salim, nel momento in cui, dopo il temporale pomeridiano, rimani solo per qualche minuto nella cucina di casa Spark mentre gli altri cercano di far riposare Gloria. Hai appena attraversato l'Inghilterra in treno col cuore in gola, hai riabbracciato la tua ex moglie tra lacrime e vecchi rancori, e il vuoto lasciato da tuo figlio ti sembra incolmabile.  
Scrivi una pagina del tuo **diario intimo**:
- Ripercorri il senso di colpa per non essere stato presente a Londra per proteggere Salim e il dolore per i conflitti familiari che hanno spinto Gloria a voler fuggire in America;
- Racconta cosa hai letto negli sguardi dei tuoi nipoti, Ted e Kat, intuendo che dietro il loro silenzio si muove qualcosa che gli adulti, troppo accecati dal panico, non riescono a comprendere;
- Spiega perché ti aggrappi disperatamente alla speranza che tuo figlio sia come i cormorani del Tamigi, capace di riemergere vivo e fiero dalle profondità della metropoli.

---

## 5. Laboratorio Lessicale e Modi di Dire

*Associa ciascun vocabolo o espressione d'autore al suo significato nel contesto del racconto (indica sul quaderno la combinazione corretta numero-lettera).*

| Termine o Modo di Dire | Abbinamento | Significato Contestuale |
| :--- | :---: | :---: |
| 1. **Semiretta verso l'infinito** | | A. Modo di dire colloquiale per sollecitare qualcuno ad affrettarsi o ad accelerare il passo, fondato sull'immagine stravagante di scuotere una gamba correndo. |
| 2. **Okta** | | B. Scarica elettrica temporalesca che si diffonde all'interno della nube illuminando il cielo con un bagliore uniforme, senza saette visibili dirette a terra. |
| 3. **Piovere gatti e cani** | | C. Concetto geometrico unidirezionale dotato di un punto di origine preciso ma privo di termine, assunto come metafora della traiettoria della vita umana. |
| 4. **Fulmine a lamina** | | D. Unità di misura convenzionale impiegata in meteorologia per quantificare in ottavi la frazione di volta celeste oscurata dalla copertura nuvolosa. |
| 5. **Darsi una mossa** | | E. Espressione idiomatica tipica anglosassone (*raining cats and dogs*) usata per descrivere un rovescio d'acqua violentissimo e torrenziale. |

---

## 6. Attività Speciale "Fuori dagli Schemi"

**Codice Segreto e Simbologia: La Decifrazione degli Scatti di Salim**  
Alla fine del Blocco 6, Kat tiene nascosta nella giacca la busta con le ventuno fotografie sviluppate: una sequenza visiva che custodisce la chiave per comprendere come e con chi Salim abbia lasciato il London Eye.  
Vesti i panni di un analista forense e realizza sul tuo quaderno una tavola di **Decifrazione Simbolica dei Fotogrammi**:

1. **La Striscia dei Fotogrammi Chiave (Timeline Visiva):**
   - Disegna la sagoma di una pellicola fotografica a 4 fotogrammi successivi (il ponte sul Tamigi, la vista della ruota, la coda dei biglietti, il momento dell'imbarco delle 11:32);
   - Assegna a ogni fotogramma un **emblema o simbolo cifrato** (es. l'occhio panoramico, la cravatta scolastica di Ted, la tazza da asporto del donatore del biglietto, la sagoma del cormorano).

2. **Il Cifrario Investigativo a Sostituzione:**
   - Elabora una chiave cifrata basata sui parametri del meteo e sui numeri d'ordine delle foto (es. cifrario di Cesare o trasposizione alfabetica) per codificare il messaggio segreto che Ted intende trasmettere a Kat: «FOTOGRAMMA 21 - ANALIZZA IL CONTROLUCE»;
   - Trascrivi il testo in chiaro e la sua versione in codice segreto.

3. **Il Rilievo Grafico del Fotogramma Indiziario:**
   - Disegna la simulazione dello scatto numero 21: la prospettiva di Salim in coda, l'ombra del donatore del biglietto e i dettagli apparentemente insignificanti sullo sfondo (la banchina, l'insegna, le sagome degli altri passeggeri).

[SPAZIO PER IL TUO DISEGNO / RILIEVO GRAFICO]

---

### GUIDA E RIASSUNTO PER IL DOCENTE

#### Riassunto sintetico dei capitoli
I capitoli 15, 16 e 17 costituiscono il culmine del primo ciclo di indagini e l'acquisizione delle prove decisive:
- **Capitolo 15 (*Infinito*):** Notte fonda. Una chiamata di Scotland Yard getta la casa nel terrore: è stato rinvenuto il corpo senza vita di un ragazzo asiatico vicino al London Eye. Gloria ha un collasso vomitando sul tappeto; il padre corre all'obitorio per il riconoscimento, mentre Kat mostra una sorprendente fermezza preparando il tè per sostenere la zia. Nei 54 minuti di attesa straziante (3.240 secondi), Ted elabora la percezione relativistica del tempo nel dolore e affronta per la prima volta la nozione geometrica della Morte: diversamente dal cerchio chiuso della ruota, la vita è una semiretta che parte dalla nascita e si estende verso l'infinito. Al rientro, il padre comunica con immenso sollievo che il defunto non è Salim, bensì un fuggiasco proveniente da Southall.
- **Capitolo 16 (*Copertura nuvolosa*):** Martedì 25 maggio. Il cielo è saturo di nubi minacciose (8 okta, imminente instabilità temporalesca). Dalla stazione giunge Rashid, padre di Salim: uomo colto, elegante e dai modi composti, che abbraccia commosso Gloria. La tregua dura poco: tra i due riesplodono recriminazioni velenose sul divorzio e sul trasferimento forzato a New York. Kat e Ted approfittano del confronto tra adulti per chiedere al padre di riportarli sul South Bank per ripercorrere i luoghi della sparizione. Durante il tragitto, Kat entra furtivamente in un laboratorio del centro commerciale e consegna il rullino della macchina di Salim per uno sviluppo urgente a pagamento rapido (ritiro fissato alle 15:30).
- **Capitolo 17 (*Il fulmine colpisce*):** Kat, Ted e il padre salgono nuovamente sul London Eye. I ragazzi ne approfittano per testare sperimentalmente la Teoria 1 (Salim nascosto sotto i sedili per compiere un secondo giro): Kat si china simulando di aver smarrito un oggetto, ma un addetto interviene tempestivamente ripulendo la cabina. La teoria n. 1 viene così definitivamente smentita: i controlli serrati impediscono a chiunque di rimanere a bordo. Scesi dalla ruota, acquistano la foto ricordo (n. 2.903) e passeggiano lungo il Tamigi; il padre indica due cormorani che s'immergono per riapparire a decine di metri di distanza, metafora vivente della speranza che Salim sia ancora vivo. Scoppia un violento temporale con fulmini a lamina e pioggia torrenziale. Rientrati al centro commerciale per ripararsi, Kat compra dell'olio da bagno come regalo per la zia e recupera la busta con le ventuno foto sviluppate, nascondendola nella giacca sotto lo sguardo complice di Ted.

#### Soluzioni ed elementi chiave di correzione
- **1. Comprensione del Testo:**
  1. *La telefonata dall'obitorio:* La notizia scatena una reazione fisica incontrollabile in Gloria (nausea, tremiti, disperazione isterica). Ted razionalizza l'angoscia cronometrando i 3.240 secondi di assenza del padre e approda a una consapevolezza esistenziale: la Morte cancella l'illusione della reversibilità; la vita non è un'orbita circolare che torna al punto di partenza (come il London Eye), ma un vettore geometrico unidirezionale che si spegne nell'infinito.
  2. *L'arrivo di Rashid e i due fuochi del conflitto:* Rashid incarna la misura, il rigore e la dignità affettiva; Gloria reagisce con ostilità isterica per mascherare il proprio senso di colpa. Il contrasto mette a nudo l'irrisolto rancore coniugale: Gloria accusa Rashid di aver trascurato la famiglia, mentre Rashid rimprovera a Gloria di aver voluto recidere le radici del figlio per pura vanità professionale.
  3. *Lo stratagemma del rullino fotografico:* Kat approfitta della distrazione del padre per consegnare il rullino a un servizio di sviluppo celere in un'ora. La pellicola è cruciale perché contiene gli scatti eseguiti da Salim e Ted prima della salita: i ragazzi sanno che l'obiettivo potrebbe aver immortalato involontariamente dettagli invisibili a occhio nudo (il volto dello sconosciuto, orari, persone sospette).
  4. *La verifica sperimentale della Teoria n. 1:* Kat e Ted salgono sulla capsula e simulano la ricerca di un oggetto caduto sotto i divanetti. L'ispezione immediata e meticolosa degli operatori della sicurezza, che spazzano il pavimento a ogni attracco, dimostra che nessuno avrebbe potuto rimanere nascosto per un secondo giro senza essere espulso.
  5. *La metafora dei cormorani sul Tamigi:* I cormorani sono uccelli acquatici capaci di nuotare in apnea nelle profondità torbide per poi riemergere all'improvviso sani e salvi lontano dal punto d'immersione. Il padre e Ted vedono in questo fenomeno la speranza che anche Salim si sia inabissato temporaneamente nella metropoli per poi riaffiorare in un luogo inaspettato.
- **2. Vero o Falso:**
  1. **FALSO.** La salma appartiene a un ragazzo di Southall; il padre torna a casa confermando che non si tratta di Salim.
  2. **VERO.** Ted osserva con ammirazione come Kat sappia gestire con straordinario altruismo le grandi tragedie, preparando il tè e accudendo la zia.
  3. **VERO.** Rashid arriva in abito scuro formale e cravatta, mantenendo un contegno dignitoso e affettuoso.
  4. **FALSO.** I controlli del personale sono rigidi e continui: la teoria n. 1 viene sperimentalmente confutata sul campo.
  5. **FALSO.** Kat mostra al padre solo la bottiglia di olio rilassante per coprire il vero scopo della sosta, tenendo occultate le foto nella tasca.
- **3. Analisi dei Personaggi:**
  1. *La Morte come retta verso l'Infinito:* Il pensiero scientifico funge da scudo cognitivo per Ted. La geometrizzazione del tempo e del lutto non denota cinismo o insensibilità, ma rappresenta la sola modalità con cui una mente analitica può contenere l'angoscia della distruzione biologica, trasformando il terrore del nulla in una legge universale e ordinata.
  2. *La complicità clandestina tra fratelli:* La dinamica fraterna evolve in una perfetta sinergia investigativa. Kat fornisce l'audacia pratica, l'ingegno sociale, la capacità di recitare una parte e gestire l'inganno verso gli adulti; Ted garantisce il rigore logico, la memoria prodigiosa e la capacità di analisi scientifica dei fatti. L'indagine diventa lo spazio in cui entrambi si scoprono indispensabili l'uno all'altra.
- **4. Officina di Scrittura:** Criteri di valutazione: rispetto del punto di vista maturo e dolente di Rashid; riflessione credibile sul fallimento del matrimonio con Gloria e sull'amore protettivo verso Salim; intuizione psicologica della complicità segreta tra i nipoti; adozione della metafora poetica dei cormorani come filo conduttore della speranza paterna.
- **5. Laboratorio Lessicale:** Combinazione corretta: `1-C, 2-D, 3-E, 4-B, 5-A`.
- **6. Attività Speciale:** Criteri di osservazione: coerenza narrativa della timeline fotografica; originalità e rigore del cifrario a sostituzione per codificare il messaggio segreto; qualità grafica e ricchezza di dettagli indiziari nella riproduzione del fotogramma n. 21.

[[FINE]]
