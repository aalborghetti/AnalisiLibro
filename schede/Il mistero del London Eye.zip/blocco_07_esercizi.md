[[FILE: blocco_07_esercizi.md]]
# SCHEDA DIDATTICA DI LETTURA E COMPRENSIONE
## *Il mistero del London Eye* di Siobhan Dowd
### Unità Didattica 7 (Blocco 7): *La nona teoria* – *Metti insieme e combina*

---

> ### 🌊 Il puzzle si ricompone nel cuore della notte
> «"La scomparsa di Salim è stata pianificata. Qualcuno lo ha aiutato." Kat mi fissò a bocca aperta. [...] Guardai le due fotografie con la lente d'ingrandimento. Era un gioco a incastro, testa e coda. Far combaciare le cose che appartenevano allo stesso quadro. Un puzzle.»  
> Mentre gli adulti sprofondano nelle confessioni e nel fumo acre delle sigarette, nella cameretta di Ted avviene la svolta decisiva dell'indagine. Rifiutando lo scoraggiamento di Kat, che aveva già gettato la spugna e appallottolato il foglio delle ipotesi nel cestino, Ted formula la sua "Nona Teoria": Salim non è evaporato per magia, ma ha orchestrato una fuga con l'aiuto di un complice. E quando nella notte Ted esamina i fotogrammi con una lente d'ingrandimento, due scatti apparentemente sbagliati combaciano all'improvviso, rivelando il volto e il corpo dell'uomo misterioso.

---

## 1. Comprensione del Testo

*Rispondi alle domande sul tuo quaderno in modo completo, motivando con riferimenti precisi al testo.*

1. **La formulazione della Nona Teoria:** Nel Capitolo 18, dopo aver recuperato il foglio delle teorie dal cestino della carta straccia ed escluso le ipotesi impossibili secondo la massima di Sherlock Holmes, quale nuova tesi rivoluzionaria espone Ted? In che modo questa intuizione ribalta l'intera prospettiva dell'indagine?
2. **La delusione iniziale per le fotografie:** Quando Kat esamina per la prima volta i ventuno scatti del rullino sviluppato, li liquida con rabbia come «stupide foto da turisti» e rinuncia a cercarvi indizi. Quali elementi visivi la portano a questo giudizio frettoloso e perché Ted rifiuta di rassegnarsi?
3. **La confessione notturna tra Gloria e Rashid:** Scendendo in cucina a notte fonda per prendere uno snack (Capitolo 20), Ted ascolta di nascosto un drammatico confronto tra la zia e l'ex marito. Quali ammissioni di colpa e reciproche fragilità emergono dal loro dialogo e quale inaspettata riconciliazione coglie Ted prima di fuggire al piano di sopra?
4. **Il gioco a incastro "Testa e Coda":** Nel Capitolo 21, osservando le fotografie con una lente d'ingrandimento, in che modo Ted riesce a ricostruire l'immagine intera del donatore del biglietto? Come combina lo scatto "venuto male" da lui eseguito con la foto panoramica scattata da Salim?
5. **L'indizio nascosto sulla maglietta:** Quale dettaglio cruciale nota Kat osservando con attenzione l'ingrandimento del torso dello sconosciuto? Quale piano d'azione stabiliscono i due fratelli per l'indomani mattina e per quale ragione decidono di escludere i genitori dalle loro scoperte?

---

## 2. Vero o Falso? (Attenzione ai dettagli)

*Indica nella tabella se l'affermazione è Vera (V) o Falsa (F). Correggi e motiva sul tuo quaderno le affermazioni false.*

| Affermazione | V | F |
| :--- | :---: | :---: |
| 1. Nel Capitolo 18, Kat appallottola il foglio delle teorie e lo getta nel cestino convinta che l'indagine sia ormai superiore alle loro capacità di ragazzi. | | |
| 2. La Nona Teoria formulata da Ted sostiene che Salim sia stato rapito da un'organizzazione criminale internazionale per estorcere un ingente riscatto. | | |
| 3. Origliando nel soggiorno buio, Ted scopre che Rashid e Gloria hanno deciso di sporgere denuncia contro la famiglia Spark per mancata custodia del figlio. | | |
| 4. Nella fotografia scattata da Ted in coda, l'inquadratura ha tagliato la testa dello sconosciuto mostrando unicamente il torso, la giacca aperta e i pantaloni. | | |
| 5. Sulla maglietta dello sconosciuto, Kat riesce a leggere all'istante e senza alcuna difficoltà l'intero nome e cognome dell'uomo impresso a caratteri cubitali. | | |

---

## 3. Analisi dei Personaggi e Riflessione

*Rifletti sulle scelte e sulle emozioni dei protagonisti e rispondi sul quaderno.*

1. **La perseveranza del metodo contro lo scoraggiamento emotivo:** Kat passa repentinamente dalla frenesia all'abbattimento (getta via le foto e accartoccia gli appunti), mentre Ted conserva una ferma tenacia analitica, convinto che ogni frammento contenga un significato. In quale modo la diversa gestione della frustrazione tra Kat e Ted rispecchia due modalità opposte di affrontare le difficoltà e gli imprevisti dell'esistenza?
2. **La complessità del mondo adulto vista da un ragazzo:** Nel Capitolo 20, Ted assiste senza volerlo alla vulnerabilità dei genitori di Salim, che prima si rinfacciano le rispettive assenze e poi si cercano in un abbraccio disperato. Come reagisce la mente lineare di Ted di fronte alle contraddizioni emotive degli adulti e perché per un adolescente è spesso destabilizzante scoprire la debolezza e i limiti dei propri modelli genitoriali?

---

## 4. Officina di Scrittura Creativa ed Empatia

*Mettiti nei panni di uno dei protagonisti e svolgi l'attività sul tuo quaderno.*

Immagina di essere **Ted** nel cuore della notte, mentre Kat divora l'ultimo pacchetto di patatine dopo aver esaminato le due fotografie con la lente d'ingrandimento. Tua sorella ti ha appena battuto la mano sulla spalla definendoti un «genio» e sul tavolo della tua camera c'è la prova tangibile che la tua Nona Teoria è corretta: il donatore del biglietto è impresso sulla pellicola.  
Scrivi una pagina del tuo **diario personale**:
- Descrivi la sensazione fisica e mentale provata quando i due scatti separati hanno formato un'unica figura coerente, paragonando quel momento a un fenomeno meteorologico di improvvisa chiarificazione atmosferica;
- Esprimi cosa significa per te ricevere l'approvazione e la stima sincera di Kat, riflettendo su come stia cambiando il vostro legame dopo anni di incomprensioni e battibecchi;
- Formula le tue ipotesi deduttive sul significato di quelle due lettere isolate ("O" e "T") visibili sulla maglietta dello sconosciuto.

---

## 5. Laboratorio Lessicale e Modi di Dire

*Associa ciascun vocabolo o espressione d'autore al suo significato nel contesto del racconto (indica sul quaderno la combinazione corretta numero-lettera).*

| Termine o Modo di Dire | Abbinamento | Significato Contestuale |
| :--- | :---: | :---: |
| 1. **Processo di eliminazione** | | A. Metodologia investigativa che consiste nell'accostare frammenti eterogenei per verificarne la perfetta concordanza come in un mosaico. |
| 2. **Origliare** | | B. Azione clandestina di spiare uditivamente conversazioni private altrui, cogliendone confessioni intime senza essere visti. |
| 3. **Metti insieme e combina** | | C. Intuizione folgorante o scoperta decisiva che demolisce un blocco investigativo consentendo di compiere un balzo avanti verso la verità. |
| 4. **Punto di svolta** | | D. Procedimento logico che esclude metodicamente tutte le ipotesi confutate dai fatti empirici, fino a isolare la sola opzione valida. |
| 5. **Lente d'ingrandimento** | | E. Strumento ottico di precisione impiegato nell'analisi forense per rivelare micro-dettagli e iscrizioni invisibili a occhio nudo. |

---

## 6. Attività Speciale "Fuori dagli Schemi"

**Mappa Tattica: La Ricostruzione dei Percorsi tra South Bank ed Euston**  
Con la formulazione della Nona Teoria, Ted e Kat deducono che Salim si sia allontanato volontariamente dal London Eye con il supporto di un complice. Per pianificare le prossime mosse, è necessario ricostruire la topografia dei possibili assi di fuga dalla banchina del Tamigi verso le grandi stazioni ferroviarie cittadine.  
Disegna sul tuo quaderno una **Pianta Tattica della Rete Urbana e Sotterranea di Londra**:

1. **Il Quadrante Operativo:**
   - Mappa l'area compresa tra il London Eye (sponda sud), il ponte pedonale Golden Jubilee, la stazione della metropolitana di Embankment (sponda nord) e il percorso della Northern Line verso la stazione di Euston (direttrice verso Manchester);
   - Traccia con un colore a contrasto il tragitto ordinario percorso dal gruppo la mattina del 24 maggio.

2. **L'Asse di Fuga e le Zone d'Ombra:**
   - Ipotizza e traccia due percorsi alternativi con cui Salim e il complice potrebbero essersi dileguati rapidamente dopo lo sbarco delle 12:02;
   - Evidenzia con simboli speciali le **zone d'ombra** (varchi privi di telecamere a circuito chiuso, sottopassaggi pedonali, servizi igienici pubblici) in cui sarebbe stato possibile effettuare un cambio d'abito rapido.

3. **Legenda dei Simboli Tattici:**
   - Crea una legenda con almeno 4 simboli: il London Eye (punto di rilascio), i tornelli della metropolitana (varco di transito rapido), il laboratorio fotografico (sede delle prove materiali) e la stazione ferroviaria (terminal di fuga).

[SPAZIO PER IL TUO DISEGNO / RILIEVO GRAFICO]

---

### GUIDA E RIASSUNTO PER IL DOCENTE

#### Riassunto sintetico dei capitoli
I capitoli 18–21 segnano il momento decisivo della svolta investigativa attraverso l'analisi delle prove materiali:
- **Capitolo 18 (*La nona teoria*):** Rientrati a casa Spark dopo il secondo giro al London Eye, Kat consegna l'olio da bagno a Gloria suscitando una sua commossa rievocazione d'infanzia di Salim. Saliti in camera, Kat esamina frettolosamente le 21 fotografie e le getta sul letto delusa («solo foto stupide da turisti»), appallottolando nel cestino il foglio delle teorie. Ted recupera il foglio e, applicando il principio deduttivo di Sherlock Holmes, cancella le teorie n. 1 e n. 8 (confutate sul campo) e accantona quelle fantascientifiche. Annuncia quindi a Kat la "Nona Teoria": Salim non è scomparso per magia o disgrazia; la sua fuga era stata deliberatamente pianificata ed eseguita con la complicità di qualcuno.
- **Capitolo 19 (*Il ragazzo sul treno*):** Kat e Ted approfondiscono le implicazioni della nuova teoria. Se la sparizione è stata concordata, con chi si è allontanato Salim e verso quale destinazione? Riemergono i discorsi notturni di Salim sul suo unico amico di Manchester, Marcus, sulle recite scolastiche e sul legame viscerale con la sua città d'origine. Ted analizza la fitta rete di trasporti londinesi e riflette sulle difficoltà di orientamento urbano. Per la notte, le stanze vengono riorganizzate: Kat dorme sul materassino in camera di Ted, mentre Rashid e Gloria occupano le altre stanze.
- **Capitolo 20 (*Ascoltare di nascosto*):** In piena notte, Ted scende in cucina per fare uno spuntino. Dalla porta socchiusa del soggiorno sente le voci sommesse di Gloria e Rashid. Ascoltando di nascosto, assiste a un momento di rara vulnerabilità adulta: Rashid confessa tra le lacrime il proprio senso di colpa per essersi allontanato emotivamente dal figlio a causa del lavoro medico; Gloria ammette la propria solitudine e il vuoto interiore mascherato dal miraggio del trasferimento americano. La sofferenza condivisa sfocia in una commossa riconciliazione e in un bacio appassionato. Ted, scandalizzato e a disagio di fronte all'effusione sentimentale, si precipita silenziosamente al piano di sopra.
- **Capitolo 21 (*Metti insieme e combina*):** Tornato a letto, Ted riesamina le fotografie sgranocchiando patatine. All'improvviso compie un collegamento visivo geniale e sveglia Kat: ha identificato l'uomo misterioso che ha regalato il biglietto. Incrociando due scatti differenti (quello "sbagliato" di Ted, che mostrava il busto senza testa con la giacca aperta e una maglietta stampata, e quello panoramico di Salim, che ritraeva in lontananza la testa e le spalle di un giovane uomo in coda), Ted ricompone l'intero corpo del soggetto come le tessere di un puzzle. Con una lente d'ingrandimento, Kat scorge sulla maglietta le lettere "O" e "T". Consapevoli di avere tra le mani la svolta del caso, i due decidono di far ingrandire i negativi l'indomani, agendo in totale autonomia rispetto agli adulti.

#### Soluzioni ed elementi chiave di correzione
- **1. Comprensione del Testo:**
  1. *La formulazione della Nona Teoria:* Ted deduce che la sparizione non è un incidente fortuito o un fenomeno inspiegabile, bensì un piano di allontanamento premeditato orchestrato da Salim con l'aiuto di un complice esterno. Questa intuizione sposta l'asse delle ricerche dall'ipotesi del rapimento o della disgrazia a quella della complicità attiva.
  2. *La delusione iniziale per le fotografie:* Kat cerca una risposta immediata ed evidente; vedendo soltanto scorci turistici canonici (il Big Ben, i ponti, ritratti di famiglia), considera il rullino una pista morta. Ted non si rassegna perché sa che ogni scatto fotografico conserva dati oggettivi indipendenti dall'intenzione dell'operatore, capaci di rivelare dettagli secondari ignorati dall'occhio.
  3. *La confessione notturna tra Gloria e Rashid:* I genitori si spogliano delle loro maschere di risentimento: Rashid ammette la propria assenza genitoriale e l'incapacità di ascoltare la solitudine del figlio; Gloria confessa la disperazione per il divorzio e l'illusione fallace della fuga newyorkese. Il dialogo si conclude con un bacio e un riavvicinamento affettivo inatteso.
  4. *Il gioco a incastro "Testa e Coda":* Ted intuisce che due inquadrature parziali possono essere integrate: il fotogramma di Salim ha immortalato il volto e la testa dell'uomo sullo sfondo della folla, mentre lo scatto sbilanciato di Ted ha ripreso da vicino il suo busto con la giacca e la maglietta grafica. Accostando testa e torso, i due fratelli ottengono l'identikit completo dell'uomo del biglietto.
  5. *L'indizio nascosto sulla maglietta:* Kat individua sul tessuto della t-shirt alcune lettere serigrafate parziali ("O" e "T"). Per decifrare l'intera iscrizione e risalire all'identità del giovane, i fratelli decidono di portare i negativi al laboratorio per ottenere un forte ingrandimento ottico, tenendo all'oscuro i genitori per evitare che blocchino la loro iniziativa.
- **2. Vero o Falso:**
  1. **VERO.** Kat si arrende provvisoriamente all'angoscia e getta il foglio nel cestino, ma Ted lo ripesca subito.
  2. **FALSO.** La Nona Teoria sostiene la fuga volontaria e organizzata con la collaborazione di un complice.
  3. **FALSO.** I due genitori condividono il proprio dolore, ammettono i propri fallimenti e si riconciliano affettuosamente.
  4. **VERO.** Lo scatto di Ted inquadrava la folla all'altezza del bacino, catturando il torso senza il capo.
  5. **FALSO.** La scritta è sfuocata e Kat riesce a decifrare soltanto le lettere "O" e "T", necessitando dell'ingrandimento fotografico.
- **3. Analisi dei Personaggi:**
  1. *La perseveranza del metodo contro lo scoraggiamento emotivo:* Il contrasto delinea due assetti psicologici complementari. Kat ragiona per picchi emotivi: si accende di entusiasmo e sprofonda nella disperazione quando non ottiene risultati immediati. Ted possiede la stabilità cognitiva del ricercatore: per lui l'insuccesso apparente è solo un dato che invita a cambiare prospettiva. L'unione dei due approcci è ciò che consente di trasformare un'intuizione solitaria in un'azione investigativa concreta.
  2. *La complessità del mondo adulto vista da un ragazzo:* La mente di Ted, abituata a categorie logiche chiare (vero/falso, causa/effetto), fatica a decodificare la contraddittorietà dei sentimenti degli adulti, capaci di odiarsi e amarsi simultaneamente. Scoprire la fragilità dei genitori è un passaggio cruciale della crescita: il ragazzo si rende conto che gli adulti non sono onnipotenti né invulnerabili, e che la salvezza di Salim dipende ormai interamente dall'indagine giovanile.
- **4. Officina di Scrittura:** Criteri di valutazione: rispetto della voce in prima persona di Ted (metafore visive, precisione terminologica, riferimenti all'equilibrio mentale); resa fedele dell'orgoglio fraterno e del mutamento relazionale con Kat; plausibilità logica e ricchezza di ipotesi deduttive sul significato delle lettere serigrafate "O" e "T".
- **5. Laboratorio Lessicale:** Combinazione corretta: `1-D, 2-B, 3-A, 4-C, 5-E`.
- **6. Attività Speciale:** Criteri di osservazione: precisione topografica della pianta dell'area fluviale e dei nodi metropolitani; coerenza logica nell'individuazione dei varchi di fuga e delle aree prive di videosorveglianza; chiarezza grafica e completezza della legenda con almeno 4 simboli.

[[FINE]]
