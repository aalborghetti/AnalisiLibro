[[FILE: blocco_08_esercizi.md]]
# SCHEDA DIDATTICA DI LETTURA E COMPRENSIONE
## *Il mistero del London Eye* di Siobhan Dowd
### Unità Didattica 8 (Blocco 8): *Il gioco delle parole* – *La troupe televisiva*

---

> ### 🌊 Le parole che svelano e le telecamere che invadono
> «Guardammo la scritta bianca sulla maglietta: O-N-T-L... e sotto C-U-R-I-T. "Security!" esclamò Kat. "Frontline Security!" [...] E poi arrivarono le telecamere. Tre uomini e una donna con un microfono. Trasformarono il nostro salotto in un palcoscenico per il telegiornale della sera.»  
> Un'indagine investigativa vive di dettagli minimi: una scritta frammentaria su una maglietta sfuocata e una ricerca frenetica sulle Pagine Gialle aprono una pista concreta nel quartiere di Battersea. Ma mentre Kat si lancia in una fuga solitaria e rischiosa per verificare l'indizio, il dramma privato della famiglia Spark viene travolto dai riflettori della televisione. Tra lacrime sollecitate a comando per commuovere il pubblico e telecamere invadenti, Ted scopre il cinismo dei media e trova il coraggio di compiere la sua scelta più audace.

---

## 1. Comprensione del Testo

*Rispondi alle domande sul tuo quaderno in modo completo, motivando con riferimenti precisi al testo.*

1. **La prima bugia di Ted:** Nel Capitolo 22, per coprire l'uscita segreta di Kat andata a ritirare gli ingrandimenti fotografici, Ted inventa una scusa plausibile con la madre (la ricerca della bussola smarrita nel giardinetto). Quale valore psicologico assume questa prima bugia per un ragazzo come Ted, che fino a quel giorno non aveva mai detto una falsità in tutta la sua vita?
2. **La decifrazione dell'enigma serigrafico:** Esaminando l'ingrandimento della maglietta dello sconosciuto, Kat e Ted notano lettere frammentarie (`O N T L` e `C U R I T`). Come riescono i due fratelli, combinando intuito linguistico e logica deduttiva, a ricostruire il nome dell'agenzia di sorveglianza privata «Frontline Security»?
3. **L'angoscia della "Katastrofe":** Nel Capitolo 23, scoprendo che Kat è fuggita da sola verso Battersea lasciando solo un biglietto sbrigativo, Ted sprofonda nel panico e conia una serie di giochi di parole sul nome della sorella (*Katastrofe*, *Kataclisma*). Da quale duplice dilemma morale è lacerato Ted mentre attende il ritorno di Kat?
4. **La messinscena dei mass media:** Nel Capitolo 25, una troupe televisiva allestisce il set nel soggiorno di casa Spark per trasmettere l'appello dei familiari. Quali dettagli osservati da Ted mettono a nudo l'artificiosità della televisione e la spettacolarizzazione del dolore privato di zia Gloria?
5. **L'indagine telefonica e la pista di Earl's Court:** Approfittando della confusione, Ted telefona personalmente alla Frontline Security e parla con la centralinista. Quale preziosa informazione riesce a ottenere sull'identità dell'uomo (Christy) e sul luogo esatto in cui si trova in servizio (il salone delle moto a Earl's Court), spingendolo a lasciare casa da solo?

---

## 2. Vero o Falso? (Attenzione ai dettagli)

*Indica nella tabella se l'affermazione è Vera (V) o Falsa (F). Correggi e motiva sul tuo quaderno le affermazioni false.*

| Affermazione | V | F |
| :--- | :---: | :---: |
| 1. Dagli ingrandimenti fotografici emerge con chiarezza che l'uomo del biglietto ha il viso perfettamente sbarbato e indossa una divisa militare della marina britannica. | | |
| 2. Per risalire all'indirizzo e al recapito telefonico della Frontline Security, Ted e Kat consultano l'elenco cartaceo delle Pagine Gialle. | | |
| 3. Durante le riprese televisive, la giornalista Sonia decide di dedicare l'intero servizio a Ted, affascinata dalla sua spiegazione dettagliata sui sistemi nuvolosi e i venti. | | |
| 4. La centralinista della Frontline Security rivela a Ted che l'uomo con la barba incolta si chiama Christy ed è in servizio come guardia giurata al Motor Show di Earl's Court. | | |
| 5. Per finanziare la sua spedizione solitaria a Earl's Court, Ted sottrae cinquanta sterline dal portafoglio del padre lasciato incustodito sul tavolo della cucina. | | |

---

## 3. Analisi dei Personaggi e Riflessione

*Rifletti sulle scelte e sulle emozioni dei protagonisti e rispondi sul quaderno.*

1. **La solitudine del testimone silenzioso:** Durante la registrazione dell'appello televisivo, Ted assiste alla trasformazione della sofferenza privata della sua famiglia in uno spettacolo per il pubblico, dove le lacrime vengono sollecitate sotto la luce dei riflettori. Quale critica all'invadenza dei mass media emerge dallo sguardo analitico di Ted e come si riflette questo sulla sua personale esclusione dal racconto ufficiale?
2. **Il superamento della paura per lealtà fraterna:** Ted è un ragazzo che teme profondamente la rottura della routine, gli spazi affollati e il contatto con gli sconosciuti. Eppure, alla fine del Capitolo 25, decide di mentire nuovamente alla madre e avventurarsi da solo nella metropolitana di Londra per raggiungere Kat a Earl's Court. Che cosa spinge Ted a sfidare le proprie fobie e cosa rivela questo gesto sulla sua maturazione morale?

---

## 4. Officina di Scrittura Creativa ed Empatia

*Mettiti nei panni di uno dei protagonisti e svolgi l'attività sul tuo quaderno.*

Immagina di essere **Kat** mentre viaggi sul treno della metropolitana di ritorno da Battersea verso casa, dopo aver trovato la sede della Frontline Security chiusa ma aver capito che la pista è caldissima. Stringi la borsa e ripensi all'azzardo che hai appena compiuto all'insaputa di tutti.  
Scrivi una pagina del tuo **diario segreto**:
- Racconta l'impulso irrefrenabile che ti ha spinto a fuggire da sola senza aspettare Ted, ammettendo la paura provata mentre ti muovevi da sola per la metropoli;
- Descrivi il senso di trionfo provato nello scoprire che gli indizi ricavati dalle foto non erano illusioni, ma piste reali che conducono a persone in carne e ossa;
- Rifletti sul legame con tuo fratello: perché senti di non poter più fare a meno del suo rigore e come intendi coinvolgerlo nella caccia finale allo sconosciuto?

---

## 5. Laboratorio Lessicale e Modi di Dire

*Associa ciascun vocabolo o espressione d'autore al suo significato nel contesto del racconto (indica sul quaderno la combinazione corretta numero-lettera).*

| Termine o Modo di Dire | Abbinamento | Significato Contestuale |
| :--- | :---: | :---: |
| 1. **Satellite geostazionario** | | A. Annuario cartaceo alfabetico e settoriale delle attività economiche e commerciali, fondamentale per rintracciare indirizzi e recapiti aziendali. |
| 2. **Ingrandimento fotografico** | | B. Lavoratore assunto con contratto provvisorio o d'agenzia per coprire mansioni d'ufficio o centralino durante assenze del personale di ruolo. |
| 3. **Pagine Gialle** | | C. Riproduzione a stampa su grande formato ottenuta dalla scansione del negativo, impiegata per rendere leggibili particolari minuti o scritte sfuocate. |
| 4. **Interinale** | | D. Espressione colloquiale inglese (*no skin off my teeth*) usata per affermare che una rivelazione o un'azione non comporta alcun rischio né danno personale. |
| 5. **Non costarmi nulla** | | E. Sonda spaziale posizionata in orbita a 36.000 km di quota la cui velocità angolare coincide con quella terrestre, apparendo immobile rispetto al suolo. |

---

## 6. Attività Speciale "Fuori dagli Schemi"

**Processo in Aula / Dibattito: Lo Spettacolo del Dolore e il Diritto alla Riservatezza**  
Nel Capitolo 25, una troupe televisiva trasforma il soggiorno di casa Spark in un set da ripresa per trasmettere in prima serata l'appello per la scomparsa di Salim. La classe si confronta in un dibattito formale (Debate) sul delicato rapporto tra informazione televisiva, rispetto della privacy e ricerca delle persone scomparse.

1. **Collegio di Difesa dell'Appello Televisivo (Pro-Media):**
   - Sostiene che la televisione e la diffusione virale delle immagini costituiscano lo strumento più rapido ed efficace per mobilitare l'opinione pubblica e raccogliere segnalazioni;
   - Dimostra che la temporanea violazione della privacy familiare è ampiamente giustificata dal valore supremo della salvaguardia della vita di un minore scomparso;
   - Evidenzia come la pressione delle telecamere impedisca alle forze dell'ordine di archiviare il caso o rallentare le indagini.

2. **Collegio di Tutela della Dignità Privata (Contro-Spettacolarizzazione):**
   - Denuncia il cinismo dei produttori televisivi che trasformano l'angoscia autentica di una madre in un prodotto d'intrattenimento a caccia di ascolti e share;
   - Mette in guardia dai rischi per il ragazzo scomparso (stigmatizzazione mediatica, interferenze di mitomani, possibili ritorsioni o fughe ulteriori per paura del giudizio pubblico);
   - Sostiene che l'efficacia investigativa debba poggiare sulla competenza forense e sul silenzio operativo, non sulla spettacolarizzazione del dolore.

*Regole del dibattito:* Ciascun collegio schiera 3 oratori (Discorso introduttivo, Replica alle obiezioni, Discorso conclusivo). La Giuria imparziale di classe valuta la pertinenza delle prove tratte dal testo e redige un giudizio critico sul rapporto tra etica giornalistica e cronaca nera.

---

### GUIDA E RIASSUNTO PER IL DOCENTE

#### Riassunto sintetico dei capitoli
I capitoli 22–25 alternano la decifrazione logica sul campo all'impatto violento della sfera mediatica:
- **Capitolo 22 (*Il gioco delle parole*):** Martedì mattina. Kat rientra furtivamente dopo aver ritirato gli ingrandimenti fotografici. Ted la copre davanti alla madre con la sua prima bugia deliberata (sostiene che cercasse la bussola in giardino). Saliti in camera, esaminano i gigantografie: la prima mostra il volto dell'uomo con barba incolta e sopracciglia scure; la seconda inquadra il torso con giacca di pelle e maglietta nera recante lettere sfuocate (`O N T L` e `C U R I T`). Con un gioco deduttivo di anagrammi e completamento lessicale, deducono la scritta integrale «Frontline Security». Consultando le Pagine Gialle individuano la sede a Battersea.
- **Capitolo 23 (*Katastrofe*):** Ted scende un attimo e al suo ritorno scopre che Kat è scomparsa, lasciando un biglietto: «Torno presto. Non dire niente». Ted cade in preda al terrore sensoriale, temendo che la sorella si sia cacciata in un pericolo mortale e giocando angosciosamente sul suo nome (*Katastrofe*, *Kataclisma*). Ted vive un dilemma etico: avvisare i genitori rompendo il patto o tacere rischiando la vita della sorella.
- **Capitolo 24 (*Bingo*):** Mentre l'attesa logora Ted, fuori dalla casa si ferma un furgone bianco con parabola satellitare: è la troupe televisiva del telegiornale. Improvvisamente Kat riappare alla porta sussurrando «Bingo!»: è andata fino a Battersea alla sede della Frontline Security, scoprendo che è chiusa ma raccogliendo indicazioni.
- **Capitolo 25 (*La troupe televisiva*):** I tecnici invadono il soggiorno piazzando faretti e microfoni. La giornalista Sonia istruisce freddamente Gloria, Rashid e la madre su come posizionarsi e quando piangere per massimizzare la resa drammatica della diretta. Ted osserva con disgusto la finzione del mezzo televisivo; quando la reporter tenta di intervistarlo, il ragazzo risponde con dati scientifici sulla pressione barometrica e viene bruscamente estromesso dal montaggio. Conclusa la diretta, Ted sfrutta la confusione per chiamare la Frontline Security dal telefono dei genitori: risponde un'impiegata interinale che, scambiandolo per un ragazzino ingenuo, gli rivela che la guardia con la barba incolta si chiama Christy ed è in servizio al Motor Show di Earl's Court. Ted scrive un biglietto d'alibi per la madre («Siamo andati a nuotare»), prende 15 monete da una sterlina dal suo forziere e fugge di casa per raggiungere Kat e trovare l'uomo del biglietto.

#### Soluzioni ed elementi chiave di correzione
- **1. Comprensione del Testo:**
  1. *La prima bugia di Ted:* Ted ha vissuto dodici anni ancorato alla verità letterale. Mentire alla madre rappresenta una profonda rottura deontologica che gli causa disagio fisico, ma segna anche la sua crescita morale: Ted antepone la lealtà e la protezione della sorella al rispetto cieco della norma astratta.
  2. *La decifrazione dell'enigma serigrafico:* Kat riconosce nella desinenza `C U R I T` la parola *Security*; Ted applica la logica combinatoria alla sequenza `O N T L`, formulando l'ipotesi *Frontline* sul modello delle agenzie di sorveglianza urbana. L'incrocio con l'elenco delle Pagine Gialle conferma l'esistenza reale della ditta a Battersea.
  3. *L'angoscia della "Katastrofe":* Ted teme che Kat sia stata vittima dello stesso destino di Salim. Il suo dilemma morale è paralizzante: infrangere la parola data denunciando la fuga alla madre (distruggendo la complicità con la sorella) o mantenere il segreto rischiando di compromettere i soccorsi in caso di aggressione.
  4. *La messinscena dei mass media:* Ted nota la totale assenza di empatia autentica nella troupe: le luci vengono calibrate per enfatizzare le occhiaie di Gloria, la giornalista interrompe il flusso spontaneo per ripetere i ciak e le lacrime vengono sollecitate come effetti speciali da copione. La sofferenza cessa di essere intima per diventare merce da palinsesto.
  5. *L'indagine telefonica e la pista di Earl's Court:* Ted adotta un registro calmo e disarmante al telefono. L'interinale si lascia sfuggire il nome della guardia (Christy) e la sua collocazione lavorativa settimanale (la fiera del motociclo all'Earl's Court Exhibition Centre), fornendo ai ragazzi l'indirizzo esatto dove rintracciare il testimone chiave.
- **2. Vero o Falso:**
  1. **FALSO.** L'uomo presenta una barba incolta di qualche giorno, sopracciglia scure, giubbotto di pelle consunto e t-shirt con scritte aziendali.
  2. **VERO.** Consultano il volume cartaceo delle Pagine Gialle per abbinare la scritta "Frontline Security" all'indirizzo del deposito di Battersea.
  3. **FALSO.** La reporter zittisce Ted non appena questi comincia a parlare di isobare e gradienti di pressione, tagliandolo fuori dal servizio.
  4. **VERO.** L'impiegata identifica la guardia («Christy, l'unico che non si rade mai a dovere») e rivela che l'intera squadra è di presidio a Earl's Court.
  5. **FALSO.** Ted impiega i propri risparmi personali prelevando 15 monete da una sterlina dal suo forziere dell'infanzia.
- **3. Analisi dei Personaggi:**
  1. *La solitudine del testimone silenzioso:* Ted smaschera l'ipocrisia dell'informazione spettacolarizzata: mentre il mondo degli adulti piange a comando davanti ai riflettori senza produrre indizi concreti, Ted comprende che l'azione reale si gioca altrove. L'esclusione dal servizio televisivo lo libera dalle convenzioni sociali, spingendolo all'azione pratica autonoma.
  2. *Il superamento della paura per lealtà fraterna:* La fuga solitaria di Ted segna il superamento definitivo delle proprie barriere difensive. Pur di non abbandonare Kat e di scoprire la verità su Salim, accetta la sfida sensoriale della città, affronta l'ignoto e assume la responsabilità di un'iniziativa clandestina, dimostrando un coraggio morale straordinario.
- **4. Officina di Scrittura:** Criteri di valutazione: espressione vivace e verosimile della voce adolescenziale di Kat; resa efficace dell'ansia provata durante l'esplorazione solitaria di Battersea; consapevolezza del valore della cooperazione con Ted; determinazione a completare l'inseguimento a Earl's Court.
- **5. Laboratorio Lessicale:** Combinazione corretta: `1-E, 2-C, 3-A, 4-B, 5-D`.
- **6. Attività Speciale:** Criteri di osservazione: capacità di reperire argomenti nel testo a sostegno delle tesi; rigore dialettico e confutazione puntuale delle argomentazioni avverse; riflessione critica sulla linea di confine tra diritto di cronaca e rispetto della persona.

[[FINE]]
