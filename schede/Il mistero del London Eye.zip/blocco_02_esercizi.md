[[FILE: blocco_02_esercizi.md]]
# SCHEDA DIDATTICA DI LETTURA E COMPRENSIONE
## *Il mistero del London Eye* di Siobhan Dowd
### Unità Didattica 2 (Blocco 2): *L'uragano raggiunge la terraferma* – *Discorsi notturni*

---

> ### 🌊 Due mondi a confronto nel buio della notte
> «Non mi piace essere diverso. Non mi piace stare nel mio cervello. A volte è come un grande spazio vuoto in cui sono completamente solo. E non c'è nient'altro, solo io.»  
> «Quel posto lo conosco anch'io», disse Salim. «Ci sono dentro anch'io. Ci si sente tremendamente soli là dentro, vero?»  
> L'Uragano Gloria e suo figlio Salim sono finalmente sbarcati in casa Spark. Dietro i modi eccentrici della zia e la battute vivaci della cena si nascondono però tensioni familiari irrisolte, ferite dolorose e scelte difficili. Ma è quando le luci si spengono e i grandi tacciono che accade qualcosa di straordinario: sul pavimento della camera di Ted, due ragazzi apparentemente lontanissimi scoprono di condividere la stessa profonda solitudine, gettando le basi di un'alleanza preziosa.

---

## 1. Comprensione del Testo

*Rispondi alle domande sul tuo quaderno in modo completo, motivando con riferimenti precisi al testo.*

1. **La scintilla di complicità tra cugini:** Quando Salim scende dal taxi, Ted nota che il cugino sembra avere «i pensieri in un posto diverso rispetto al corpo». Per quale motivo questo particolare dettaglio cattura la simpatia di Ted e fa nascere all'istante un'intesa silenziosa tra i due ragazzi, prima ancora che scambino una sola parola?
2. **La difesa dell'identità di Ted:** Quando zia Gloria commenta l'aspetto severo di Ted, vestito con la divisa scolastica anche durante le vacanze, Salim interviene prontamente definendolo un «ribelle» che usa un travestimento formale. Che valore ha questo gesto per Ted e come cambia la percezione di sé agli occhi della famiglia?
3. **La fascinazione per le altezze:** Durante la cena, mentre gli adulti e Kat propongono attività consuete come lo shopping in centro o la visita a una pinacoteca, perché Salim accoglie con tanto entusiasmo la proposta di Ted di visitare il London Eye? Da quali passioni e desideri profondi nasce la sua attrazione per i punti panoramici elevati?
4. **Il peso del trasferimento forzato:** Nel dialogo notturno del Capitolo 5, quali contrasti emotivi esprime Salim a proposito del suo imminente trasferimento a New York voluto dalla madre? Perché arriva ad augurarsi che una tempesta violenta blocchi tutti i voli all'aeroporto?
5. **«Quel posto lo conosco anch'io»:** Quando Ted confessa di sentirsi spesso intrappolato in un «grande spazio vuoto» all'interno del proprio cervello, Salim non lo deride ma afferma di conoscere bene quella medesima solitudine. Quali vicende scolastiche di emarginazione e discriminazione racconta Salim per spiegare il suo senso di isolamento?

---

## 2. Vero o Falso? (Attenzione ai dettagli)

*Indica nella tabella se l'affermazione è Vera (V) o Falsa (F). Correggi e motiva sul tuo quaderno le affermazioni false.*

| Affermazione | V | F |
| :--- | :---: | :---: |
| 1. All'arrivo di zia Gloria, Ted calcola con rigore geometrico che il giardinetto di casa, descritto dalla madre come «grande quanto un francobollo», potrebbe contenere in realtà 22.500 francobolli. | | |
| 2. Durante la cena, quando il padre di Ted nomina Rashid (l'ex marito di Gloria rimasto a Manchester), la donna intrattiene gli ospiti con aneddoti spensierati dimostrando di aver superato del tutto la separazione. | | |
| 3. Salim dichiara a Ted di detestare la fotografia e gli edifici moderni perché preferisce passeggiare in aperta campagna senza guardare in alto. | | |
| 4. Per descrivere la propria condizione a Salim, Ted usa l'analogia di un computer che possiede un sistema operativo diverso e un cablaggio differente rispetto alle altre persone. | | |
| 5. Nella scuola maschile di Manchester, Salim e il suo compagno Marcus subivano pesanti provocazioni e insulti razzisti prima di riscattarsi attraverso la recita teatrale de *La tempesta* di Shakespeare. | | |

---

## 3. Analisi dei Personaggi e Riflessione

*Rifletti sulle scelte e sulle emozioni dei protagonisti e rispondi sul quaderno.*

1. **Oltre le etichette dell'emarginazione:** A scuola Ted viene deriso con il nomignolo di «neek» (fusione tra nerd e geek) per il suo linguaggio accademico e i suoi interessi scientifici; a sua volta Salim, per via delle sue origini per metà asiatiche, ha subito a lungo insulti denigratori prima di trovare riscatto tra i compagni. In che modo la conversazione notturna tra i due cugini dimostra che le etichette sociali sono maschere ingannevoli e che la vera sintonia nasce dalla condivisione delle reciproche fragilità?
2. **Il dilemma della scelta paterna e materna:** Zia Gloria proietta sul trasferimento a New York l'illusione di una rinascita personale ed esistenziale («un'avventura favolosa nel nostro affascinante viaggio nella vita»), ignorando però il legame profondo tra Salim e suo padre Rashid rimasto in Inghilterra. Rifletti sul rapporto tra genitori e figli: fino a che punto un genitore ha il diritto di decidere il destino di un ragazzo di tredici anni senza ascoltare le sue reali aspirazioni e i suoi affetti?

---

## 4. Officina di Scrittura Creativa ed Empatia

*Mettiti nei panni di uno dei protagonisti e svolgi l'attività sul tuo quaderno.*

Immagina di essere **Salim**, disteso sul materassino gonfiabile nella stanza buia di Ted, subito dopo la vostra lunga conversazione notturna. Tuo cugino si è appena addormentato mormorando le coordinate del suo bollettino meteorologico e tu guardi la luce della luna filtrare dalla finestra.  
Scrivi una **lettera mai spedita a tuo padre Rashid**, rimasto da solo a Manchester:
- Racconta il tuo arrivo a Londra e l'incontro con Ted, spiegando perché quel cugino così insolito, con le sue risposte spiazzanti e il suo cervello peculiare, ti sia sembrato fin da subito l'unico capace di comprenderti davvero;
- Confessa a tuo padre la rabbia e la paura che provi all'idea di partire per New York al seguito di tua madre, ammettendo quanto ti mancheranno le vostre giornate insieme e la tua città;
- Esprimi le speranze e i timori per il giro sul London Eye in programma l'indomani, spiegando il bisogno di salire in alto per guardare il mondo e cercare di fare chiarezza dentro di te.

---

## 5. Laboratorio Lessicale e Modi di Dire

*Associa ciascun vocabolo o espressione d'autore al suo significato nel contesto del racconto (indica sul quaderno la combinazione corretta numero-lettera).*

| Termine o Modo di Dire | Abbinamento | Significato Contestuale |
| :--- | :---: | :---: |
| 1. **Goccia d'acqua** | | A. Modo di dire che indica un argomento, una passione o un'esperienza che si adatta perfettamente ai gusti e alle inclinazioni personali di un individuo. |
| 2. **Cablaggio** | | B. Termine mutuato dall'elettronica per indicare la specifica configurazione delle connessioni neuronali che regolano il flusso delle informazioni nel cervello. |
| 3. **Cervello a colabrodo** | | C. Conversazione convenzionale e leggera su temi quotidiani e futili, utilizzata nelle relazioni sociali per stabilire un contatto rassicurante. |
| 4. **Parlare del più e del meno** | | D. Espressione popolare che sottolinea un'estrema e sbalorditiva somiglianza somatica o comportamentale tra due parenti stretti. |
| 5. **Essere nelle proprie corde** | | E. Locuzione figurata usata per descrivere una memoria selettiva o distratta, incapace di trattenere commissioni e piccoli dettagli pratici della vita ordinaria. |

---

## 6. Attività Speciale "Fuori dagli Schemi"

**Processo in Aula / Dibattito: Trasferimento all'estero, opportunità o forzatura?**  
La partenza di Salim e Gloria per New York costituisce il nodo emotivo scatenante di questi capitoli. La madre vede negli Stati Uniti una prestigiosa rinascita professionale e umana; il ragazzo, al contrario, soffre per l'allontanamento forzato dal padre Rashid, dagli amici e dalle proprie radici.  
La classe si divide in due collegi contrapposti per sostenere un dibattito formale (Debate):

1. **Collegio di Difesa della Scelta Materna (Pro-Gloria):**
   - Sostiene il diritto della madre di ricostruire la propria carriera artistica a livello internazionale dopo un divorzio doloroso;
   - Evidenzia come l'ambiente scolastico di Manchester fosse ostile e pericoloso per Salim (episodi di bullismo, minacce e aggressioni);
   - Dimostra come una metropoli cosmopolita come New York possa offrire al ragazzo stimoli culturali ed educativi irripetibili.

2. **Collegio di Tutela dell'Identità del Minore (Pro-Salim e Rashid):**
   - Denuncia il carattere unilaterale e impositivo della decisione materna, presa senza una reale consultazione del ragazzo;
   - Difende l'importanza fondamentale della continuità del rapporto filiale con il padre Rashid, destinato a diventare distante e saltuario;
   - Evidenzia il rischio di disorientamento identitario derivante dallo sradicamento improvviso dal proprio tessuto sociale e affettivo.

*Regole di svolgimento:* Ogni squadra seleziona 3 oratori (Discorso introduttivo, Confutazione delle argomentazioni avverse, Discorso di chiusura). Gli altri studenti fungono da collegio giudicante (Giuria imparziale), incaricato di redigere una sintesi scritta motivata indicando quale tesi sia risultata più convincente in base alle testimonianze fornite dal testo.

---

### GUIDA E RIASSUNTO PER IL DOCENTE

#### Riassunto sintetico dei capitoli
I capitoli 4 e 5 approfondiscono il contesto familiare e relazionale, preparando l'antefatto psicologico della scomparsa:
- **Capitolo 4 (*L'uragano raggiunge la terraferma*):** Domenica 23 maggio, alle 18:24, zia Gloria e Salim arrivano in taxi a casa Spark. Gloria si presenta con un abbigliamento sofisticato, smalto rosa shocking e il bocchino da fumo; Salim, tredicenne longilineo dalla carnagione caramello, appare pensieroso e distaccato. Tra Ted e Salim si accende un'immediata intesa: il cugino difende la scelta di Ted di indossare la divisa scolastica anche durante le vacanze («un vero figo, il completo formale nasconde il ribelle interiore»), strappandogli un senso di fierezza mai provato prima. A cena si manifesta l'attrito mai risolto tra Gloria e il passato: quando il padre di Ted accenna all'ex marito Rashid, Gloria reagisce con sarcasmo e durezza. Per il lunedì seguente si discutono varie mete: Ted suggerisce il London Eye, e Salim si entusiasma all'istante per la possibilità di ammirare l'architettura cittadina dall'alto.
- **Capitolo 5 (*Discorsi notturni*):** Durante la notte, Salim non riesce a prendere sonno sul materassino e si confida con Ted. Esprime la sua fascinazione per i grattacieli e la fotografia, ma rivela anche il malessere per la partenza forzata verso New York, che lo separerà dal padre e dalla sua vita. Con grande tatto e rispetto, Salim interroga Ted sulla sua "sindrome". Ted risponde con limpidezza: il suo cervello è come un computer dotato di un sistema operativo diverso, eccellente sui fatti e sulle nozioni meteorologiche ma in difficoltà con le convenzioni sociali e la memoria a breve termine. Ted confessa la dolorosa sensazione di abitare in una «grande stanza vuota», e con sua immensa sorpresa Salim ammette di condividere lo stesso senso di vuoto e isolamento, raccontando gli episodi di bullismo e razzismo subiti a Manchester prima di farsi valere nella recita de *La tempesta*. Rassicurato dalla comprensione reciproca, Ted si addormenta serenamente.

#### Soluzioni ed elementi chiave di correzione
- **1. Comprensione del Testo:**
  1. *La scintilla di complicità tra cugini:* Ted riconosce in Salim il proprio stesso modo di essere al mondo: la dissociazione tra l'azione corporea presente e l'attività mentale interiore, spesso assorta in pensieri lontani. Questo rispecchiamento genera immediata empatia, priva del giudizio sociale che Ted subisce quotidianamente.
  2. *La difesa dell'identità di Ted:* Salim nobilita quella che gli altri considerano una bizzarria o una rigidità ossessiva, trasformando la divisa in una scelta stilistica d'avanguardia e in una maschera di ribellione. Questo restituisce a Ted dignità e autostima davanti alla sorella e ai genitori.
  3. *La fascinazione per le altezze:* Salim è un appassionato di architettura e fotografia urbana: l'altezza rappresenta per lui un punto di vista privilegiato da cui dominare lo spazio, catturare scorci inediti con la macchina fotografica e trovare simbolicamente respiro e chiarezza rispetto al caos della propria vita.
  4. *Il peso del trasferimento forzato:* Salim si sente trascinato in una decisione unilaterale della madre; soffre per il distacco forzato dal padre Rashid, cui è legatissimo, e teme di perdere i punti di riferimento faticosamente conquistati a scuola. Il desiderio di una tempesta è l'espressione simbolica del bisogno inconscio di fermare il tempo e scongiurare la partenza.
  5. *«Quel posto lo conosco anch'io»:* Salim racconta la violenza verbale e fisica della scuola maschile di Manchester, le sfide pericolose con coltelli e l'odio razziale espresso tramite l'insulto «Paki-Boy». Quell'emarginazione ha scavato dentro di lui la stessa sensazione di solitudine radicale e incomprensione confessata da Ted.
- **2. Vero o Falso:**
  1. **VERO.** Ted converte le dimensioni lineari di 3x5 metri nell'esatto numero di francobolli standard calcolandone l'area (22.500 francobolli).
  2. **FALSO.** La zia reagisce con evidente tensione, risentimento e imbarazzo, dimostrando quanto il divorzio da Rashid sia ancora un nervo scoperto e conflittuale.
  3. **FALSO.** Salim ama profondamente gli edifici alti e la fotografia ed è entusiasta di poter scattare immagini panoramiche dalla cima della ruota.
  4. **VERO.** Ted utilizza con precisione scientifica e informatica la metafora del computer con un sistema operativo e un circuito di cablaggio differenti.
  5. **VERO.** Salim e l'amico Marcus erano bersagli sistematici di bullismo a causa delle origini etniche, prima che il successo nella rappresentazione teatrale di Shakespeare mutasse la considerazione dei compagni.
- **3. Analisi dei Personaggi:**
  1. *Oltre le etichette dell'emarginazione:* I soprannomi denigratori («neek», «Paki-Boy») nascono dall'incapacità del gruppo di accettare la diversità. Nel confronto intimo della notte, cadono le difese e le etichette: i due ragazzi scoprono che la comune condizione di esclusi rappresenta una risorsa di comprensione autentica, fondata sul rispetto reciproco anziché sulla conformità ai modelli dominanti.
  2. *Il dilemma della scelta paterna e materna:* Il confronto evidenzia l'ambivalenza dei legami genitoriali durante le crisi familiari. Gloria legittima la propria scelta nascondendosi dietro l'enfasi della nuova avventura newyorkese, ma finisce per strumentalizzare il figlio come alleato nella propria fuga emotiva. Emerge la necessità etica di garantire al minore il diritto all'ascolto e alla stabilità degli affetti bilaterali.
- **4. Officina di Scrittura:** Criteri di valutazione: assunzione fedele della voce di Salim (registro colloquiale ma introspettivo); contrasto emotivo tra la fascinazione per Ted e l'angoscia per l'abbandono del padre; espressione sincera dei timori legati alla separazione da Manchester; coerenza nel descrivere l'attesa per l'ascesa sul London Eye come metafora di liberazione interiore.
- **5. Laboratorio Lessicale:** Combinazione corretta: `1-D, 2-B, 3-E, 4-C, 5-A`.
- **6. Attività Speciale:** Criteri di osservazione: capacità di reperire prove testuali dirette per corroborare le proprie tesi; efficacia retorica e rispetto delle regole del contraddittorio senza interruzioni improprie; profondità argomentativa nell'analisi del dilemma etico tra bisogni dell'adulto e diritti del minore.

[[FINE]]
