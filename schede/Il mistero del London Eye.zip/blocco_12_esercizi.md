[[FILE: blocco_12_esercizi.md]]
# SCHEDA DIDATTICA DI LETTURA E COMPRENSIONE
## *Il mistero del London Eye* di Siobhan Dowd
### Unità Didattica 12 (Blocco 12): *Ripercorrere i passi* – *L'ultimo giro della ruota*

---

> ### 🌊 L'ultimo giro della ruota e la luce nel cielo
> «"Mister Unico", mi disse Salim stringendomi forte la mano prima di passare il controllo passaporti. "Ci vediamo a New York." [...] Da quando il Casermone è stato demolito, lo skyline è cambiato: quando cammini lungo la nostra strada, per un istante vedi brillare mezza ruota del London Eye. E la silhouette di Salim è sempre lì, sospesa nel centro, che ci saluta proprio come quel giorno.»  
> La notte porta consiglio e fa cadere l'ultimo velo: unendo i frammenti della memoria, Ted formula una geniale "Terza Teoria" ricordando l'amore di Salim per le altezze e l'acquisto della macchina fotografica usa e getta. Salim non è fuggito né è stato rapito: è rimasto intrappolato al ventiquattresimo piano di Barrington Heights, il grattacielo che il padre di Ted deve far brillare all'alba. Inizia così una disperata corsa contro il tempo che si trasforma nel trionfo della vita. Un romanzo straordinario si chiude con l'abbraccio dell'aeroporto, la nascita di nuove amicizie e la consapevolezza che essere diversi è il dono più prezioso del mondo.

---

## 1. Comprensione del Testo

*Rispondi alle domande sul tuo quaderno in modo completo, motivando con riferimenti precisi al testo.*

1. **La Terza Teoria e la passione per le vette:** Nel Capitolo 38, rifiutando il falso dilemma tra rapimento e fuga volontaria, Ted formula una "Terza Teoria" ripercorrendo la psicologia e i desideri di Salim. Quale intuizione folgorante porta Ted a collegare l'acquisto della macchina fotografica usa e getta al cantiere di Barrington Heights («Il Casermone»)?
2. **La trappola del 24° piano e la corsa contro il tempo:** Quale drammatica catena di eventi ha intrappolato Salim all'ultimo piano dell'edificio disabitato e perché il suo ritrovamento si trasforma in una corsa disperata contro i minuti prima dell'alba?
3. **Il riscatto di zia Gloria e l'addio al fumo:** Nel Capitolo 41, prima di varcare i controlli di sicurezza dell'aeroporto per volare verso New York, zia Gloria consegna a Ted il suo bocchino e il portasigarette chiedendogli di gettarli via. Che valore simbolico assume questo gesto e perché la zia diventa ufficialmente la «sesta amica» di Ted?
4. **I doni e la terza bugia di Ted:** Per premiare i due fratelli, la famiglia concede loro un desiderio: Ted sceglie un orologio meteorologico multifunzione con barometro, mentre Kat si fa tagliare i capelli da *Hair Flair*. Quale terza bugia compassionevole pronuncia Ted guardando la nuova pettinatura della sorella e dove decide di annotarla?
5. **Il nuovo panorama e l'eterno giro della ruota:** Con la demolizione definitiva di Barrington Heights, lo skyline del quartiere cambia per sempre. Quale scorcio visivo inedito si apre ora in fondo alla strada e quale significato assume l'immagine di Salim che continua idealmente a salutare dalla capsula del London Eye nella mente di Ted?

---

## 2. Vero o Falso? (Attenzione ai dettagli)

*Indica nella tabella se l'affermazione è Vera (V) o Falsa (F). Correggi e motiva sul tuo quaderno le affermazioni false.*

| Affermazione | V | F |
| :--- | :---: | :---: |
| 1. Salim è rimasto bloccato nel Casermone perché il guardiano notturno si era allontanato per comprare le sigarette e al suo rientro ha sbarrato i cancelli con catene e lucchetti senza ispezionare i piani alti. | | |
| 2. Durante la perlustrazione notturna di Barrington Heights con i vigili del fuoco, è Kat a sfondare la porta del 24° piano a calci e a trovare Salim svenuto sul pavimento. | | |
| 3. L'orologio meteorologico regalato a Ted è dotato di bussola e barometro, permettendogli di aumentare la precisione statistica delle sue previsioni meteo del 31,5%. | | |
| 4. Al momento dell'imbarco per gli Stati Uniti, Salim dichiara di non voler più vedere i cugini per dimenticare l'angoscia vissuta a Londra. | | |
| 5. Dopo l'abbattimento del Casermone, svoltando l'angolo della via principale è possibile scorgere in lontananza la sagoma scintillante della ruota del London Eye. | | |

---

## 3. Analisi dei Personaggi e Riflessione

*Rifletti sulle scelte e sulle emozioni dei protagonisti e rispondi sul quaderno.*

1. **«Mister Unico»: la celebrazione della diversità:** Nel congedarsi all'aeroporto, Salim saluta Ted definendolo «Mister Unico» (*Mr Unique*). In quale modo l'esperienza dell'indagine ha ribaltato l'etichetta di stramberia o difetto («neek») che pesava su Ted, trasformando la sua neurodivergenza in un talento eccezionale riconosciuto e amato dall'intera famiglia?
2. **La cartellina delle bugie e la maturazione empatica:** Ted crea una cartellina argentata intitolata *Le mie bugie* per custodire le tre falsità pronunciate nel corso della vicenda (la bussola smarrita, il biglietto della piscina e il complimento al taglio di capelli di Kat). Perché queste "bugie bianche" non indicano un degrado morale, ma segnano l'ingresso di Ted nella comprensione profonda della gentilezza e della cura verso i sentimenti altrui?

---

## 4. Officina di Scrittura Creativa ed Empatia

*Mettiti nei panni di uno dei protagonisti e svolgi l'attività sul tuo quaderno.*

Immagina di essere **Salim** mentre ti trovi a bordo del volo transoceanico che ti sta portando a New York accanto a tua madre Gloria. Guardi l'aereo solcare il cielo sopra le nuvole e ripensi ai due giorni trascorsi nel buio del Casermone e al momento in cui hai visto spuntare le torce dei soccorritori guidati da Ted e Kat.  
Scrivi una pagina del tuo **diario di bordo**:
- Racconta il terrore vissuto all'ultimo piano di Barrington Heights, mentre sentivi la pioggia battere sui vetri rotti e temevi che le cariche esplosive demolissero l'edificio con te dentro;
- Esprimi la gratitudine infinita per tuo cugino Ted, spiegando come solo una mente come la sua potesse ricordarsi della tua passione per le altezze e dedurre il tuo nascondiglio;
- Descrivi la nuova prospettiva con cui guardi ora tua madre (che ha finalmente buttato via le sigarette) e tuo padre Rashid, guardando all'America non più come a una condanna ma come a una nuova sfida da affrontare a testa alta.

---

## 5. Laboratorio Lessicale e Modi di Dire

*Associa ciascun vocabolo o espressione d'autore al suo significato nel contesto del racconto (indica sul quaderno la combinazione corretta numero-lettera).*

| Termine o Modo di Dire | Abbinamento | Significato Contestuale |
| :--- | :---: | :---: |
| 1. **Mister Unico** | | A. Macchine operatrici da cantiere munite di pinze idrauliche ad alta pressione impiegate per sbriciolare e demolire pilastri e blocchi di cemento armato. |
| 2. **Due piselli in un baccello** | | B. Vasto sistema barico di alta pressione che garantisce condizioni meteorologiche stabili, cieli limpidi e venti moderati di rotta. |
| 3. **Non lasciare nulla di intentato** | | C. Titolo affettuoso che riconosce e nobilita la straordinaria e irripetibile originalità cognitiva ed etica di un individuo. |
| 4. **Anticiclone atlantico** | | D. Espressione proverbiale anglosassone (*two peas in a pod*) usata per descrivere due persone strettamente affini per temperamento, indole e reazioni. |
| 5. **Frantumatori di calcestruzzo** | | E. Locuzione figurata usata in ambito operativo per indicare una ricerca instancabile, minuziosa e condotta a 360 gradi senza trascurare alcuna pista. |

---

## 6. Attività Speciale "Fuori dagli Schemi"

**Stemma e Simbologia: L'Emblema del "Sistema Operativo Ted"**  
Al termine della vicenda, Ted ha dimostrato che ciò che il mondo considerava una bizzarria è in realtà una risorsa logica straordinaria che ha strappato Salim a una fine tragica.  
Realizza sul tuo quaderno lo **Stemma Simbolico del "Sistema Operativo Ted"**:

1. **Lo Scudo Araldico e i Quattro Quarti Tematici:**
   - Disegna lo scudo araldico bipartito in quattro quadranti, assegnando a ciascuno un simbolo cardinale della storia:
     - *Primo Quarto (La Scienza e il Cielo):* Una rosa dei venti o una nube a sviluppo verticale attraversata da un barometro (la passione scientifica di Ted);
     - *Secondo Quarto (La Ruota e la Prospettiva):* La sagoma circolare del London Eye con i raggi a bicicletta (la capacità di vedere la realtà oltre le apparenze da 135 metri);
     - *Terzo Quarto (La Solidarietà Fraterna):* Due mani che si uniscono o due profili complici (l'alleanza indissolubile nata tra Kat e Ted);
     - *Quarto Quarto (La Salvezza e la Vetta):* La torre di Barrington Heights con una luce al 24° piano e un cormorano che riemerge dai flutti del Tamigi (il trionfo della vita).

2. **Il Cartiglio e il Motto Ufficiale:**
   - Traccia alla base dello scudo un nastro decorativo con un motto inciso a caratteri capitali (es. *«DIFFERENTIA NON EST DEFECTUS - MISTER UNICO»* oppure *«GUARDANDO OLTRE LE APPARENZE»*).

3. **Il Rilievo Grafico dell'Emblema:**
   - Esegui il disegno dello stemma curando le proporzioni, i contorni e i dettagli simbolici di ciascun elemento.

[SPAZIO PER IL TUO DISEGNO / RILIEVO GRAFICO]

---

### GUIDA E RIASSUNTO PER IL DOCENTE

#### Riassunto sintetico dei capitoli
I capitoli finali portano a compimento la parabola investigativa, umana e relazionale del romanzo:
- **Capitolo 38 (*Ripercorrere i passi*):** Ore 22:03 di martedì sera. Marcus lascia casa Spark dopo aver restituito il telefono di Salim a Gloria, che nobilmente lo rincuora scagionandolo da ogni colpa. L'ispettrice Pearce mobilita la polizia metropolitana su Euston. Mandati a letto, Ted e Kat non riescono a dormire. Kat oscilla tra il terrore del rapimento a sfondo criminale e la disperazione. Ascoltando il bollettino dei naviganti di mezzanotte, Ted intuisce l'esistenza di una "Terza Teoria": ripercorrendo la psicologia di Salim, ricorda la sua ossessione per l'architettura monumentale, la vista del Casermone Barrington Heights (la torre di 24 piani in cui lavora il padre) e l'acquisto della macchina fotografica usa e getta. Salim voleva scattare foto aeree dall'alto prima di partire per New York ed è salito clandestinamente nel Casermone, rimanendovi intrappolato proprio alla vigilia della demolizione controllata programmata per l'indomani mattina.
- **Capitolo 39 (*Pioggia notturna*):** Kat grida richiamando i genitori. Ted espone la deduzione: Salim è bloccato al Casermone. Il padre, consapevole dell'imminente brillamento delle cariche, corre all'auto con tutta la famiglia nella pioggia battente, avvertendo vigili del fuoco e polizia. Il padre apre i cancelli blindati del cantiere; le squadre perlustrano piano per piano la torre deserta. Al ventiquattresimo piano, in un appartamento dismesso chiuso dall'esterno, le torce illuminano Salim: è infreddolito, spaventato e disidratato, ma vivo. Gloria si getta su di lui in un pianto liberatorio.
- **Capitolo 40 (*Dopo la tempesta*):** Salim racconta la dinamica: dopo la separazione da Marcus a Euston, è tornato verso casa Spark ma è stato attirato dal Casermone; approfittando dell'allontanamento momentaneo del custode andato a comprare le sigarette, è salito in cima per fotografare Londra; il custode è rientrato, ha sbarrato le porte con catene e lucchetti e Salim, privo di cellulare, è rimasto bloccato nel buio per quasi due giorni. Il custode viene licenziato.
- **Capitolo 41 (*L'ultimo giro della ruota*):** Giovedì mattina all'aeroporto. Salim e Gloria partono per New York: Salim stringe la mano a Ted chiamandolo affettuosamente «Mister Unico» e dandogli appuntamento in America; Gloria consegna a Ted il bocchino e il portasigarette per buttarli, onorando la promessa di smettere di fumare e diventando la sua sesta amica. A casa, il padre cucina la sua speciale frittata fischiettando Stanlio e Ollio; come ricompensa, Ted riceve un orologio meteorologico con barometro e bussola (che accresce del 31,5% la sua precisione predittiva), mentre Kat si fa tagliare i capelli da Hair Flair; Ted le fa un complimento compassionevole (la sua terza bugia, annotata nella cartellina argentata *Le mie bugie*). Infine, il Casermone viene abbattuto: dalla strada di casa Spark ora si scorge in lontananza il profilo scintillante del London Eye, dove nella mente di Ted la figura di Salim continua a salutare sorridente all'infinito.

#### Soluzioni ed elementi chiave di correzione
- **1. Comprensione del Testo:**
  1. *La Terza Teoria e la passione per le vette:* Ted supera la dicotomia rigida tra fuga e sequestro analizzando la personalità del cugino: Salim era affascinato dalle strutture verticali e desiderava documentare Londra dall'alto con la fotocamera usa e getta prima del volo transoceanico. Questo desiderio estetico lo ha spinto a violare il cantiere del Casermone approfittando della porta lasciata aperta.
  2. *La trappola del 24° piano e la corsa contro il tempo:* Salim è salito al 24° livello mentre il guardiano si assentava per fumare; al suo ritorno, l'addetto ha sprangato gli ingressi blindati ignorando che ci fosse qualcuno all'interno. La corsa è disperata perché l'edificio è già minato e programmato per la distruzione controllata all'alba seguente: poche ore di ritardo avrebbero significato la morte del ragazzo sotto le macerie.
  3. *Il riscatto di zia Gloria e l'addio al fumo:* Gloria affida a Ted i suoi strumenti da fumatrice (bocchino e astuccio) suggellando il proprio voto morale di rinascita e purificazione. L'atto segna la trasformazione della zia da figura caotica e distruttiva («Uragano Gloria») a persona capace di gratitudine profonda, conquistandosi un posto nel ristretto cerchio affettivo di Ted («la mia sesta amica»).
  4. *I doni e la terza bugia di Ted:* Ted sceglie uno strumento scientifico rigoroso (l'orologio barometrico multifunzione), mentre Kat sceglie un'affermazione estetica di identità adolescenziale. Ted afferma che il taglio sfilato e bizzarro della sorella è «fantastico»: è una bugia pietosa e altruistica, archiviata nella cartellina argentata, che denota la sua acquisita sensibilità diplomatica verso i sentimenti altrui.
  5. *Il nuovo panorama e l'eterno giro della ruota:* La scomparsa del Casermone rimuove una barriera visiva opprimente e apre lo sguardo direttamente verso il Tamigi e il London Eye. L'immagine di Salim sulla ruota si trasforma in un'icona interiore permanente: la memoria traumatica della sparizione viene sublimata nella celebrazione poetica di un legame fraterno che né il tempo né la distanza potranno spezzare.
- **2. Vero o Falso:**
  1. **VERO.** Il custode ha abbandonato la postazione per comprare sigarette e al ritorno ha chiuso con catene e lucchetti senza ispezionare l'edificio.
  2. **FALSO.** I soccorritori e il padre forzano l'accesso al 24° piano e trovano Salim infreddolito ma cosciente che abbraccia la madre.
  3. **VERO.** L'orologio include bussola e barometro, incrementando la precisione dei pronostici di Ted del 31,5%.
  4. **FALSO.** Salim si congeda con profondo affetto, stringe la mano a Ted chiamandolo «Mister Unico» e dandogli appuntamento a New York.
  5. **VERO.** L'abbattimento della torre residenziale dischiude un varco panoramico che rende visibile metà del London Eye dalla via di casa.
- **3. Analisi dei Personaggi:**
  1. *«Mister Unico»: la celebrazione della diversità:* Il romanzo si conclude con la piena riabilitazione della neurodivergenza. L'epiteto «Mister Unico» sancisce che la mente di Ted non è guasta né inferiore, ma dotata di un'eccezionalità cognitiva che ha colmato i punti ciechi di poliziotti, genitori e investigatori. La famiglia non cerca più di "normalizzarlo", ma impara a stimarlo per la sua insostituibile originalità.
  2. *La cartellina delle bugie e la maturazione empatica:* La nascita della cartellina *Le mie bugie* testimonia il raggiungimento di una sofisticata teoria della mente. Ted comprende che la verità letterale non è sempre la scelta più etica: quando una piccola bugia preserva l'armonia, conforta un affetto ferito o sostiene la fiducia di una sorella, mentire diventa un atto di squisita intelligenza relazionale ed empatica.
- **4. Officina di Scrittura:** Criteri di valutazione: resa fedele della voce interiore di Salim (linguaggio maturo, riconoscente e riflessivo); descrizione credibile dell'angoscia provata durante la reclusione al 24° piano del Casermone; espressione di gratitudine autentica per il genio logico di Ted; serenità e speranza nel guardare al futuro americano e al legame familiare ritrovato.
- **5. Laboratorio Lessicale:** Combinazione corretta: `1-C, 2-D, 3-E, 4-B, 5-A`.
- **6. Attività Speciale:** Criteri di osservazione: completezza araldica dello scudo diviso in quattro quarti tematici; pertinenza simbolica delle figure (meteo, ruota panoramica, mani/profili fraterni, torre con cormorano); originalità del motto inciso nel cartiglio; accuratezza estetica e leggibilità del rilievo grafico.

[[FINE]]
