[[FILE: blocco_09_esercizi.md]]
# SCHEDA DIDATTICA DI LETTURA E COMPRENSIONE
## *Il mistero del London Eye* di Siobhan Dowd
### Unità Didattica 9 (Blocco 9): *L'effetto Coriolis* – *Inseguimento*

---

> ### 🌊 Forze invisibili che deviano il cammino
> «L'effetto Coriolis è una forza potente nel mondo: non puoi vederla né toccarla, ma esiste e devia le traiettorie dei corpi. [...] Pensai alla sparizione di Salim: forse seguire le sue tracce era come seguire il meteo, solo che non conoscevamo l'effetto Coriolis che lo aveva fatto deviare dalla sua rotta. Ma qualcosa lo aveva deviato.»  
> L'indagine esce dalle mura protette di casa Spark e si trasforma in una rischiosa caccia all'uomo nella giungla urbana di Londra. Sfidando la propria disorientazione spaziale e il terrore della folla, Ted viaggia da solo nella metropolitana e raggiunge la sorella nell'immenso salone fieristico di Earl's Court. Tra il frastuono assordante dei motori e le sagome dei biker, Kat e Ted individuano finalmente Christy, l'uomo della maglietta, dando inizio a un pedinamento mozzafiato che si concluderà davanti alle vetrine di un pub con un drammatico faccia a faccia.

---

## 1. Comprensione del Testo

*Rispondi alle domande sul tuo quaderno in modo completo, motivando con riferimenti precisi al testo.*

1. **La metafora fisica dell'effetto Coriolis:** Nel Capitolo 26, mentre cammina da solo verso la metropolitana, Ted riflette sull'effetto Coriolis e sulla differente velocità tangenziale tra l'equatore e i poli. Quale analogia stabilisce tra questa deviazione fisica invisibile e la traiettoria interrotta della vita di Salim?
2. **L'orientamento attraverso le nubi:** Trovandosi disorientato nelle strade del quartiere a causa della sua difficoltà a distinguere la destra dalla sinistra («geografo dislessico»), come riesce Ted a ritrovare la direzione corretta verso la stazione senza usare una mappa tradizionale?
3. **L'impatto sensoriale nell'«Inferno dei Motociclisti»:** Nel Capitolo 27, Ted fa il suo ingresso nel monumentale centro fieristico di Earl's Court per il salone delle moto. Quali violente stimolazioni sensoriali (acustiche, visive e olfattive) mettono a dura prova il suo sistema operativo e come avviene l'incontro inaspettato con Kat?
4. **Le regole del pedinamento e la tecnica del "ciondolare":** Nel Capitolo 29, quando Christy finisce il turno e si incammina verso la metropolitana, Kat ordina a Ted di non correre ma di «ciondolare» (*saunter*). Che cosa significa questo comando per Ted e come riescono i due fratelli a seguire il sospettato fino al pub *Falcon Arms* senza farsi scoprire?
5. **Lo shock dei diciotto schermi e l'imboscata finale:** Mentre attendono fuori dal pub davanti alla vetrina di un negozio di televisori, quale immagine sconvolgente appare contemporaneamente su tutti i diciotto schermi accesi e quale colpo di scena conclude improvvisamente il capitolo alle loro spalle?

---

## 2. Vero o Falso? (Attenzione ai dettagli)

*Indica nella tabella se l'affermazione è Vera (V) o Falsa (F). Correggi e motiva sul tuo quaderno le affermazioni false.*

| Affermazione | V | F |
| :--- | :---: | :---: |
| 1. A causa dell'effetto Coriolis, un corpo lanciato dall'equatore verso nord tende a deviare verso destra nell'emisfero settentrionale e verso sinistra in quello meridionale. | | |
| 2. Per accedere al salone motociclistico di Earl's Court, Ted scavalca furtivamente i tornelli di sicurezza approfittando della distrazione dei guardiani. | | |
| 3. Quando si ricongiunge a Kat tra gli stand della fiera, scopre che la sorella ha già fatto arrestare l'uomo del biglietto dalla polizia presente nel padiglione. | | |
| 4. L'insegna del pub *Falcon Arms* mostra un falco posato su un ramo con un topo nel becco, la cui coda svolazzante suggerisce a Ted la presenza di un vento di burrasca forza sette. | | |
| 5. Fuori dal pub, mentre i ragazzi guardano il telegiornale nella vetrina, l'uomo misterioso scappa a bordo di una motocicletta sportiva senza accorgersi della loro presenza. | | |

---

## 3. Analisi dei Personaggi e Riflessione

*Rifletti sulle scelte e sulle emozioni dei protagonisti e rispondi sul quaderno.*

1. **La sfida sensoriale del coraggio:** Per un ragazzo nello spettro autistico con ipersensibilità sensoriale, attraversare la metropolitana da solo e immergersi nell'«Inferno dei motociclisti» (rombi assordanti di motori, folla che urta, luci stroboscopiche, odore acre di benzina) rappresenta un atto di eroismo pari a un'impresa epica. Da dove trae Ted la forza morale per dominare il proprio sovraccarico sensoriale e non fuggire?
2. **Il confine tra ingenuità e pericolo reale:** Kat e Ted pedinano un uomo adulto sconosciuto, potenzialmente coinvolto in una scomparsa misteriosa, muovendosi per le strade di Londra senza alcun supporto adulto e appostandosi fuori da un pub degradato. Quale giudizio etico si può esprimere sull'incoscienza adolescenziale dei due protagonisti e sul rischio reale a cui si espongono per senso di lealtà verso il cugino?

---

## 4. Officina di Scrittura Creativa ed Empatia

*Mettiti nei panni di uno dei protagonisti e svolgi l'attività sul tuo quaderno.*

Immagina di essere **Christy**, la giovane guardia giurata della Frontline Security, mentre sei seduto al bancone del pub *The Falcon Arms* davanti alla tua birra scura intatta. Hai appena visto al notiziario l'appello disperato della zia di Salim con la foto del ragazzo scomparso e senti il cuore battere all'impazzata. Poi esci dal locale e ti accorgi che i due ragazzini del London Eye ti stavano spiando dalla vetrina di fronte.  
Scrivi il tuo **monologo interiore**:
- Racconta il panico e il senso di colpa provati nel vedere la faccia di quel ragazzino alla televisione, confessando il ruolo reale che hai avuto nello scambio del biglietto sul London Eye;
- Spiega perché ti sei rifugiato nel pub a bere e cosa hai pensato vedendo che la vicenda sta diventando un caso nazionale di cronaca nera;
- Descrivi l'istante in cui hai riconosciuto Kat e Ted riflessi nella vetrina del negozio di televisori e la decisione rabbiosa di affrontarli faccia a faccia.

---

## 5. Laboratorio Lessicale e Modi di Dire

*Associa ciascun vocabolo o espressione d'autore al suo significato nel contesto del racconto (indica sul quaderno la combinazione corretta numero-lettera).*

| Termine o Modo di Dire | Abbinamento | Significato Contestuale |
| :--- | :---: | :---: |
| 1. **Effetto Coriolis** | | A. Modo di dire idiomatico inglese (*stick out like a sore thumb*) usato per indicare chi o cosa si fa notare in modo goffo, evidente e fuori luogo. |
| 2. **Velocità tangenziale** | | B. Andatura lenta, rilassata e dinoccolata, adottata tatticamente per non dare nell'occhio e simulare disinteresse durante un pedinamento. |
| 3. **Geografo dislessico** | | C. Definizione autoironica con cui Ted indica la sua difficoltà a decodificare le mappe tradizionali e a distinguere la destra dalla sinistra. |
| 4. **Ciondolare** | | D. Forza fisica apparente generata dalla rotazione terrestre che provoca la deviazione laterale della traiettoria dei corpi in movimento libero. |
| 5. **Sentirsi un pesce fuor d'acqua** | | E. Misura lineare della rapidità con cui un punto ruota lungo la traiettoria circolare, massima all'equatore e nulla ai poli geografici. |

---

## 6. Attività Speciale "Fuori dagli Schemi"

**Dossier Investigativo: Il Pedinamento del Sospettato Christy**  
L'indagine ha finalmente un volto e un nome: Christy, l'addetto alla sicurezza della Frontline Security immortalato negli scatti del London Eye.  
Vesti i panni di un detective e redigi sul tuo quaderno la seconda scheda del **Dossier di Pedinamento Forense**:

1. **Identikit e Rilievi Comportamentali del Bersaglio:**
   - Dati anagrafici ricavati: Christy, guardia non armata presso la Frontline Security di Battersea;
   - Caratteristiche somatiche e abbigliamento: barba incolta di tre giorni, sopracciglia arcuate, giacca in pelle logora, andatura a testa bassa;
   - Indicatori psicologici di stress: frequente consultazione dell'orologio, sguardi guardinghi, rifugio solitario in un locale pubblico, consumo nervoso di bevande alcoliche.

2. **Cronistoria e Tracciato del Pedinamento:**
   - Orario e modalità di uscita dall'Earl's Court Exhibition Centre;
   - Tragitto sotterraneo: banchina della metropolitana, cambio di convoglio e discesa;
   - Percorso pedonale in superficie fino all'ingresso del pub *The Falcon Arms*.

3. **La Scena della Vetrina TV e la Cattura:**
   - Ricostruisci graficamente la posizione dei soggetti all'angolo della strada (la vetrina dei 18 monitor con l'appello di Gloria, il punto di sosta dei ragazzi, l'angolo d'attacco alle spalle compiuto da Christy);
   - Formula due ipotesi sul reale movente del sospettato: era a conoscenza della scomparsa o è stato a sua volta ingannato?

[SPAZIO PER IL TUO DISEGNO / RILIEVO GRAFICO]

---

### GUIDA E RIASSUNTO PER IL DOCENTE

#### Riassunto sintetico dei capitoli
I capitoli 26–29 costituiscono la sequenza di massima tensione dinamica e pedinamento urbano dell'opera:
- **Capitolo 26 (*L'effetto Coriolis*):** Ted intraprende il suo primo viaggio in solitaria. Camminando verso la metropolitana riflette sull'effetto Coriolis (la forza d'inerzia che devia i corpi a causa della diversa velocità tangenziale terrestre tra equatore e poli), istituendo un parallelismo con la sparizione di Salim, deviato dalla propria traiettoria da una forza invisibile. Disorientato per via della sua difficoltà a distinguere destra e sinistra («geografo dislessico»), si orienta guardando la sagoma di un cumulonimbus all'orizzonte. Raggiunta la metropolitana, si affida alla mappa topologica del metrò, conta scrupolosamente le fermate sulla Northern Line ed effettua lo scambio a Embankment verso la District Line in direzione Earl's Court.
- **Capitolo 27 (*Inferno per motociclisti*):** Ted giunge all'Earl's Court Exhibition Centre, dove si svolge il rombante salone delle moto. L'ambiente è un incubo sensoriale: decibel assordanti, fumi di scarico, luci violente e folla di biker. Ted paga regolarmente il biglietto da 12 sterline usando le monete del suo forziere. Mentre cerca faticosamente di orientarsi tra i padiglioni controllando lo sfarfallio della mano, scorge improvvisamente una figura familiare: è Kat, arrivata prima di lui per perlustrare gli stand.
- **Capitolo 28 (*Incontri*):** I due fratelli si confrontano: Kat ha scoperto a sua volta la presenza delle guardie a Earl's Court. Ispezionando i varchi della fiera, individuano l'uomo della maglietta: è Christy, riconoscibile per la barba rada, il giubbotto di pelle e le sopracciglia scure. L'uomo appare teso e nervoso, scruta continuamente il cellulare e si toglie il pass aziendale al termine del turno. Kat decide di pedinarlo senza perderlo di vista.
- **Capitolo 29 (*Inseguimento*):** Comincia il pedinamento: Kat insegna a Ted a «ciondolare» (*saunter*), camminando con finta indifferenza per non allarmare il bersaglio. Salgono sullo stesso convoglio della metropolitana e lo seguono in superficie fino a un pub fatiscente, il *Falcon Arms*. Christy entra a bere una birra al bancone mentre osserva la TV. Kat e Ted restano fuori appostati davanti alla vetrina di un negozio di elettrodomestici sintonizzato sul notiziario. Improvvisamente, su diciotto schermi in simultanea, appare il salotto di casa Spark con l'appello straziante di zia Gloria e la foto di Salim. Mentre i ragazzi fissano sbigottiti lo schermo, due mani pesanti e vigorose afferrano le spalle di entrambi: è Christy, con gli occhi ridotti a fessure per la rabbia, che sibila minaccioso: «Ancora voi!».

#### Soluzioni ed elementi chiave di correzione
- **1. Comprensione del Testo:**
  1. *La metafora fisica dell'effetto Coriolis:* L'effetto Coriolis devia gli oggetti dalla linea retta a causa della rotazione del pianeta, pur operando come una forza invisibile. Ted vi intravede la chiave del mistero: Salim non si è dissolto nel nulla, ma è stato deviato dalla sua rotta ordinaria da un fattore imprevisto (un complice o una scelta segreta) che ne ha alterato la direzione all'insaputa dei parenti.
  2. *L'orientamento attraverso le nubi:* Trovandosi smarrito a causa della propria difficoltà a orientarsi con i nomi delle vie e le mappe topografiche tradizionali, Ted usa la meteorologia come bussola naturale: individua un cumulonimbus in espansione verso nord-ovest che aveva osservato prima da casa, usandolo come punto cardinale celeste per raggiungere la stazione del metrò.
  3. *L'impatto sensoriale nell'«Inferno dei Motociclisti»:* Ted sperimenta un bombardamento sensoriale paralizzante: il rombo fragoroso delle marmitte, l'odore asfissiante di idrocarburi e cibo fritto, la massa caotica di giubbotti di cuoio. Il suo sistema operativo rischia il collasso, ma l'avvistamento inaspettato di Kat trasforma il panico in determinazione operativa.
  4. *Le regole del pedinamento e la tecnica del "ciondolare":* «Ciondolare» significa avanzare a passo sciolto, lento e distratto, evitando movimenti bruschi o sguardi fissi che possano insospettire il bersaglio. Ted fatica a recitare questa parte disinvolta ma si sforza di sincronizzarsi con la sorella, riuscendo a seguire l'uomo fino al pub senza allarmarlo.
  5. *Lo shock dei diciotto schermi e l'imboscata finale:* Sugli schermi del negozio appare l'appello televisivo girato poco prima a casa Spark, con la zia in lacrime e il volto di Salim moltiplicato per diciotto volte. Mentre i fratelli sono ipnotizzati dalla trasmissione, Christy esce dal pub e li blocca cogliendoli alle spalle con violenza e furore.
- **2. Vero o Falso:**
  1. **VERO.** La legge fisica stabilisce la deviazione destrorsa nell'emisfero nord e sinistrorsa nell'emisfero sud a causa della rotazione terrestre.
  2. **FALSO.** Ted paga regolarmente il biglietto d'ingresso di 12 sterline attingendo alle monete risparmiate nel suo forziere.
  3. **FALSO.** Kat sta conducendo un appostamento discreto e pedina l'uomo senza aver allertato nessuno.
  4. **VERO.** Ted osserva la banderuola e la coda del topo dipinto sull'insegna, stimando la forza del vento a forza sette della scala Beaufort.
  5. **FALSO.** Christy esce dal pub cogliendo i due ragazzi di sorpresa e afferrandoli con forza per le spalle con fare minaccioso.
- **3. Analisi dei Personaggi:**
  1. *La sfida sensoriale del coraggio:* La prova affrontata da Ted è straordinaria: per un individuo neurodivergente con ipersensibilità uditiva e cinetica, il salone delle moto è paragonabile a una tortura fisica. Dominare lo sfarfallio della mano e la nausea all'esofago in nome dell'amore per la sorella e il cugino dimostra che il coraggio morale può prevalere sui limiti neurobiologici.
  2. *Il confine tra ingenuità e pericolo reale:* Kat e Ted dimostrano una dedizione ammirevole ma incosciente: pedinare un uomo adulto e forte in un quartiere isolato espone i minori a rischi gravissimi di aggressione. La scena evidenzia la tipica presunzione adolescenziale di invulnerabilità, che porta i ragazzi a sfidare pericoli mortali pur di non dipendere dal fallimento degli adulti.
- **4. Officina di Scrittura:** Criteri di valutazione: assunzione fedele del punto di vista di Christy (registro teso, gergale e tormentato); spiegazione logica e coerente delle motivazioni che lo hanno spinto ad accettare lo scambio del biglietto al London Eye; resa drammatica del panico nel riconoscere la trasmissione televisiva e del confronto fisico finale con i ragazzi.
- **5. Laboratorio Lessicale:** Combinazione corretta: `1-D, 2-E, 3-C, 4-B, 5-A`.
- **6. Attività Speciale:** Criteri di osservazione: precisione descrittiva e forense dell'identikit di Christy; accuratezza cronologica nella mappatura degli spostamenti tra fiera, metro e pub; qualità grafica della pianta della strada con la posizione della vetrina televisiva e dell'agguato alle spalle.

[[FINE]]
