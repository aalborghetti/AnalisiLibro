# SCHEDA DIDATTICA DI LETTURA E COMPRENSIONE
## *I lucci della via Lago* di Giuseppe Festa
### Unità Didattica 2 (Blocco 2): *Un luccio non può annegare* – *La frega delle alborelle*

---

> ### 🐟 Un segreto tra le onde e il richiamo della notte
> L'incredulità e il dolore stringono la gola a tutta la via Lago: i sommozzatori cercano nelle acque scure, ma per Mauri accettare l'inaccettabile è impossibile. Due giorni dopo, la natura compie il suo rito annuale: le alborelle accorrono a milioni a riva per la frega. Tra guardiapesca in agguato nella notte e ricordi che bruciano, comincia per i ragazzi un lungo cammino di resistenza e lealtà.

---

## 1. Comprensione del Testo

*Rispondi sul tuo quaderno in modo chiaro e completo, argomentando con riferimenti al testo.*

1. **La reazione di fronte all'evidenza:**  
   Nel capitolo *Un luccio non può annegare*, quale spiegazione tenta di dare il ragazzino di città, Angelo, e perché Mauri reagisce con tanta rabbia alle sue parole? Qual è la convinzione incrollabile a cui Mauri si aggrappa disperatamente?
   

2. **I testimoni e i primi rilievi:**  
   Chi sono gli adulti presenti sul pontile durante le ricerche? Quale testimonianza fornisce il "Generale" con il suo sigaro toscano e che cosa riferisce il maresciallo Girelli dopo aver parlato con il vecchio Santiago?
   

3. **Villa Lago e il privilegio dei custodi:**  
   Qual è il legame speciale tra la famiglia di Mauri e la maestosa Villa Lago appartenente alla Signora De Brochet? Perché questo ruolo garantisce ai ragazzi una libertà di movimento e di pesca che tutti gli altri coetanei di Predore invidiano?
   

4. **Il rito sacro della "frega":**  
   Che cos'è la "frega delle alborelle"? Come funziona il "bilancino" utilizzato da Fabi e Trapola e per quale motivo i ragazzi scelgono proprio la riva del giardino Italia per calarlo in acqua?
   

5. **L'agguato di Batman e la lezione del fratello maggiore:**  
   Chi è il personaggio soprannominato "Batman" e come fa a sorprendere i ragazzi? Perché, nonostante il lago brulichi ancora di pesci, Fabi decide di fermarsi dopo un solo secchio pieno, richiamando la regola del fratello maggiore Vince?
   

---

## 2. Vero o Falso? (Attenzione ai dettagli)
*Indica nella tabella se l'affermazione è Vera (V) o Falsa (F). Correggi e motiva sul tuo quaderno le affermazioni false.*

| Affermazione | V | F |
| :--- | :---: | :---: |
| 1. Il subacqueo riferisce a Mauri che ha perlustrato anche il vecchio scolo dell'acqua (il tunnel), ma che il condotto si interrompe dopo pochi metri. | | |
| 2. La partita dei Mondiali di Spagna Italia-Polonia finisce con una schiacciante vittoria degli azzurri per 3 a 0. | | |
| 3. Fabi viene chiamato anche "Orzowei" perché ama stare a petto nudo e scalzo in ogni stagione dell'anno. | | |
| 4. Il guardiapesca di Predore ha il permesso di entrare di notte a piedi nel parco privato di Villa Lago per cogliere i ragazzi sul fatto. | | |
| 5. Trapola vorrebbe continuare a pescare per riempire una betoniera, ma Fabi gli spiega che bisogna accontentarsi di ciò che serve alla famiglia. | | |

---
## 3. Analisi dei Personaggi e Riflessione

### La psicologia del lutto: Il rifiuto della verità
*Quando un evento è troppo doloroso per essere accettato, la mente umana costruisce barriere difensive.*

- **Domanda di analisi:**  
  Mauri ripete a se stesso e al maresciallo: *«Non è morto... Sarà nascosto da qualche parte nel parco della Villa, ci scommetto. Gli piace fare gli scherzi»*.  
  Analizza questo comportamento: si tratta di semplice ingenuità o di un meccanismo di autodifesa psicologica per non crollare? In che modo il soprannome stesso della banda («i Lucci») alimenta l'illusione che Brando sia immune ai pericoli dell'acqua?
  

---

## 4. Officina di Scrittura Creativa ed Empatia

### La luce nella notte
*Mettiti nei panni di Fabi o di Trapola.*

Vedere il tuo amico Mauri "mummiato" sul divano da due giorni, svuotato di ogni energia, ti fa male al cuore. Decidi di trascinarlo a forza al lago nella notte della frega, sperando che il rito della pesca e l'odore dell'acqua possano scuoterlo dal torpore.

✍️ **Traccia:** Scrivi sul tuo quaderno una breve pagina di diario personale o una riflessione dal punto di vista di Fabi (12-15 righe), raccontando cosa hai provato nel momento in cui hai visto Mauri accendere la torcia e guardare le alborelle brillare: cosa significa per te essere un vero amico nei momenti bui?


---

## 5. Laboratorio Lessicale e Modi di Dire
*Associa ciascun vocabolo al suo significato nel contesto del racconto (indica sul quaderno la combinazione corretta numero-lettera).*

| Termine o Modo di Dire | Abbinamento | Significato Contestuale |
| :--- | :---: | :---: |
| 1. **Frega** | | A. Rete quadrata montata su due archi incrociati usata per pescare da riva o dalla barca. |
| 2. **Bilancino** | | B. Stare completamente fermo, immobile e inerte come una mummia priva di reazioni. |
| 3. **Mummiato** | | C. Periodo dell'anno in cui i pesci si radunano in acque basse per deporre e fecondare le uova. |
| 4. **Macarù** | | D. Pescare violando i divieti di legge, in tempi o luoghi non consentiti (bracconaggio). |
| 5. **Pescare di frodo** | | E. Espressione dialettale lombarda per indicare una persona sciocca o credulona. |

---

## 6. Attività Speciale "Fuori dagli schemi" 🧭
### 🌿 Compito di Realtà: Il Decalogo del Pescatore Etico

> **Il dilemma morale del capitolo:**  
> I ragazzi pescano durante la frega (attività vietata dalla legge per proteggere la riproduzione della specie) e rischiano le sanzioni del guardiapesca "Batman". Tuttavia, seguono una loro ferrea regola morale tramandata dal fratello maggiore: *«Accontentiamoci. Se la mamma le mette sott'olio, queste bastano fino alla prossima frega... e poi cosa ne facciamo, le diamo alle galline?»*. Rifiutano l'ingordigia di riempire un'intera betoniera.

**Lavoro cooperativo (in coppia o piccolo gruppo):**

1. **Il Processo alle Alborelle (Confronto critico):**  
   Rifletti sul tuo quaderno evidenziando le due posizioni a confronto:
   - *Le ragioni della legge di tutela ecologica:* Perché la frega è protetta da divieti assoluti?
   - *Le ragioni della tradizione dei ragazzi:* Perché per la banda è un rito sacro di sussistenza e identità?

2. **Redigi il "Decalogo del Pescatore del Lago":**  
   Scrivi sul tuo quaderno 4 regole fondamentali che ogni giovane pescatore dovrebbe rispettare per vivere l'avventura senza saccheggiare l'ecosistema del lago.
---

# GUIDA E RIASSUNTO PER IL DOCENTE

### 📌 Scheda di Sintesi del Capitolo
- **Capitolo/Sezione:** Unità 2 (composta da *Un luccio non può annegare*, *La frega delle alborelle*).
- **Pagine di riferimento:** pp. 21–34.
- **Data e Luogo:** 14 giugno pomeriggio (subito dopo l'incidente) e 16 giugno sera (due giorni dopo); Predore, molo della darsena e giardino Italia di Villa Lago.
- **Personaggi introdotti/approfonditi:** 
  - **Fabi (Fabiano, detto "Orzowei"):** Fratello minore di Mauri, spirito selvaggio, leale, scalzo, custode delle tradizioni piscatorie e del bilancino.
  - **Nazzareno (detto "Trapola"):** Amico fedele della banda, parla in modo buffo, entusiasta ed energico.
  - **Il Generale:** Anziano del paese con cappello di paglia e toscano in bocca; è lui ad aver allertato i carabinieri.
  - **Maresciallo Girelli:** Comandante della stazione carabinieri locale.
  - **Signora De Brochet:** Ricca proprietaria di Villa Lago, di cui i genitori di Mauri sono custodi.
  - **Batman:** Il temuto guardiapesca di Predore, instancabile persecutore dei pescatori di frodo.

### 📖 Sinossi per il docente
Il capitolo 7 descrive i concitati momenti successivi alla scomparsa di Brando: l'arrivo dell'ambulanza, dei carabinieri e dei sommozzatori che scandagliano la darsena e l'imbocco del condotto di scolo senza trovare tracce. Mauri, sotto shock e congelato dal trauma, respinge le insinuazioni di Angelo e l'ipotesi della morte: è convinto che Brando si sia nascosto nel parco per fargli uno scherzo madornale. Il silenzio assordante della partita inaugurale Italia-Polonia (0-0) fa da specchio al suo intorpidimento emotivo.  
Due giorni dopo (capitolo 8), mentre le ricerche si spostano verso Sarnico, Fabi e Trapola strappano Mauri dall'apatia del divano per partecipare alla "frega delle alborelle", l'annuale raduno riproduttivo a riva. Armati di bilancino, pescano furtivamente nel giardino Italia di Villa Lago, scampando per un soffio al blitz del guardiapesca "Batman" arrivato a remi nel buio. Nonostante l'abbondanza incredibile di pesci, i ragazzi si fermano al primo secchio pieno nel rispetto della lezione morale del fratello maggiore Vince: prendere solo ciò che serve alla famiglia e non sprecare le risorse del lago.

### 🎯 Nuclei Didattici e Spunti di Discussione in Classe
1. **L'elaborazione del trauma e il ruolo dell'amicizia:** L'atteggiamento di Fabi e Trapola dimostra come l'affetto dei pari possa rompere l'isolamento depressivo senza bisogno di troppe parole, attraverso la condivisione di un'azione concreta.
2. **Etica della sostenibilità contro lo spreco:** La scelta di non riempire ulteriori secchi benché il lago fosse colmo di prede offre lo spunto ideale per educare gli alunni alla consapevolezza ecologica e al consumo responsabile.
3. **Il fascino delle regole infrante e il rispetto degli anziani:** Il rapporto ambiguo con il guardiapesca "Batman" e il rispetto delle massime impartite dal fratello maggiore Vince.

### 🔑 Soluzioni e Risposte Attese (Chiavi di correzione)

#### 2. Vero o Falso:
1. **VERO.** Il subacqueo conferma che il vecchio scolo dell'acqua (che i ragazzi chiamano tunnel) si interrompe poco dopo e non c'è traccia del ragazzo.
2. **FALSO.** La partita di Vigo contro la Polonia finisce 0 a 0 senza alcuna emozione.
3. **VERO.** È scalzo, a petto nudo e con lunghi capelli scuri come il personaggio televisivo Orzowei.
4. **FALSO.** Villa Lago è proprietà privata invalicabile; Batman è costretto a pattugliare a remi dall'acqua e a fare agguati dalla riva lacustre.
5. **VERO.** Fabi e Mauri ricordano l'insegnamento di Vince: accontentarsi del necessario per la famiglia senza fare scempio.

#### 5. Laboratorio Lessicale:
- **1. Frega** → **C** (Periodo di riproduzione e deposizione delle uova dei pesci a riva)
- **2. Bilancino** → **A** (Rete quadrata su bacchette a croce)
- **3. Mummiato** → **B** (Immobile e inerte senza reazioni)
- **4. Macarù** → **E** (Termine lombardo/bergamasco per persona sciocca o credulona)
- **5. Pescare di frodo** → **D** (Bracconaggio ittico in violazione delle norme)

