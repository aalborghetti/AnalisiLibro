# SCHEDA DIDATTICA DI LETTURA E COMPRENSIONE
## *I lucci della via lago* di Giuseppe Festa  
### Unità Didattica 7 (Blocco 7): *Nessuno poteva saperlo* – *Tutto contro di noi*  
---

> *«Fabi mette a fuoco la scritta: "Pinna Mozza? Cos'è Pinna Mozza?" — "È il nome che avevamo dato al persico trota. È questo il punto. Nessuno poteva saperlo. Nessuno. Tranne me. E Brando."»*  
> *(Capitolo 20)*

---

## 1. Comprensione del Testo

### A. Domande a risposta aperta

Rispondi alle seguenti domande aperte argomentando con riferimenti precisi alle vicende dei capitoli 20, 21 e 22.

1. **La notte della festa e l'incontro con Santiago:** Come festeggia il paese di Predore la vittoria dell'Italia contro l'Argentina? Quale confidenza fa il vecchio pescatore Santiago a Mauri durante la pesca notturna al pontile e quale invito gli rivolge?
2. **Il terzo messaggio e lo shock di Mauri:** Quale frase è contenuta nel terzo biglietto trovato nella grondaia di Zuzù? Perché questa rivelazione sconvolge Mauri fino a fargli mancare l'equilibrio e fargli dubitare della realtà?
3. **L'ipotesi di Mauri e l'esplorazione subacquea:** Di fronte allo scetticismo del gruppo, quale spiegazione alternativa alla presenza di uno zombie propone Mauri per spiegare la scomparsa di Brando? Che cosa scopre Fabi immergendosi nel tunnel con la fune di sicurezza?
4. **La pista dei passaggi segreti:** Dove conduce la nuova pista investigativa di Nando? Perché i ragazzi sono costretti a organizzare un'infiltrazione notturna nella Chiesa Vecchia invece di consultare normalmente il testo?
5. **La nuotata notturna e il "trucco antistrizza":** Quali imprevisti rischiano di far fallire la spedizione notturna al Porto di Chiesa? Chi li soccorre dal fondo del lago e quale singolare consiglio offre per vincere la paura del buio subacqueo?

---

### B. Vero o Falso? (Attenzione ai dettagli)
*Indica nella tabella se l'affermazione è Vera (V) o Falsa (F). Correggi e motiva sul tuo quaderno le affermazioni false.*

| Affermazione | V | F |
| :--- | :---: | :---: |
| 1. Nella storica sfida dei Mondiali del 1982, l'Argentina batte l'Italia grazie a una tripletta di Maradona. | | |
| 2. Il nome in codice "Pinna Mozza" era conosciuto da tutti i ragazzi del paese e persino dal maresciallo Girelli. | | |
| 3. Nando propone di consegnare immediatamente il terzo biglietto alle autorità, ma Mauri si oppone fermamente. | | |
| 4. Le pietre del crollo viste da Fabi all'interno del tunnel subacqueo appaiono insolitamente pulite e prive di melma. | | |
| 5. Per raggiungere la sacrestia della chiesa, i ragazzi noleggiano un motoscafo a motore dal lungolago di Sarnico. | | |

---
## 2. Analisi e Riflessione

### A. Approfondimento del Personaggio e Riflessione
Nel Capitolo 21, Mauri formula un'ipotesi quasi disperata: *«E se Brando non fosse morto? Come fa ad annegare un Luccio, dai? Proprio lui, il più forte...»*.
* **Domanda di riflessione:** Rispondi sul tuo quaderno: Di fronte alla morte improvvisa di una persona cara o di un coetaneo, la mente umana tende spesso a rifiutare la realtà, preferendo aggrapparsi a spiegazioni improbabili pur di non pronunciare la parola "fine". Come giudichi il ragionamento di Mauri? È semplice ingenuità o una necessaria autodifesa del cuore per sopportare il senso di colpa?

### B. Officina di Scrittura ed Empatia
Rileggi la chiusa del Capitolo 20: *«Una voce mi risuona improvvisa in testa: Non riesco a uscire, non riesco a uscire»*.  
* **Traccia di scrittura:** Scrivi sul tuo quaderno un breve monologo interiore (15-20 righe) in cui Mauri, nel silenzio della sua stanza accanto al fratello addormentato, cerca di distinguere tra la realtà, gli incubi e i propri rimorsi. Cosa significherebbe per lui se Brando fosse davvero vivo? E cosa significherebbe se invece fosse vittima di una macchinazione crudele?

---

## 3. Laboratorio Lessicale e Modi di Dire
*Associa ciascun vocabolo al suo significato nel contesto del racconto (indica sul quaderno la combinazione corretta numero-lettera).*

| Termine o Modo di Dire | Abbinamento | Significato Contestuale |
| :--- | :---: | :--- |
| 1. **Ancorino** | | A. Antica fortificazione difensiva medievale di Predore, legata storicamente a camminamenti e rifugi sotterranei. |
| 2. **Cimelio** | | B. Piccolo attrezzo con tre o quattro bracci uncinati (ancoretta), impiegato per la pesca o per recuperare oggetti dal fondale. |
| 3. **Ipnotizzare** | | C. Fantasma, apparizione inquietante o figura evanescente che incute timore nell'oscurità. |
| 4. **Mezza Torre** | | D. Oggetto antico o caro al ricordo, conservato con venerazione come preziosa testimonianza del passato. |
| 5. **Spettro** | | E. Catturare e polarizzare lo sguardo o l'attenzione di qualcuno in modo quasi magnetico e irresistibile. |

---

## 4. Attività Speciale "Fuori dagli schemi" 🧭

**Contesto:** Dopo il terzo biglietto, il gruppo si spacca. Nando sostiene con fermezza che bisogna denunciare tutto ai Carabinieri perché la situazione è sfuggita di mano. Mauri, al contrario, rifiuta categoricamente per timore di essere incriminato ingiustamente e perché "i Lucci risolvono i loro guai da soli".

Organizza in classe un **Tribunale Simulato** dividendo la classe in tre ruoli e sviluppando sul quaderno le tesi di ciascuna parte:

                    TRIBUNALE SIMULATO: "LEALTÀ VS LEGALITÀ"
CASO N. 03: Biglietto anonimo con segreto esclusivo ("Pinna Mozza")

1. COLLEGIO DI ACCUSA (Istituzioni & Sicurezza - Tesi di Nando):
   - Argomentazioni per consegnare subito il biglietto ai Carabinieri;
   - Rischi per l'incolumità dei ragazzi nel continuare indagini private.

2. COLLEGIO DI DIFESA (Codice della Contrada - Tesi di Mauri):
   - Perché coinvolgere gli adulti rischierebbe di incolpare ingiustamente un amico;
   - Il valore sacro dell'autonomia e della lealtà fraterna tra "Lucci".

3. GIURIA POPOLARE (Il Verdetto della Classe):
   - Valutazione dei pro e contro di entrambe le scelte e sentenza finale motivata.
---

# GUIDA E RIASSUNTO PER IL DOCENTE

#### Sinossi del Blocco (Cap. 20-22)
Nel Capitolo 20 l'Italia supera l'Argentina 2-1 (gol di Tardelli e Cabrini) e la banda festeggia fino a tardi sul ponte di Sarnico. Al ritorno Mauri pesca al pontile con Santiago, che gli confessa di calare reti di frodo prima dell'alba. Beve alla fontana e scorge nella grondaia il terzo biglietto: *«Maledetto Pinna Mozza! Zombie»*. È il panico: quel soprannome segreto era noto solo a lui e a Brando. Nel Capitolo 21 Mauri confida la scoperta agli amici. Non volendo rivolgersi ai Carabinieri per non autoincriminarsi, elabora l'ipotesi che Brando sia vivo e fuggito attraverso un tunnel subacqueo collegato ai sotterranei storici della Mezza Torre. Fabi e Mauri si immergono: il tunnel è crollato, ma le pietre sembrano pulite, come cadute di recente. Nando ricorda che tali cunicoli sono descritti in un libro di storia locale conservato nella Chiesa Vecchia. Nel Capitolo 22 i ragazzi si ritrovano di notte per introdursi nella sacrestia. Mancando chiavi e barca, incontrano Viero (fratello di Aura) impegnato nella pesca subacquea notturna. Viero svela loro che la porta del giardino è aperta e insegna il "trucco antistrizza" per non temere il buio in acqua. I ragazzi si spogliano e raggiungono a nuoto la scaletta della sacrestia.

#### Obiettivi Didattici
- **Cognitivi:** Esaminare la tensione tra fiducia negli amici e timore del giudizio degli adulti; analizzare la costruzione della suspense nel romanzo di mistero.
- **Linguistici:** Riflettere sulla polisemia dei termini e sull'uso di espressioni metaforiche legate al folklore e alla storia locale (i passaggi segreti medievali).
- **Cittadinanza e Costituzione:** Favorire il pensiero critico attraverso il debate e il processo simulato sul confine tra segreto amicale, timore di ingiustizia e rispetto della legge.

---

#### Soluzioni delle Domande Aperte (Traccia di Risposta)
1. *I cittadini e i giovani si riversano a Sarnico festeggiando sul ponte con cortei di motorini, cori, fumogeni e botti fino a notte fonda. Durante la pesca notturna al pontile, Santiago ammette a Mauri di posizionare reti di frodo vicino a riva e gli propone di uscire in barca con lui alle quattro e mezza del mattino per ritirarle prima dell'arrivo delle guardie ittiche.*
2. *Il terzo biglietto recita testualmente: «Maledetto Pinna Mozza! Zombie». Mauri rimane tramortito perché "Pinna Mozza" era il nome segreto che lui e Brando avevano inventato per il persico trota gigante: un dettaglio intimo mai rivelato a nessun altro vivente, che sembra confermare l'inspiegabile presenza o conoscenza da parte dello scomparso.*
3. *Mauri ipotizza che Brando non sia annegato, ma che il giorno della tragedia si sia infilato nel cunicolo subacqueo della darsena per sfuggire a un pericolo, e che il tunnel sia franato subito dopo. Fabi si infila nel pertugio e constata il crollo della volta, ma nota che le pietre sono pulite e senza limo, come franate da poco.*
4. *Nando ricorda di aver letto dell'esistenza di gallerie sotterranee tra la Mezza Torre e varie zone del paese in un volume storico di Predore. Poiché la biblioteca comunale è chiusa per ristrutturazione e i volumi sono stipati nella Chiesa Vecchia per la catalogazione, i ragazzi decidono di intrufolarsi furtivamente di notte per consultare il tomo senza insospettire gli adulti.*
5. *Mancano sia l'imbarcazione di famiglia di Aura (usata dai parenti per andare a Montisola) sia le chiavi d'accesso alla chiesa. Dal lago spunta Viero con l'attrezzatura da sub: spiega loro il trucco di tenere la torcia ferma sul petto per non farsi spaventare dalle ombre della penombra ("zona al limite della luce") e indica che la porta del giardino della sacrestia è socchiusa, raggiungibile nuotando al buio lungo i muraglioni.*

#### Soluzioni Vero/Falso
1. **Falso.** L'Italia sconfigge l'Argentina 2-1 con le reti di Tardelli e Cabrini.
2. **Falso.** Il nome era un segreto assoluto condiviso unicamente tra Mauri e Brando.
3. **Vero.** Nando vorrebbe rivolgersi alle autorità, ma Mauri si oppone temendo che la polizia lo incolpi ingiustamente.
4. **Vero.** Le macerie non mostrano incrostazioni di alghe o melma, segno di un cedimento apparentemente recente.
5. **Falso.** I ragazzi vi giungono a nuoto nel buio, dopo essersi spogliati e aver messo le mutande in testa per tenerle asciutte.

#### #### Laboratorio di Lessico - Abbinamenti:
- **1. Ancorino** → **B** (Piccolo amo multiplo con bracci uncinati per agganciare prede o oggetti sommersi)
- **2. Cimelio** → **D** (Oggetto antico carico di valore affettivo, testimonianza preziosa del passato)
- **3. Ipnotizzare** → **E** (Catturare lo sguardo o l'attenzione in modo magnetico e involontario)
- **4. Mezza Torre** → **A** (Antica struttura fortificata difensiva medievale di Predore)
- **5. Spettro** → **C** (Figura evanescente o apparizione paurosa che incute timore)


#### Griglia di Valutazione Suggerita
- Comprensione del testo (Domande 1-5): **punti 0 - 2,5 ciascuna (tot. 12,5)**
- Vero/Falso con correzione: **punti 0,5 ciascuno (tot. 2,5)**
- Esercizio lessicale: **punti 0,6 per termine corretto (tot. 3,0)**
- Analisi psicologica e scrittura creativa: **punti 0 - 7,0**
- Attività "Processo simulato": **punti 0 - 5,0**
- **Punteggio Totale: 30 / 30** (Conversione in decimi: voto diviso 3).

