# SCHEDA DIDATTICA DI LETTURA E COMPRENSIONE
## *I lucci della via Lago* di Giuseppe Festa
### Unità Didattica 1 (Blocco 1): *Prologo* – *Un sacco di roba* – *Pinna mozza*

---

> ### 🌊 Benvenuto nella «via Lago»!
> Hai appena iniziato a leggere una storia intensa, fatta di amicizia vera, acque profonde e segreti da svelare. La narrazione si apre con un ragazzo su un treno nell'estate del 1982, per poi tuffarsi indietro di un mese, nel giorno in cui tutto è cominciato: la fine della terza media a Predore, sulle rive del lago d'Iseo. Leggi con attenzione le prime pagine e mettiti alla prova con le attività seguenti!

---

## 1. Comprensione del Testo

*Rispondi sul tuo quaderno in modo chiaro e completo, argomentando con riferimenti al testo.*

1. **La cornice narrativa e il salto nel tempo:**  
   Nel *Prologo*, dove si trova il protagonista e in quale data precisa è ambientata la scena? Da quale frase o elemento capiamo che la storia che sta per raccontare è un lungo ricordo (flashback)?
   

2. **I nomi della banda e l'eccezione di Brando:**  
   Nel capitolo *Un sacco di roba*, il narratore spiega come i ragazzi della via Lago usano chiamarsi tra loro. Qual è la regola generale per i nomi e perché Brando rappresenta l'unica eccezione fin dalla nascita?
   

3. **La grande caccia a "Pinna Mozza":**  
   Perché il narratore e Brando vogliono assolutamente catturare Pinna Mozza proprio il giorno dell'esame di terza media? Di che tipo di pesce si tratta e quali strumenti artigianali hanno costruito per cacciarlo?
   

4. **Il tiro combinato e la fretta:**  
   Perché i due amici decidono di effettuare un «tiro combinato» invece di tirare uno alla volta? Quale evento imminente li costringe ad affrettarsi mentre sono appostati vicino al palo della darsena?
   

5. **L'immersione e la sparizione:**  
   Descrivi cosa accade dopo il fallimento del primo tiro: come reagiscono i due ragazzi e cosa spinge Brando a tuffarsi di nuovo verso l'albero sommerso? Qual è l'esito finale dell'avventura?
   

---

## 2. Vero o Falso? (Attenzione ai dettagli)
*Indica nella tabella se l'affermazione è Vera (V) o Falsa (F). Correggi e motiva sul tuo quaderno le affermazioni false.*

| Affermazione | V | F |
| :--- | :---: | :---: |
| 1. Nel *Prologo*, il protagonista racconta che l'incubo che ha vissuto è durato esattamente trentatré giorni. | | |
| 2. La professoressa Turla saluta Mauri predicendogli un futuro brillante come campione di calcio professionista. | | |
| 3. Pinna Mozza è un enorme persico trota stimato in almeno tre chili, con la pinna dorsale morsicata. | | |
| 4. Le frecce per gli archetti subacquei sono state fabbricate usando bacchette di metallo ricavate da un ombrello. | | |
| 5. Quando il battello *Il Cigno* riparte, Brando riemerge soddisfatto mostrando il pesce catturato alla folla sul pontile. | | |

---
## 3. Analisi dei Personaggi e Riflessione

### Personaggi a confronto: Mauri e Brando
*Nel testo emerge con forza il legame fraterno tra Mauri e Brando, ma si intravedono anche tratti caratteriali distinti: l'ambizione di non perdere la faccia, l'istinto di protezione, l'entusiasmo della giovinezza.*

- **Domanda di analisi:**  
  Rileggi con attenzione il dialogo tra Mauri e Brando prima del tuffo e il momento in cui entrambi mancano il bersaglio:  
  *«So cosa sta pensando: meglio non dirlo in giro. Ma soprattutto, non possiamo dargliela vinta così».*  
  Che cosa rivela questo pensiero sulla mentalità dei due amici e sul senso dell'onore tipico dei ragazzi della loro età? Perché per loro era così inaccettabile tornare a riva a mani vuote dopo aver fallito il primo tiro?
  

---

## 4. Officina di Scrittura Creativa ed Empatia

### Immedesimazione ed Emozioni
*Mettiti nei panni del narratore Mauri.*

Immagina di trovarti a pelo d'acqua, con la maschera bagnata tra le mani, subito dopo la partenza del battello *Il Cigno*. Fino a cinque minuti prima eri un ragazzo spensierato che festeggiava la fine della scuola media sognando i Mondiali di calcio e le vacanze; ora l'acqua del lago è immobile e il tuo migliore amico non risponde alle tue grida.

✍️ **Traccia:** Scrivi sul tuo quaderno una pagina di diario o un breve monologo interiore (15-20 righe) in cui descrivi questo istante di passaggio dalla spensieratezza al terrore: cosa vedi attorno a te? Cosa provi nel tuo corpo? Quali pensieri ti assalgono mentre gridi disperatamente il nome di Brando?


---

## 5. Laboratorio Lessicale e Modi di Dire
*Associa ciascun vocabolo al suo significato nel contesto del racconto (indica sul quaderno la combinazione corretta numero-lettera).*

| Termine o Modo di Dire | Abbinamento | Significato Contestuale |
| :--- | :---: | :---: |
| 1. **Coppino** | | A. Discorso lungo, severo e moraleggiante con cui un adulto rimprovera un ragazzo. |
| 2. **Paternale** | | B. Bacino o specchio d'acqua riparato, destinato all'ormeggio e al ricovero delle barche. |
| 3. **Darsena** | | C. La parte posteriore del collo; la nuca (termine del linguaggio familiare/regionale). |
| 4. **Sarneghera** | | D. Discesa subacquea o tuffo eseguito mantenendo il corpo perfettamente dritto e verticale. |
| 5. **A candela** | | E. Tipica e improvvisa tempesta d'acqua e vento che scende da Sarnico sul lago d'Iseo. |

---

## 6. Attività Speciale "Fuori dagli schemi" 🧭
### 🔍 Compito di Realtà: Il Rilievo Tecnico dei Sommozzatori

> **Contesto della missione:**  
> Sono le ore 14:30 del 14 giugno 1982. A Predore è appena scattato l'allarme: un ragazzo di tredici anni è scomparso nelle acque antistanti la darsena durante le manovre del battello di linea. La squadra dei sommozzatori e i carabinieri hanno bisogno della testimonianza tecnica di Mauri per circoscrivere l'area di ricerca prima che le correnti complichino le operazioni.

**Lavorate individualmente o a coppie per completare le due schede operative:**

#### Fase 1. La Mappa Tattica del Fondale (Ricostruzione Grafica)
Sul tuo quaderno, disegna una **mappa schematica dall'alto** dell'area della darsena basandoti esclusivamente sui dettagli geografici e ambientali forniti nel testo. Assicurati di inserire e contrassegnare con precisione:
- **A.** Il pontile di partenza dei due ragazzi;
- **B.** Il masso piatto sotto «l'aquila di pietra» (punto di osservazione);
- **C.** La traiettoria a semicerchio nuotata da Mauri e Brando per sorprendere Pinna Mozza dal largo;
- **D.** Il palo azzurro (territorio di Pinna Mozza) e l'albero sommerso dalla Sarneghera;
- **E.** La rotta di attracco e ripartenza del battello *Il Cigno* con la direzione della corrente generata dalle eliche;
- **F.** «La strada sul fondo» che scende verso il largo nel buio.

#### Fase 2. La Cronologia dei 60 Secondi e l'Ipotesi Investigativa
Mauri misura il tempo con drammatica precisione negli ultimi istanti.
1. Completa la tabella cronologica degli eventi chiave:
   - **T = 0s:** Brando si tuffa a candela verso l'albero caduto.
   - **T = 10s - 20s:** (Descrivi cosa fa Mauri mentre scruta l'acqua)
   - **T = 30s:** Il battello passa davanti a Mauri e attracca al molo.
   - **T = 40s - 50s:** (Descrivi l'attesa febbrile e il cambio delle correnti)
   - **T = 60s+ :** Il battello riparte a motori spiegati; Mauri si immerge ma trova solo un banco di alborelle.

2. **La tua Ipotesi Investigativa:** Secondo te, quale combinazione di fattori ha impedito a un nuotatore esperto come Brando di riemergere in tempo? (Considera: visibilità, ostacoli sul fondo, correnti meccaniche del battello, malore improvviso o attrezzi impigliati). Formula un'ipotesi motivata di 3-4 righe sul tuo quaderno.

---

# GUIDA E RIASSUNTO PER IL DOCENTE

### 📌 Scheda di Sintesi del Capitolo
- **Capitolo/Sezione:** Unità 1 (composta da *Prologo*, *Un sacco di roba*, *Pinna mozza*).
- **Pagine di riferimento:** pp. 11–20.
- **Data e Luogo:** 16 luglio 1982 (cornice: treno Milano-Firenze); 14 giugno 1982 (flashback: Predore, Lago d'Iseo).
- **Personaggi introdotti:** 
  - **Mauri (Maurizio):** Narratore in prima persona, 13 anni, appassionato di calcio (il suo idolo è Giancarlo Antognoni, numero 10 della Fiorentina e della Nazionale), leale e coraggioso.
  - **Brando:** Il migliore amico di Mauri, furbo, agile, nuotatore eccezionale e impavido ("con due sillabe dalla nascita").
  - **Professoressa Turla:** Insegnante delle medie, severa ma affettuosa ("sberla sul coppino").
  - **Aura:** Ragazza della banda della via Lago, figura femminile che attira i primi turbamenti affettivi di Mauri.
  - **Santiago:** Vecchio pescatore saggio del paese, punto di riferimento per i ragazzi del lago.
  - **Gamba de legn:** L'ormeggiatore del battello di linea *Il Cigno*.

### 📖 Sinossi per il docente
Il romanzo si apre con un prologo in medias res ambientato il 16 luglio 1982: il tredicenne Mauri si trova su un treno verso Firenze, in fuga dal suo paese e dai fantasmi di una tragedia durata trentatré giorni.  
Attraverso un flashback, la narrazione ritorna al 14 giugno 1982 a Predore, sulla sponda bergamasca del lago d'Iseo. È l'ultimo giorno degli esami di terza media. Liberatisi dal peso della scuola, Mauri e Brando corrono al pontile per realizzare un'impresa segreta: catturare con rudimentali archetti subacquei "Pinna Mozza", un leggendario persico trota di tre chili annidato presso i pali della darsena.  
Per garantirsi il successo e dividere la gloria, decidono di scoccare un tiro combinato. Tuttavia, incalzati dall'imminente attracco del battello di linea *Il Cigno*, mancano clamorosamente il bersaglio. Mauri ritenta immergendosi verso un albero caduto sul fondo (abbattuto dalla celebre tempesta *Sarneghera*), ma riesce solo a scalfire il pesce. Brando, rifiutando l'idea del fallimento, si immerge "a candela" nel buio profondo per tentare l'ultimo tiro.  
I secondi trascorrono inesorabili; il battello manovra e riparte creando forti correnti con le eliche. Brando non riemerge più. Mauri, tornato sul fondo senza scorgerne traccia, riaffiora urlando disperato il nome dell'amico tra le acque agitate del lago.

### 🎯 Nuclei Didattici e Spunti di Discussione in Classe
1. **La struttura narrativa del Flashback e il Patto con il Lettore:** Far notare agli alunni la tecnica con cui l'autore cattura l'attenzione aprendo dalla fine (cornice temporale sul treno) e anticipando che i 33 giorni successivi si trasformeranno in un incubo.
2. **Il tema della sfida e della "prova di coraggio":** Spunto per un dibattito guidato sulla pressione sociale tra coetanei, sul bisogno di mettersi alla prova alla fine di un ciclo scolastico (il rito di passaggio delle medie) e sul confine tra avventura e incoscienza.
3. **L'ambientazione geografica e linguistica:** Valorizzare il contesto lacustre italiano e i termini dialettali/geografici (*Sarneghera*, *darsena*, *coppino*).

### 🔑 Soluzioni e Risposte Attese (Chiavi di correzione)

#### 2. Vero o Falso:
1. **FALSO.** Racconterà solo trentatré giorni della sua vita (dal 14 giugno al 16 luglio 1982), non un intero anno scolastico.
2. **FALSO.** La prof Turla gli ripete che la sua fissa per il calcio farà di lui un ignorantone disoccupato.
3. **VERO.** È un persico trota enorme con la pinna dorsale morsicata che staziona davanti alla darsena.
4. **VERO.** Le frecce sono state ricavate affilando le stecche metalliche di un vecchio ombrello.
5. **FALSO.** Brando non riemerge affatto e scompare nelle profondità del lago mentre il battello riparte.

#### 5. Laboratorio Lessicale:
- **1. Coppino** → **C** (La parte posteriore del collo; la nuca)
- **2. Paternale** → **A** (Discorso lungo, severo e moraleggiante con cui un adulto rimprovera un ragazzo)
- **3. Darsena** → **B** (Bacino o specchio d'acqua riparato per l'ormeggio delle barche)
- **4. Sarneghera** → **E** (Tipica e improvvisa tempesta d'acqua e vento che scende da Sarnico sul lago d'Iseo)
- **5. A candela** → **D** (Discesa subacquea o tuffo eseguito mantenendo il corpo perfettamente dritto e verticale)

