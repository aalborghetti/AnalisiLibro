# SCHEDA DIDATTICA DI LETTURA E COMPRENSIONE
## *I lucci della via lago* di Giuseppe Festa  
### Unità Didattica 6 (Blocco 6): *Peli di coniglio bianco* – *La strada sul fondo del lago*  
---

> *«I bambini morti non li hanno più ripescati. Da allora risalgono dal fondo del lago, con i capelli di alghe e gli zainetti vuoti... La strada sul fondo è il segno del loro passaggio.»*  
> *(Capitolo 19)*

---

## 1. Comprensione del Testo

### A. Domande a risposta aperta

*Rispondi sul tuo quaderno in modo chiaro e completo, argomentando con riferimenti al testo.*

1. **Il sospetto tra le mura di casa:** Perché la visita mattutina del maresciallo Girelli getta nel panico Mauri? Quale sconcertante particolare emerge sull'adesivo della busta e perché Fabi prende Mauri da parte con grande preoccupazione?
2. **Il rito del battello e la sfida con l'autorità:** Descrivi la dinamica con cui i ragazzi si tuffano nella scia del battello *Iseo*. Chi è "Gamba de legn", quale pericolo cerca di sventare e con quale astuto stratagemma la banda riesce a beffarlo?
3. **Il luccio da record e la prova del tombino:** Quali due episodi testimoniano la cultura e lo spirito di competizione estrema della contrada in via Lago prima dell'arrivo del battello?
4. **La pesca notturna in Villa Lago:** Quali sono le regole etiche che i ragazzi si sono dati per la pesca delle tinche col bilancino? Come trattano i pesci catturati e quali insoliti nomi attribuiscono loro?
5. **Il mito dei bambini coi capelli d'alghe:** Racconta l'origine storica e la trasformazione leggendaria della sciagura del battello narrata da Trapola. Quale spiegazione fantastica viene data alla misteriosa "strada sul fondo del lago"?

---

### B. Vero o Falso? (Attenzione ai dettagli)
*Indica nella tabella se l'affermazione è Vera (V) o Falsa (F). Correggi e motiva sul tuo quaderno le affermazioni false.*

| Affermazione | V | F |
| :--- | :---: | :---: |
| 1. I carabinieri decidono di trattenere Mauri in caserma per sottoporlo al rilevamento coatto delle impronte digitali. | | |
| 2. Nella sfida di resistenza sul tombino rovente, Trapola stabilisce il record resistendo per ben 58 secondi. | | |
| 3. Gione è un ragazzo di Crema che viene detestato ed emarginato da tutti perché non rispetta le tradizioni dei pescatori. | | |
| 4. Le tinche pescate dai ragazzi vengono immediatamente cucinate e mangiate in darsena insieme a Vince. | | |
| 5. Al termine della pesca, Aura accetta con entusiasmo che Mauri e Angelo la scortino a braccetto fino a casa. | | |

---
## 2. Analisi e Riflessione

### A. Approfondimento del Personaggio e Riflessione
Nel finale del Capitolo 19, Mauri e Angelo fanno a gara per fare i "cavalieri" e scortare Aura fino alla sua barca nel buio della notte. La ragazza, tuttavia, reagisce con fierezza: *«Ma per chi mi avete preso? Non ho mica bisogno della scorta! Ci vediamo domani in piazzetta»*.
* **Domanda di riflessione:** Rispondi sul tuo quaderno: In che modo la figura di Aura rompe gli stereotipi della classica "fanciulla da proteggere"? Perché, per una ragazza della sua età inserita in un gruppo prevalentemente maschile, è fondamentale ribadire la propria autonoma sicurezza?

### B. Officina di Scrittura ed Empatia
Le comunità in riva ai laghi o ai fiumi hanno sempre generato leggende per mettere in guardia i bambini dai pericoli dell'acqua profonda (gorghi, correnti di fondo, mulinelli).  
* **Traccia di scrittura:** Inventa sul tuo quaderno un breve racconto o mito popolare (15-20 righe) ambientato in una riva lacustre: crea una creatura fantastica o uno spirito delle acque che custodisce un relitto o una strada sommersa, spiegando quale ammonimento morale impartisce a chi si avventura incautamente dove l'acqua diventa scura.

---

## 3. Laboratorio Lessicale e Modi di Dire
*Associa ciascun vocabolo al suo significato nel contesto del racconto (indica sul quaderno la combinazione corretta numero-lettera).*

| Termine o Modo di Dire | Abbinamento | Significato Contestuale |
| :--- | :---: | :--- |
| 1. **Scientifica** | | A. Vano segreto ricavato sotto il fondo di una barca o di un mobile per nascondere oggetti o pescato. |
| 2. **Doppiofondo** | | B. Pratica illegale di caccia o pesca esercitata di nascosto, violando i divieti o i periodi di tutela. |
| 3. **Frodo** | | C. Celebre aereo militare da bombardamento in picchiata, noto per il sibilo sinistro delle sue sirene. |
| 4. **Bilancino** | | D. Settore o squadra specializzata delle forze dell'ordine incaricata dei rilievi tecnici e delle impronte digitali. |
| 5. **Stuka** | | E. Rete da pesca quadrata montata su due archi a croce, manovrata a mano da riva o dalla barca. |

---

## 4. Attività Speciale "Fuori dagli schemi" 🧭

**Contesto:** I capitoli 18 e 19 mostrano una profonda confidenza dei ragazzi con il lago d'Iseo (il Sebino), ma ne evidenziano anche i pericoli mortali: il risucchio delle eliche, le correnti fredde, i gorghi e le profondità abissali.

Vesti i panni di un **Giovane Idrografo del Lago** e redigi sul tuo quaderno l'analisi dei rischi e delle risorse acquatiche descritte nel testo:

           CARTA IDROGRAFICA DEI "LUCCI": IL SEBINO SOTTO LA SUPERFICIE
1. LA MINACCIA DELLA CORRENTE:
   - Imbarcazione più potente descritta;
   - Meccanismo del risucchio dell'elica;
   - Perché "Gamba de legn" tenta di ostacolare il salto dei ragazzi?

2. FAUNA ITTICA A CONFRONTO:
   Confronta sul tuo quaderno il Luccio e la Tinca analizzando: aspetto fisico e dentatura, habitat preferito, valore simbolico ed etica della cattura.

3. LA "STRADA SUL FONDO DEL LAGO":
   - Descrizione visiva del fenomeno;
   - Spiegazione scientifico-geologica;
   - Spiegazione mitico-folclorica (la leggenda narrata da Trapola).

4. DECALOGO DI SICUREZZA IN ACQUA DOLCE:
   Scrivi sul tuo quaderno 3 regole fondamentali che un bagnante dovrebbe sempre rispettare per evitare pericoli in acque lacustri.
---

# GUIDA E RIASSUNTO PER IL DOCENTE

#### Sinossi del Blocco (Cap. 17-19)
Nel Capitolo 17 il maresciallo Girelli ritira il secondo biglietto anonimo. Le voci di paese rivelano che sul foglio è presente una sola impronta e dei peli di coniglio bianco: poiché solo la famiglia di Mauri alleva conigli in contrada, i sospetti ricadono sul protagonista. Nel Capitolo 18, dopo che i carabinieri interrompono le indagini, i ragazzi assistono alla cattura di un luccio gigantesco da parte del burbero Pietro Ross e si cimentano nella prova di resistenza sul tombino bollente (vinta da Trapola con 58 secondi). All'arrivo del battello *Iseo*, la comitiva distrae l'addetto all'attracco "Gamba de legn" e si tuffa nella poderosa scia d'acqua generata dall'elica; in acqua Mauri trova il coraggio di invitare Aura a pescare le tinche nella darsena di Villa Lago. Nel Capitolo 19 la battuta di pesca notturna col bilancino vede aggregarsi a sorpresa il piccolo Angelo e poi il fratello Vince. Trapola racconta la lugubre leggenda del battello scolastico affondato da uno Stuka tedesco nel secondo conflitto mondiale e degli spettri dei bambini che risalirebbero lungo la "strada sul fondo del lago". L'atmosfera misteriosa rovina il romanticismo di Mauri, e Aura riafferma la propria fiera indipendenza tornando a casa da sola.

#### Obiettivi Didattici
- **Cognitivi:** Esplorare l'intreccio tra tradizioni locali, memoria storica (il bombardamento bellico) e credenze popolari tramandate oralmente.
- **Linguistici:** Riconoscere la terminologia nautica e della pesca lacustre (doppiofondo, pesca di frodo, bilancino, naét, battello).
- **Formativo-educativi:** Discutere la parità di genere e il rifiuto di atteggiamenti paternalistici o protettivi non richiesti; promuovere l'etica del rispetto per la fauna selvatica (pesca con rilascio).

---

#### Soluzioni delle Domande Aperte (Traccia di Risposta)
1. *La comparsa del maresciallo alle otto del mattino fa temere a Mauri che la madre creda a una sua colpevolezza. Sulla busta la scientifica rileva peli di coniglio bianco; poiché in tutta la via solo la famiglia di Mauri alleva conigli (e ne possiede uno bianco), la cerchia dei sospettati si stringe pericolosamente attorno a Mauri e Fabi.*
2. *I ragazzi amano lanciarsi subito dopo la ripartenza del natante per farsi trascinare ad alta velocità dalla spinta d'acqua senza nuotare. L'addetto "Gamba de legn" cerca di bloccarli temendo che la forza d'aspirazione dell'elica li maciulli, ritardando l'accelerazione fino al largo. La banda lo inganna fingendo totale disinteresse al muretto con le carte da gioco, per poi scattare in tuffo appena il battello ingrana la marcia.*
3. *Il primo è l'esibizione silenziosa del monumentale luccio di un metro pescato da Pietro Ross (ammirato con reverente stupore); il secondo è la sfida a piedi nudi sul tombino di ghisa arroventato dal sole estivo, vinta da Trapola con 58 secondi di sopportazione estrema.*
4. *I ragazzi praticano una pesca non cruenta: le tinche catturate col bilancino non vengono uccise né mangiate, ma trasferite nella vasca della serra in tane di tufo, nutrite con vermi e polenta e battezzate con i nomi dei grandi campioni della nazionale francese di calcio (Tigana, Platini).*
5. *L'origine storica risale a un reale bombardamento tedesco (a opera di uno Stuka) su un battello di scolaresche durante la Seconda Guerra Mondiale. La fantasia popolare e i racconti del nonno di Trapola hanno trasformato i piccoli annegati in fantasmi acquatici dai capelli d'alghe che tornerebbero nottetempo a rubare i giocattoli dei vivi, calpestando la depressione sommersa nota come "strada sul fondo".*

#### Soluzioni Vero/Falso
1. **Falso.** Il maresciallo ritira semplicemente il reperto per sottoporlo all'esame della scientifica e scherza sul fatto di non voler arrestare Mauri.
2. **Vero.** Trapola resiste per 58 secondi bruciandosi letteralmente la pianta dei piedi.
3. **Falso.** Pur essendo antipatico e snob, Gione è rispettato da tutti per la bravura eccezionale e acrobatica nei tuffi olimpici dal lampione.
4. **Falso.** I ragazzi non mangiano le tinche: le accudiscono nella serra come piccoli trofei viventi.
5. **Falso.** Aura rifiuta sdegnata la scorta sia di Mauri sia di Angelo, ribadendo di non aver bisogno di protettori.

#### #### Laboratorio di Lessico - Abbinamenti:
- **1. Scientifica** → **D** (Squadra tecnica della polizia scientifica incaricata di esaminare impronte e reperti)
- **2. Doppiofondo** → **A** (Vano celato sotto il fondo della barca per nascondere il pescato)
- **3. Frodo** → **B** (Pesca clandestina praticata senza licenza e in violazione dei divieti)
- **4. Bilancino** → **E** (Rete da pesca quadrata calata vicino a riva mediante archetti a croce)
- **5. Stuka** → **C** (Aereo da guerra noto per le sue picchiate e le sirene intimidatorie)


#### Griglia di Valutazione Suggerita
- Comprensione del testo (Domande 1-5): **punti 0 - 2,5 ciascuna (tot. 12,5)**
- Vero/Falso con correzione: **punti 0,5 ciascuno (tot. 2,5)**
- Lessico ed esercizio associativo: **punti 0,6 per associazione (tot. 3,0)**
- Riflessione su genere/indipendenza e scrittura creativa: **punti 0 - 7,0**
- Scheda idrografica e decalogo sicurezza "Fuori dagli schemi": **punti 0 - 5,0**
- **Punteggio Totale: 30 / 30** (Conversione in decimi: voto diviso 3).

