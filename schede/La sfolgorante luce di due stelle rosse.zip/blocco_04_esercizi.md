# SCHEDA DIDATTICA DI LETTURA E COMPRENSIONE
## *La sfolgorante luce di due stelle rosse* di Davide Morosinotto
### Unità Didattica 4 (Blocco 4): *Capitolo 11* – *Capitolo 13*

---

**Nome e Cognome dello studente:** ________________________________________  
**Classe:** ____________________  **Data:** ____________________  

---

> ### 🌊 Tra il fango del Volga e i binari morti di Mga
> «Tutte le famiglie felici si assomigliano fra loro; ogni famiglia infelice, invece, è infelice a modo suo.»  
> Separati da oltre mille chilometri, Viktor e Nadya affrontano due prove opposte: mentre Viktor lavora duramente nel fango di una fattoria collettiva sul Volga e rischia la punizione per cercare notizie della sorella, Nadya è bloccata su un convoglio immobile a poca distanza dal fronte, dove una scacchiera intarsiata diventa il rifugio contro la paura.

---

## 1. Comprensione del Testo

### A. Domande a risposta aperta
*Rispondi sul tuo quaderno in modo completo, motivando le tue risposte con riferimenti precisi al testo.*

1. **La beffa della distanza a Mga:**  
   Nel Capitolo 11 Nadya incolla sul diario la mappa della regione e cita l'inizio di *Anna Karenina*. Perché la sosta forzata del treno 76 alla stazione di Mga è così assurda e pericolosa per la vita dei bambini e delle mamme?

2. **La dura realtà del kolkhoz:**  
   Nel Capitolo 12 Viktor sperimenta la vita nella fattoria collettiva sul Volga. Perché osserva che l'ideale del *kolkhoz* «è bellissimo visto da fuori, ma da dentro è molto più complicato»? Quali ostacoli concreti devono affrontare i ragazzi sotto gli ordini del capobrigata Garayev?

3. **Il piano audace del camion del latte:**  
   Per scoprire se il convoglio 76 sia transitato da Kazan, Viktor organizza una fuga con l'aiuto dei compagni. Come riescono Viktor, Lev e Flavio a farsi assegnare al carico dei bidoni e quale delusione attende Viktor nell'ufficio della stazione ferroviaria?

4. **Khasanov e Garayev, due modelli di autorità:**  
   Sorpreso alla stazione di Kazan, Viktor viene affidato al direttore Anton Abramovich Khasanov. In che modo la reazione umana e paterna di Khasanov si differenzia dall'atteggiamento rigido e inflessibile del capobrigata Garayev?

5. **La vita sul binario morto:**  
   Nel Capitolo 13 il treno 76 rimane fermo fuori Mga, ma i passeggeri si riorganizzano con tenacia. Che cos'è il "Soviet delle Mamme", come vengono riconvertiti i vagoni e perché le rassicurazioni del commissario Bok si rivelano vane?

---

### B. Vero o Falso? (Attenzione ai dettagli)
*Indica se ciascuna affermazione è Vera (V) o Falsa (F). Correggi le affermazioni false sul tuo quaderno.*

| Affermazione | V | F |
| :--- | :---: | :---: |
| 1. Dopo quattro giorni di viaggio da Leningrado, il treno 76 ha percorso meno di settanta chilometri ed è piantonato da sentinelle armate. | | |
| 2. Appena giunto al granaio del *kolkhoz*, Mikhail si offre volontario per riparare il tetto e assistere i bambini più piccoli. | | |
| 3. Il direttore Khasanov, commosso dal dolore di Viktor per la gemella dispersa, decide di perdonare la fuga e lo riaccompagna in automobile. | | |
| 4. Sul treno 76 Nadya e Anna approfondiscono la loro amicizia sfidandosi di notte su una scacchiera con i pezzi intarsiati. | | |
| 5. Il 17 luglio i camion promessi dalle autorità arrivano regolarmente a Mga e riportano tutti i passeggeri sani e salvi a Leningrado. | | |

---

## 2. Analisi dei Personaggi e Riflessione
*Rispondi alle seguenti domande sul tuo quaderno, analizzando a fondo i personaggi e motivando le tue considerazioni.*

1. **La maturazione di un giovane leader (Viktor):**  
   Nel vecchio granaio infestato dai topi, i compagni smarriti si rivolgono a Viktor chiedendo: *«Che si fa adesso?»*. Come impara Viktor a guidare il gruppo senza imporsi con la prepotenza, valorizzando le doti pratiche di ciascuno e dominando il proprio dolore segreto?

2. **L'enigma di Anna Tereshenkov:**  
   Nel Capitolo 13 Nadya descrive Anna come un'amica colta, poliglotta e talentuosa scacchista. Confronta questo ritratto con le note a margine del colonnello Smirnov: perché la presenza della ragazza desta particolare apprensione nell'NKVD?

---

## 3. Officina di Scrittura Creativa ed Empatia
*Svolgi la seguente attività di scrittura sul tuo quaderno.*

Immagina di essere **Viktor** durante il viaggio di rientro in automobile da Kazan al *kolkhoz*, seduto accanto al direttore Khasanov. Hai appena appreso dalla ferroviera che il treno 76 non è mai giunto in Tatarstan e nessuno conosce la sorte di Nadya. Scrivi sul tuo quaderno un monologo interiore in prima persona: descrivi lo sgomento nel guardare l'orizzonte sconfinato della pianura russa, la gratitudine per il gesto paterno del direttore e la promessa inflessibile di ritrovare tua sorella costi quel che costi.

---

## 4. Laboratorio Lessicale e Modi di Dire
*Associa ciascun vocabolo o espressione d'autore al suo significato nel contesto del racconto (indica sul quaderno la combinazione corretta numero-lettera).*

| Termine o Modo di Dire | Abbinamento | Significato Contestuale |
| :--- | :---: | :--- |
| 1. **Kolkhoz** | [   ] | A. Ramo ferroviario secondario e senza sbocco, destinato alla sosta prolungata di carrozze e treni fermi. |
| 2. **Scansafatiche** | [   ] | B. Superare un contrasto o dimenticare un'infrazione rinunciando ad applicare punizioni o vendette. |
| 3. **Metterci una pietra sopra** | [   ] | C. Azienda agricola collettiva sovietica gestita dai contadini per rifornire lo Stato di grano e provviste. |
| 4. **Binario morto** | [   ] | D. Lavorato con inserti di legni pregiati di diverse tonalità a formare motivi ornamentali o riquadri bicolori. |
| 5. **Intarsiato** | [   ] | E. Persona incline all'indolenza che ricorre a pretesti per sottrarsi ai compiti faticosi della comunità. |

---

## 5. Attività Speciale "Fuori dagli Schemi"

**Taccuino Naturalistico / Storico / Tecnico: L'Ingegneria del Kolkhoz e la Strategia degli Scacchi**  
Nel Blocco 4 si intrecciano due pilastri della cultura sovietica del tempo: la complessa macchina produttiva del **Kolkhoz agricolo** (Capitolo 12) e la celebre scuola scacchistica russa (Capitolo 13).  
Realizza una doppia scheda illustrata sul tuo quaderno:
1. *Scheda Tecnica del Kolkhoz:* Disegna lo schema funzionale dell'insediamento (il dormitorio ricavato nel granaio, le stalle bovine, la catena di raccolta e trasporto del latte sui camion per la città).
2. *La Scacchiera della Resistenza:* Spiega come il rigore strategico degli scacchi (il sacrificio di pezzi per salvare la posizione, la difesa del re, la pazienza nell'attendere la mossa avversaria) rispecchi la condizione psicologica di Viktor e Nadya di fronte all'avanzata della guerra.

---

### GUIDA E RIASSUNTO PER IL DOCENTE

#### Riassunto sintetico dei capitoli
- **Capitolo 11 (Mga, 7 luglio 1941 - Nadya):** Il treno 76 è bloccato da quattro giorni a Mga, ad appena 70 km da Leningrado. Nadya legge *Anna Karenina* per ingannare il tempo; una madre, Irina, apprende che le colonne corazzate tedesche hanno già espugnato Pskov, rendendo l'evacuazione verso gli Urali impraticabile.
- **Capitolo 12 (7–11 luglio 1941 - Viktor):** Viktor è alloggiato nel granaio fatiscente di un *kolkhoz* sul Volga, a cinquanta chilometri da Kazan. Sotto gli ordini del rude capobrigata Garayev i ritmi sono estenuanti; Viktor compatta i compagni (Lev, Flavio, Kostya, Klara) emarginando il pigro Mikhail. L'11 luglio simula un incidente durante la mungitura per caricare i bidoni del latte e nascondersi sul camion per Kazan. In stazione scopre che il treno 76 non è mai arrivato; fermato dal direttore Khasanov, viene perdonato e ricondotto al villaggio con un ammonimento.
- **Capitolo 13 (Mga, 14–17 luglio 1941 - Nadya):** Le mamme fondano il "Soviet delle Mamme" per esigere viveri e sapone dal commissario Bok. Nadya fa amicizia con Anna Tereshenkov: di notte analizzano partite di scacchi dei maestri Ragozin e Botvinnik. L'annuncio di Bok sul rimpatrio a Leningrado tramite camion si rivela un'illusione: i mezzi non compaiono e la tensione cresce.

#### Soluzioni ed elementi chiave di correzione
- **1.A Domande aperte:**
  1. *La beffa della distanza a Mga:* Il treno è bloccato a pochi chilometri dal punto di partenza anziché essere lontano al sicuro; il fronte avanza rapidamente e i passeggeri sono intrappolati in un imbuto strategico.
  2. *La dura realtà del kolkhoz:* La fatica fisica è schiacciante: sveglia prima dell'alba, dormitori invasi dai topi, fango e barriere linguistiche con i contadini locali di lingua tatara.
  3. *Il piano del camion del latte:* Fingono di inciampare per farsi assegnare al carico dei bidoni pesanti, avvicinandosi al veicolo; a Kazan la ferroviera rivela che il treno 76 non è registrato negli elenchi d'arrivo.
  4. *Khasanov e Garayev:* Garayev vede nei giovani solo braccia da lavoro e impone disciplina militare; Khasanov riconosce la disperazione fraterna di Viktor e antepone l'empatia alla punizione formale.
  5. *La vita sul binario morto:* Il "Soviet delle Mamme" gestisce l'igiene e le necessità dei minori; i ragazzi adibiscono le carrozze a dormitorio e sala giochi; Bok formula promesse irrealizzabili per contenere il malcontento.
- **1.B Vero o Falso:**
  1. **VERO.** Il convoglio ha coperto meno di settanta chilometri ed è sorvegliato militarmente.
  2. **FALSO.** Mikhail cerca in ogni modo di sottrarsi al lavoro e si fa beffe dei compagni affaticati.
  3. **VERO.** Khasanov comprende il dramma della separazione e chiude un occhio sulla fuga.
  4. **VERO.** Gli scacchi cementano l'amicizia tra Nadya e Anna durante le notti sul vagone.
  5. **FALSO.** Nessun camion si presenta il 17 luglio, lasciando tutti nell'angoscia.
- **2. Analisi dei Personaggi:**
  1. *Maturazione di Viktor:* Impara a delegare con intelligenza (affidando le mansioni giuste a Lev e Klara) e comprende che la vera autorità si fonda sulla condivisione delle fatiche e sull'ascolto.
  2. *L'enigma di Anna:* È colta e protettiva, ma le postille di Smirnov lasciano intendere che le sue origini legate ai vertici dell'NKVD possano nascondere dinamiche poco chiare.
- **3. Officina di Scrittura:** Verificare la resa psicologica dello smarrimento di Viktor, il senso di colpa verso il padre e la tenacia nel non arrendersi.
- **4. Laboratorio Lessicale:** Combinazione corretta: `1-C, 2-E, 3-B, 4-A, 5-D`.
- **5. Attività Speciale:** Valutare la completezza dello spaccato sul *kolkhoz* e l'originalità nel trasporre i valori scacchistici nella narrazione bellica.
