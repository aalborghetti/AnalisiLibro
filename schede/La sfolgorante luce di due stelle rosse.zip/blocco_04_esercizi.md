# SCHEDA DIDATTICA DI LETTURA E COMPRENSIONE
## *La sfolgorante luce di due stelle rosse* di Davide Morosinotto
### Unità Didattica 4 (Blocco 4): *Capitolo 11* – *Capitolo 13*

---

**Nome e Cognome dello studente:** ________________________________________  
**Classe:** ____________________  **Data:** ____________________  

---

> ### 🌊 Tra il fango del Volga e i binari morti di Mga
> «Tutte le famiglie felici si assomigliano fra loro; ogni famiglia infelice, invece, è infelice a modo suo.»  
> Separati da oltre mille chilometri, Viktor e Nadya affrontano prove durissime: mentre Viktor lavora nei campi fangosi di una fattoria sul Volga e rischia grosso pur di cercare notizie della sorella, Nadya è bloccata su un treno fermo vicino al fronte, dove una scacchiera intarsiata diventa il rifugio contro la paura.

---

## 1. Comprensione del Testo

### A. Domande a risposta aperta
*Rispondi sul tuo quaderno in modo chiaro e completo, facendo riferimento a ciò che hai letto nel testo.*

1. **Un viaggio a passo di lumaca:**  
   Nel Capitolo 11 Nadya incolla sul diario la cartina della regione e cita una frase famosa di *Anna Karenina*. Perché la sosta forzata del treno 76 alla stazione di Mga è così assurda e mette in grave pericolo i bambini e le mamme?

2. **La dura vita nel kolkhoz:**  
   Nel Capitolo 12 Viktor sperimenta il lavoro nella fattoria collettiva vicino al fiume Volga. Perché osserva che l'ideale del *kolkhoz* «è bellissimo visto da fuori, ma da dentro è molto più complicato»? Quali fatiche quotidiane devono sopportare i ragazzi?

3. **Il piano dei bidoni del latte:**  
   Per scoprire se il convoglio 76 sia transitato da Kazan, Viktor organizza un piano audace con i compagni. Come riescono Viktor, Lev e Flavio a salire di nascosto sul camion del latte e quale delusione attende Viktor alla stazione?

4. **Un direttore severo ma comprensivo:**  
   Sorpreso alla stazione di Kazan, Viktor viene accompagnato dal direttore Anton Abramovich Khasanov. In che modo la reazione umana e paterna di Khasanov si differenzia dall'atteggiamento rigido del capobrigata Garayev?

5. **La vita sul binario morto:**  
   Nel Capitolo 13 il treno 76 rimane fermo fuori Mga, ma i passeggeri si organizzano con coraggio. Che cos'è il "Soviet delle Mamme", come vengono riadattati i vagoni e perché le promesse del commissario Bok si rivelano illusioni?

---

### B. Vero o Falso? (Attenzione ai dettagli)
*Indica se ciascuna affermazione è Vera (V) o Falsa (F). Correggi le affermazioni false sul tuo quaderno.*

| Affermazione | V | F |
| :--- | :---: | :---: |
| 1. Dopo quattro giorni di viaggio da Leningrado, il treno 76 ha percorso meno di settanta chilometri ed è piantonato da sentinelle armate. | | |
| 2. Appena arrivato al kolkhoz, Mikhail si offre volontario per riparare il tetto e aiuta i più piccoli senza mai lamentarsi. | | |
| 3. Il direttore Khasanov, commosso dal dolore di Viktor per la sorella dispersa, decide di perdonare la fuga e lo riporta indietro in automobile. | | |
| 4. Sul treno 76 Nadya e Anna fanno amicizia sfidandosi di notte su una scacchiera con i pezzi intarsiati nel legno. | | |
| 5. Il 17 luglio i camion promessi dalle autorità arrivano puntualmente a Mga e riportano tutti i passeggeri a Leningrado. | | |

---

## 2. Analisi dei Personaggi e Riflessione
*Rispondi alle seguenti domande sul tuo quaderno, riflettendo bene sui comportamenti dei protagonisti.*

1. **Viktor non si arrende:**  
   Nel vecchio granaio infestato dai topi, i compagni smarriti si rivolgono a Viktor chiedendo: *«Che si fa adesso?»*. Come impara Viktor a guidare il gruppo senza fare il prepotente, valorizzando le doti di ciascuno e tenendo per sé il proprio dolore?

2. **L'amicizia speciale con Anna:**  
   Nel Capitolo 13 Nadya descrive Anna come un'amica colta, intelligente e brava a scacchi. Quali qualità di Anna colpiscono Nadya e come fanno le due ragazze a farsi coraggio a vicenda nelle lunghe notti sul vagone?

---

## 3. Officina di Scrittura Creativa ed Empatia
*Svolgi la seguente attività di scrittura sul tuo quaderno.*

Immagina di essere **Viktor** durante il viaggio di rientro in automobile da Kazan al kolkhoz, seduto accanto al direttore Khasanov. Alla stazione hai appena saputo che il treno 76 non è mai arrivato e nessuno sa dove sia finita Nadya. Scrivi sul tuo quaderno i tuoi pensieri in prima persona: racconta lo sgomento nel guardare la pianura infinita, la gratitudine per la bontà del direttore e la promessa che fai a te stesso di ritrovare tua sorella costi quel che costi.

---

## 4. Laboratorio Lessicale e Modi di Dire
*Associa ciascun vocabolo o espressione d'autore al suo significato nel contesto del racconto (indica sul quaderno la combinazione corretta numero-lettera).*

| Termine o Modo di Dire | Abbinamento | Significato Contestuale |
| :--- | :---: | :--- |
| 1. **Kolkhoz** | | A. Ramo secondario dei binari chiuso a un'estremità, usato per far sostare i treni fermi. |
| 2. **Scansafatiche** | | B. Modo di dire che significa perdonare un errore e non tornarci più sopra. |
| 3. **Metterci una pietra sopra** | | C. Grande azienda agricola collettiva sovietica dove i contadini lavoravano insieme per lo Stato. |
| 4. **Binario morto** | | D. Lavorato con inserti di legni pregiati di diverso colore per formare disegni geometrici. |
| 5. **Intarsiato** | | E. Persona incline alla pigrizia che cerca qualsiasi scusa per evitare i lavori pesanti. |

---

## 5. Attività Speciale "Fuori dagli Schemi"

**La vita nel Kolkhoz e la strategia degli Scacchi**  
Nel Blocco 4 si incontrano due aspetti della vita russa dell'epoca: il lavoro nella grande fattoria collettiva (**Kolkhoz**) e il gioco degli **scacchi**, amatissimo da Nadya e Anna.  
Svolgi sul tuo quaderno una delle due attività (o entrambe):
1. *La mappa del Kolkhoz:* disegna una pianta della fattoria sul Volga (il dormitorio nel fienile, le stalle, la catena per caricare i bidoni del latte sui camion e i campi di grano);
2. *La scacchiera della resistenza:* spiega in che modo la calma, la riflessione e la pazienza necessarie a scacchi somiglino al modo in cui Nadya e Viktor cercano di resistere alla paura della guerra.

---

### GUIDA E RIASSUNTO PER IL DOCENTE

#### Riassunto sintetico dei capitoli
- **Capitolo 11 (Mga, 7 luglio 1941 - Nadya):** Il treno 76 è bloccato da quattro giorni a Mga, ad appena 70 km da Leningrado. Nadya legge *Anna Karenina* per ingannare il tempo; una madre, Irina, apprende che le colonne corazzate tedesche hanno già espugnato Pskov, rendendo l'evacuazione verso gli Urali impraticabile.
- **Capitolo 12 (7–11 luglio 1941 - Viktor):** Viktor è alloggiato nel granaio fatiscente di un *kolkhoz* sul Volga, a cinquanta chilometri da Kazan. Sotto gli ordini del rude capobrigata Garayev i ritmi sono estenuanti; Viktor compatta i compagni (Lev, Flavio, Kostya, Klara) emarginando il pigro Mikhail. L'11 luglio simula un incidente durante la mungitura per caricare i bidoni del latte e nascondersi sul camion per Kazan. In stazione scopre che il treno 76 non è mai arrivato; fermato dal direttore Khasanov, viene perdonato e ricondotto al villaggio con un ammonimento.
- **Capitolo 13 (Mga, 14–17 luglio 1941 - Nadya):** Le mamme fondano il "Soviet delle Mamme" per esigere viveri e sapone dal commissario Bok. Nadya fa amicizia con Anna Tereshenkov: di notte analizzano partite di scacchi dei maestri Ragozin e Botvinnik. L'annuncio di Bok sul rimpatrio a Leningrado tramite camion si rivela un'illusione: i mezzi non compaiono e la tensione cresce.

#### Soluzioni ed elementi chiave di correzione
- **1.A Domande aperte:**
  1. *Un viaggio a passo di lumaca:* Il treno è bloccato a pochi chilometri da Leningrado anziché allontanarsi verso la salvezza; le truppe tedesche avanzano rapidamente e la linea rischia di essere tagliata.
  2. *La dura vita nel kolkhoz:* Sveglia prima dell'alba, fango, dormitorio freddo e infestato dai topi, cibo scarso e la severità inflessibile del capobrigata.
  3. *Il piano dei bidoni del latte:* Fingono di inciampare per caricare i pesanti contenitori e scivolare sul cassone; a Kazan Viktor scopre che il treno 76 non è mai giunto a destinazione.
  4. *Un direttore severo ma comprensivo:* Garayev vede nei ragazzi solo braccia da lavoro; Khasanov riconosce il dolore sincero di Viktor e antepone l'umanità alla punizione formale.
  5. *La vita sul binario morto:* Il "Soviet delle Mamme" organizza la vita quotidiana, l'igiene e i pasti; i vagoni diventano alloggi e aule; Bok promette aiuti che non arriveranno mai.
- **1.B Vero o Falso:**
  1. **VERO.** Il treno ha coperto pochissima strada ed è sorvegliato da sentinelle.
  2. **FALSO.** Mikhail cerca ogni pretesto per scansare la fatica e non collabora.
  3. **VERO.** Khasanov capisce le motivazioni del ragazzo e lo riaccompagna senza punirlo.
  4. **VERO.** Gli scacchi uniscono le due amiche e le aiutano a distrarsi dalla paura.
  5. **FALSO.** Nessun veicolo arriva a soccorrere i passeggeri del treno a Mga.
- **2. Analisi dei Personaggi:**
  1. *Viktor:* Dimostra doti di guida valorizzando le qualità pratiche dei compagni e tenendo alto il morale senza ricorrere alla prepotenza.
  2. *Anna:* Ragazza colta ed equilibrata, trasmette serenità a Nadya condividendo la sua passione per lo studio e la logica degli scacchi.
- **3. Officina di Scrittura:** Verificare la resa dell'angoscia per la sorte della sorella, la gratitudine verso il direttore e la determinazione a non arrendersi.
- **4. Laboratorio Lessicale:** Combinazione corretta: `1-C, 2-E, 3-B, 4-A, 5-D`.
- **5. Attività Speciale:** Valutare la comprensione del funzionamento della vita comune e la capacità di cogliere il valore simbolico degli scacchi.
