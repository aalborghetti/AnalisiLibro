# SCHEDA DIDATTICA DI LETTURA E COMPRENSIONE
## *La sfolgorante luce di due stelle rosse* di Davide Morosinotto
### Unità Didattica 6 (Blocco 6): *Capitolo 16* – *Capitolo 19*

---

**Nome e Cognome dello studente:** ________________________________________  
**Classe:** ____________________  **Data:** ____________________  

---

> ### 🌊 Tra la fortezza di Oreshek e i misteri di Shlisselburg
> «Questa è una terra di cieli e acquitrini, di prati verdissimi e boschi, laghi e fiumi, e l'acqua è azzurra perché riflette il cielo...»  
> Giunti nell'antico borgo di Shlisselburg, sulle sponde del maestoso lago Ladoga, Nadya e i compagni scoprono un paese sospeso nel tempo, protetto dalla cupa mole della fortezza di Oreshek. Ma dietro i divieti ossessivi del comitato locale e le parole distorte della radio, si spalanca un enigma inquietante che riguarda direttamente la loro sorte.

---

## 1. Comprensione del Testo

### A. Domande a risposta aperta
*Rispondi sul tuo quaderno in modo completo, motivando le tue risposte con riferimenti precisi al testo.*

1. **L'incendio nella notte a Mga:**  
   Nel Capitolo 16 Nadya racconta la distruzione del convoglio 76, divorato da un rogo notturno mentre i ragazzi dormivano sotto le pensiline. Quali dubbi sollevano la signora Esipova e le altre madri sulle cause dell'incendio e perché il commissario Bok si affretta a definirlo una casualità?

2. **Le regole della chiesa di San Nicola:**  
   Alloggiati nella chiesa sconsacrata di Shlisselburg, i rifugiati ricevono dal comitato di villaggio una lista di rigorosi divieti. Quali prescrizioni vengono imposte e per quale ragione Nadya le giudica assurde e crudeli?

3. **L'isola di Oreshek tra storia e leggenda:**  
   Durante un'uscita in barca con Boris, Anna e Sergey, Nadya contempla la fortezza di Oreshek sul Ladoga. Quali vicende storiche legano quell'antico baluardo alle guerre contro gli svedesi e alle prigioni dell'epoca zarista?

4. **Il giornale delle uova fresche:**  
   Mentre aiuta in cucina, Nadya maneggia un foglio della *Leningradskaya Pravda* del 19 luglio utilizzato da Irina per incartare uova di contrabbando. Quale sconcertante verità emerge leggendo quell'articolo e confrontandolo con la loro presenza nel paese?

5. **Il radiogiornale spiato dall'albero:**  
   Nel Capitolo 19 Nadya sale su un frassino davanti alla casa del popolo per origliare il notiziario radiofonico. Cosa comunica la voce ufficiale sulla tragedia del treno 76 e quale calcolo politico spinge le autorità a nascondere l'esistenza dei sopravvissuti?

---

### B. Vero o Falso? (Attenzione ai dettagli)
*Indica se ciascuna affermazione è Vera (V) o Falsa (F). Correggi le affermazioni false sul tuo quaderno.*

| Affermazione | V | F |
| :--- | :---: | :---: |
| 1. Nella marcia a piedi verso Shlisselburg, Nadya stringe amicizia con Lilya, una loquace ragazzina di Mosca che cammina svelta. | | |
| 2. Il commissario Bok accoglie con calore i ragazzi nella cattedrale distribuendo coperte pulite e dolciumi per sollevare il morale. | | |
| 3. L'antica fortezza di Oreshek fu battezzata così perché la sua posizione strategica la rendeva dura da espugnare come un nocciolo. | | |
| 4. Nadya e le sue amiche apprendono della propria presunta morte leggendo una circolare ministeriale affissa nella piazza del paese. | | |
| 5. Per coprire la salita di Nadya sull'albero, Anna e Lilya simulano un'animata discussione lungo il viale attirando l'attenzione dei passanti. | | |

---

## 2. Analisi dei Personaggi e Riflessione
*Rispondi alle seguenti domande sul tuo quaderno, analizzando a fondo i personaggi e motivando le tue considerazioni.*

1. **Nadya l'investigatrice (Contro la congiura del silenzio):**  
   A Shlisselburg gli adulti intimano ai ragazzi di tacere, dimenticare il treno e non porre domande. Come reagisce Nadya a questa imposizione e in che modo la sua ostinata ricerca della verità dimostra autonomia di giudizio e coraggio civile?

2. **La dedizione discreta di Boris:**  
   In queste pagine Boris si rivela un alleato insostituibile: governa la barca sul lago, sostiene Nadya nella salita sull'albero e vigila sui compagni. Come si è trasformato il rapporto tra lui e la protagonista rispetto agli esordi del racconto?

---

## 3. Officina di Scrittura Creativa ed Empatia
*Svolgi la seguente attività di scrittura sul tuo quaderno.*

Immagina di essere **Nadya** appollaiata tra i rami dell'albero davanti alla casa del popolo, mentre dalla finestra aperta la radio diffonde la solenne commemorazione dei "piccoli martiri del treno 76 caduti per la Patria". Tu sei viva, arrabbiata e costretta a nasconderti tra il fogliame. Scrivi sul tuo quaderno una pagina di diario in prima persona: esprimi il turbamento di essere stata cancellata dagli elenchi dei vivi dallo stesso Stato che doveva proteggerti e la fiera determinazione a far sentire la tua voce.

---

## 4. Laboratorio Lessicale e Modi di Dire
*Associa ciascun vocabolo o espressione d'autore al suo significato nel contesto del racconto (indica sul quaderno la combinazione corretta numero-lettera).*

| Termine o Modo di Dire | Abbinamento | Significato Contestuale |
| :--- | :---: | :--- |
| 1. **Sagrestia** | [   ] | A. Locale annesso alla chiesa dove si custodiscono arredi sacri e paramenti, adibito a ricovero per le mamme. |
| 2. **Cattedrale** | [   ] | B. Emblema grafico o figurativo che racchiude valori storici, ideali o simboli identitari di un gruppo. |
| 3. **Canale artificiale** | [   ] | C. Grande edificio di culto principale di una comunità, caratterizzato da dimensioni imponenti e navate ampie. |
| 4. **Fortezza** | [   ] | D. Via d'acqua scavata dall'uomo per consentire il transito protetto dei battelli al riparo dalle burrasche del lago. |
| 5. **Simbologia** | [   ] | E. Complesso difensivo in muratura provvisto di torri e bastioni, eretto a presidio di un varco strategico. |

---

## 5. Attività Speciale "Fuori dagli Schemi"

**Codice Segreto, Stemma o Simbologia: L'Emblema dei Sopravvissuti del Treno 76**  
Dichiarati ufficialmente deceduti dalla propaganda, i ragazzi della chiesa di San Nicola rifiutano di rassegnarsi a essere fantasmi senza nome.  
Disegna e descrivi sul tuo quaderno lo **Stemma Segreto dei Sopravvissuti**:
1. Inserisci elementi figurativi coerenti con la narrazione: una stella rossa stilizzata ma attraversata da una cicatrice o una crepa, le merlature della fortezza di Oreshek, le acque del Ladoga, un quaderno ad anelli con penna e matita incrociate.
2. Componi un **motto in codice** (in lingua italiana o in latino, traendo ispirazione dagli studi di Anna) che esprima il rifiuto della menzogna e il valore della memoria documentata.

---

### GUIDA E RIASSUNTO PER IL DOCENTE

#### Riassunto sintetico dei capitoli
- **Capitolo 16 (luglio 1941 - Nadya):** A Mga il treno 76 viene distrutto nottetempo da un rogo fulmineo; la signora Esipova sospetta un dolo o un attentato, mentre Bok minimizza. I passeggeri compiono a piedi la marcia verso Shlisselburg. Nadya stringe amicizia con Lilya di Mosca; tutti vengono accampati nella chiesa di San Nicola. Il comitato locale proibisce severamente di comunicare con l'esterno e di menzionare il convoglio o la guerra.
- **Capitolo 17:** Durante una battuta di pesca in barca con Boris, Anna e Sergey, Nadya osserva l'isola di Oreshek (Noteborg), fondata nel Duecento sul Ladoga e trasformata dagli zar in prigione politica dove fu giustiziato il fratello di Lenin.
- **Capitolo 18 (9–13 agosto 1941):** Irina procura uova al mercato nero avvolte in una pagina della *Leningradskaya Pravda* del 19 luglio. Nadya e le compagne leggono che il treno 76 è stato dichiarato distrutto senza superstiti: comprendono che la burocrazia sovietica le ha cancellate per mascherare il fallimento dell'evacuazione.
- **Capitolo 19 (13 agosto 1941):** Nadya si arrampica su un albero vicino alla casa del popolo mentre Anna e Lilya fingono un alterco in strada per sviare l'attenzione. Origliando il bollettino radio, ascolta l'omaggio solenne ai bambini "periti" a Mga: la menzogna di Stato trasforma i vivi in testimoni scomodi da occultare nel silenzio.

#### Soluzioni ed elementi chiave di correzione
- **1.A Domande aperte:**
  1. *L'incendio a Mga:* Il treno brucia simultaneamente da cima a fondo; le madri ipotizzano un attentato o un versamento di carburante, mentre Bok cerca di soffocare le indagini per coprire la disorganizzazione logistica.
  2. *Le regole della chiesa di San Nicola:* È fatto divieto di inviare lettere, telegrafare e pronunciare parole su Leningrado e sul convoglio; Nadya vi scorge un tentativo autoritario di annullare la loro identità civile.
  3. *L'isola di Oreshek:* Sorta come fortilizio difensivo sulle foci del Ladoga per respingere le incursioni svedesi, divenne celebre come carcere politico zarista, teatro di esecuzioni di rivoluzionari celebri.
  4. *Il giornale delle uova fresche:* Il quotidiano certifica la loro morte ufficiale; confrontando il foglio con la loro presenza materiale, realizzano che lo Stato ha già archiviato il dossier sacrificando la verità storica alla propaganda.
  5. *Il radiogiornale spiato dall'albero:* Il notiziario esalta il sacrificio patriottico dei giovani; le autorità perseverano nell'inganno per non ammettere l'avanzata nazista verso le porte di Leningrado e giustificare l'evacuazione coatta.
- **1.B Vero o Falso:**
  1. **VERO.** Lilya diventa una compagna fedele e spigliata durante il cammino.
  2. **FALSO.** Bok è evasivo, inquieto e impone divieti perentori evitando ogni confidenza.
  3. **VERO.** La denominazione rimanda alla consistenza dura e resistente del nocciolo.
  4. **FALSO.** Trovano la notizia per puro caso leggendo la carta da imballaggio delle uova.
  5. **VERO.** Il finto diverbio di Anna e Lilya consente a Nadya di arrampicarsi indisturbata.
- **2. Analisi dei Personaggi:**
  1. *Nadya l'investigatrice:* Rifiuta la passività imposta dagli adulti; sfrutta l'osservazione scientifica, il confronto dei dati e l'audacia per far emergere i fatti oltre la cortina della censura.
  2. *La dedizione di Boris:* Boris dimostra intelligenza pratica e sensibilità d'animo, confermandosi come spalla fidata nelle esplorazioni e custode vigile della sicurezza dei compagni.
- **3. Officina di Scrittura:** Verificare la modulazione del testo: indignazione morale per la cancellazione burocratica e orgoglio ribelle nel riaffermare la propria esistenza.
- **4. Laboratorio Lessicale:** Combinazione corretta: `1-A, 2-C, 3-D, 4-E, 5-B`.
- **5. Attività Speciale:** Valutare la sintesi concettuale dello stemma (inclusione dei motivi iconografici centrali) e l'efficacia del motto civico prescelto.
