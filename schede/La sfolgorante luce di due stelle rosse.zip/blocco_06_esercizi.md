# SCHEDA DIDATTICA DI LETTURA E COMPRENSIONE
## *La sfolgorante luce di due stelle rosse* di Davide Morosinotto
### Unità Didattica 6 (Blocco 6): *Capitolo 16* – *Capitolo 19*

---

**Nome e Cognome dello studente:** ________________________________________  
**Classe:** ____________________  **Data:** ____________________  

---

> ### 🌊 Tra la fortezza di Oreshek e i misteri di Shlisselburg
> «Questa è una terra di cieli e acquitrini, di prati verdissimi e boschi, laghi e fiumi, e l'acqua è azzurra perché riflette il cielo...»  
> Giunti nell'antico borgo di Shlisselburg, sulle rive del maestoso lago Ladoga, Nadya e i compagni scoprono un paese protetto dalla sagoma severa della fortezza di Oreshek. Ma dietro i divieti del comitato locale e le parole distorte della radio, si nasconde un mistero inquietante che riguarda proprio il loro destino.

---

## 1. Comprensione del Testo

### A. Domande a risposta aperta
*Rispondi sul tuo quaderno in modo chiaro e completo, facendo riferimento a ciò che hai letto nel testo.*

1. **L'incendio nella notte a Mga:**  
   Nel Capitolo 16 Nadya racconta la distruzione del convoglio 76, bruciato in un rogo notturno mentre i ragazzi dormivano sotto le pensiline. Quali dubbi hanno le mamme sulle cause dell'incendio e perché il commissario Bok si affretta a definirlo un semplice incidente?

2. **Le regole della chiesa di San Nicola:**  
   Alloggiati nella chiesa sconsacrata di Shlisselburg, i rifugiati ricevono dal comitato del paese una lista di divieti severissimi. Cosa viene loro proibito e perché Nadya trova queste regole ingiuste e crudeli?

3. **L'antica fortezza di Oreshek:**  
   Durante un'uscita in barca a remi con Boris, Anna e Sergey, Nadya contempla la fortezza di Oreshek sul lago Ladoga. Quali storie del passato legano quell'antico castello alle guerre e alle prigioni dell'epoca zarista?

4. **La verità sul foglio delle uova:**  
   Mentre aiuta a pulire in cucina, Nadya legge per caso un pezzo di giornale usato da una madre per avvolgere uova di contrabbando. Quale incredibile notizia scopre leggendo quell'articolo?

5. **Il radiogiornale ascoltato dall'albero:**  
   Nel Capitolo 19 Nadya sale su un frassino davanti alla casa del popolo per origliare il notiziario alla radio. Cosa dice la voce ufficiale sui bambini del treno 76 e perché le autorità nascondono che sono ancora vivi?

---

### B. Vero o Falso? (Attenzione ai dettagli)
*Indica se ciascuna affermazione è Vera (V) o Falsa (F). Correggi le affermazioni false sul tuo quaderno.*

| Affermazione | V | F |
| :--- | :---: | :---: |
| 1. Nella marcia a piedi verso Shlisselburg, Nadya fa amicizia con Lilya, una simpatica e chiacchierina ragazzina di Mosca. | | |
| 2. Il commissario Bok accoglie i ragazzi con calore, offrendo coperte pulite e dolciumi per tirare su il morale. | | |
| 3. L'antica fortezza di Oreshek deve il suo nome al fatto che la sua posizione sull'acqua la rendeva dura da conquistare come una noce. | | |
| 4. Nadya e le sue amiche scoprono di essere considerate morte leggendo un bando ufficiale affisso nella piazza del paese. | | |
| 5. Per coprire Nadya mentre sale sull'albero, Anna e Lilya fingono un litigio rumoroso in strada per distrarre i passanti. | | |

---

## 2. Analisi dei Personaggi e Riflessione
*Rispondi alle seguenti domande sul tuo quaderno, riflettendo bene sui comportamenti dei protagonisti.*

1. **Nadya non si arrende al silenzio:**  
   A Shlisselburg gli adulti dicono ai ragazzi di tacere, di non parlare del treno e di non fare domande. Come reagisce Nadya a queste imposizioni e cosa dimostra la sua ostinazione nel cercare la verità?

2. **L'aiuto discreto di Boris:**  
   In queste pagine Boris si dimostra un amico prezioso: governa la barca sul lago, sostiene Nadya nella salita sull'albero e vigila sui compagni. Come è cambiato il legame tra lui e Nadya rispetto all'inizio del libro?

---

## 3. Officina di Scrittura Creativa ed Empatia
*Svolgi la seguente attività di scrittura sul tuo quaderno.*

Immagina di essere **Nadya** nascosta tra i rami dell'albero davanti alla casa del popolo, mentre dalla finestra aperta la radio trasmette la commemorazione ufficiale dei "piccoli martiri del treno 76 caduti per la Patria". Tu sei viva, arrabbiata e costretta a tacere tra le foglie. Scrivi sul tuo quaderno una pagina di diario in prima persona: esprimi il turbamento di essere stata considerata morta da chi doveva proteggerti e la tua ferma decisione di non arrenderti.

---

## 4. Laboratorio Lessicale e Modi di Dire
*Associa ciascun vocabolo o espressione d'autore al suo significato nel contesto del racconto (indica sul quaderno la combinazione corretta numero-lettera).*

| Termine o Modo di Dire | Abbinamento | Significato Contestuale |
| :--- | :---: | :--- |
| 1. **Sagrestia** | | A. Locale annesso alla chiesa dove si tengono arredi e paramenti, usato qui come stanza per le mamme. |
| 2. **Cattedrale** | | B. Insieme di disegni, figure e simboli scelti per esprimere un significato o un ideale comune. |
| 3. **Canale artificiale** | | C. Grande chiesa principale di una città, imponente e con ampie navate. |
| 4. **Fortezza** | | D. Corso d'acqua scavato dall'uomo per consentire il transito sicuro delle imbarcazioni al riparo dalle onde. |
| 5. **Simbologia** | | E. Grande complesso difensivo in muratura provvisto di torri e bastioni, costruito per respingere i nemici. |

---

## 5. Attività Speciale "Fuori dagli Schemi"

**Lo Stemma Segreto dei Sopravvissuti del Treno 76**  
Dichiarati ufficialmente deceduti dalla propaganda, i ragazzi della chiesa di San Nicola rifiutano di rassegnarsi a essere fantasmi senza nome.  
Disegna e descrivi sul tuo quaderno lo **Stemma Segreto dei Sopravvissuti**:
1. *I simboli:* disegna uno scudo inserendo immagini legate alla loro avventura (una stella rossa, le mura della fortezza di Oreshek, le onde del lago Ladoga, un quaderno con penna e matita incrociate);
2. *Il motto:* inventa un motto breve e d'impatto (in italiano o in latino, come le frasi che piacciono ad Anna) che ricordi a tutti che la verità non si può cancellare.

---

### GUIDA E RIASSUNTO PER IL DOCENTE

#### Riassunto sintetico dei capitoli
- **Capitolo 16 (luglio 1941 - Nadya):** A Mga il treno 76 viene distrutto nottetempo da un rogo fulmineo; la signora Esipova sospetta un dolo o un attentato, mentre Bok minimizza. I passeggeri compiono a piedi la marcia verso Shlisselburg. Nadya stringe amicizia con Lilya di Mosca; tutti vengono accampati nella chiesa di San Nicola. Il comitato locale proibisce severamente di comunicare con l'esterno e di menzionare il convoglio o la guerra.
- **Capitolo 17:** Durante una battuta di pesca in barca con Boris, Anna e Sergey, Nadya osserva l'isola di Oreshek (Noteborg), fondata nel Duecento sul Ladoga e trasformata dagli zar in prigione politica dove fu giustiziato il fratello di Lenin.
- **Capitolo 18 (9–13 agosto 1941):** Irina procura uova al mercato nero avvolte in una pagina della *Leningradskaya Pravda* del 19 luglio. Nadya e le compagne leggono che il treno 76 è stato dichiarato distrutto senza superstiti: comprendono che la burocrazia sovietica le ha cancellate per mascherare il fallimento dell'evacuazione.
- **Capitolo 19 (13 agosto 1941):** Nadya si arrampica su un albero vicino alla casa del popolo mentre Anna e Lilya fingono un alterco in strada per sviare l'attenzione. Origliando il bollettino radio, ascolta l'omaggio solenne ai bambini "periti" a Mga: la menzogna di Stato trasforma i vivi in testimoni scomodi da occultare nel silenzio.

#### Soluzioni ed elementi chiave di correzione
- **1.A Domande aperte:**
  1. *L'incendio a Mga:* Il treno brucia rapidamente da cima a fondo; le mamme sospettano un attentato o combustibile versato apposta, mentre Bok vuole chiudere il caso per non svelare l'inefficienza dei trasporti.
  2. *Le regole della chiesa di San Nicola:* È vietato scrivere lettere, telegrafare e parlare del convoglio o di Leningrado; Nadya vi scorge il tentativo di togliere loro l'identità.
  3. *L'antica fortezza di Oreshek:* Sorta per difendere il lago Ladoga dagli attacchi svedesi, divenne celebre come carcere politico zarista dove venivano rinchiusi i rivoluzionari.
  4. *La verità sul foglio delle uova:* Il giornale certifica la morte di tutti i passeggeri del treno 76; leggendolo capiscono che lo Stato ha deciso di nascondere il fallimento dell'evacuazione.
  5. *Il radiogiornale dall'albero:* Il bollettino commemora i bambini come eroi scomparsi per non ammettere che la linea ferroviaria verso gli Urali è stata interrotta dai tedeschi.
- **1.B Vero o Falso:**
  1. **VERO.** Lilya è una compagna spiritosa e leale che alleggerisce la fatica del cammino.
  2. **FALSO.** Bok è agitato, freddo e ordina divieti severi senza mostrare affetto.
  3. **VERO.** Il nome rimanda alla robustezza del nocciolo di noce (*oreshek* in russo).
  4. **FALSO.** Scoprono la notizia casualmente leggendo la carta usata per le uova.
  5. **VERO.** La recita del finto diverbio distrae la gente e permette a Nadya di arrampicarsi.
- **2. Analisi dei Personaggi:**
  1. *Nadya:* Rifiuta di restare passiva e usa curiosità, spirito di osservazione e coraggio per far emergere la realtà oltre le bugie ufficiali.
  2. *Boris:* Dimostra intelligenza pratica e grande delicatezza; la sua presenza discreta rassicura Nadya e la aiuta nei momenti decisivi.
- **3. Officina di Scrittura:** Verificare la resa della rabbia di Nadya di fronte alla propaganda e l'affermazione fiera della propria vita.
- **4. Laboratorio Lessicale:** Combinazione corretta: `1-A, 2-C, 3-D, 4-E, 5-B`.
- **5. Attività Speciale:** Valutare la coerenza dei simboli disegnati con le vicende del racconto e l'originalità del motto ideato.
