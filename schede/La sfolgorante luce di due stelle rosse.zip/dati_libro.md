# Dati del Libro

- **Titolo:** La sfolgorante luce di due stelle rosse. Il caso dei quaderni di Viktor e Nadya
- **Autore:** Davide Morosinotto
- **Anno di pubblicazione:** 2017
- **Editore:** Mondadori
- **Genere:** Romanzo storico di formazione e avventura
- **Ambientazione:** Leningrado e Unione Sovietica, giugno – novembre 1941 (con cornice d'indagine nel dicembre 1946)
- **Target scolastico:** Scuola secondaria di primo grado (11-13 anni)
- **Unità didattiche:** 9 blocchi narrativi (28 capitoli, rapporti NKVD e conclusione)

## Piano delle Unità Didattiche

- **Blocco 1** — Capitoli: *Prologo* – *Capitolo 3* · Nucleo tematico: L'irruzione della Grande Storia nella vita quotidiana, il valore dell'arte e il peso dei segreti · Attività speciale: Mappa Topografica o Tattica
- **Blocco 2** — Capitoli: *Capitolo 4* – *Capitolo 7* · Nucleo tematico: Propaganda contro realtà, il sacrificio familiare e il dolore del distacco · Attività speciale: Processo in Aula / Dibattito (Debate)
- **Blocco 3** — Capitoli: *Capitolo 8* – *Capitolo 10* · Nucleo tematico: Il trauma della separazione, l'istinto di sopravvivenza e la nascita della leadership nel gruppo dei pari · Attività speciale: Dossier Investigativo / Caccia all'Indizio
- **Blocco 4** — Capitoli: *Capitolo 11* – *Capitolo 13* · Nucleo tematico: L'adattamento forzato, la fatica del lavoro collettivo e il potere salvifico dell'amicizia e del gioco · Attività speciale: Taccuino Naturalistico / Storico / Tecnico
- **Blocco 5** — Capitoli: *Capitolo 14* – *Capitolo 15* · Nucleo tematico: La manipolazione dell'informazione, il pregiudizio verso il "nemico interno" e la lealtà oltre la paura · Attività speciale: Redazione Giornalistica d'Epoca
- **Blocco 6** — Capitoli: *Capitolo 16* – *Capitolo 19* · Nucleo tematico: La menzogna di Stato, la clandestinità forzata e il coraggio della solidarietà · Attività speciale: Codice Segreto, Stemma o Simbologia
- **Blocco 7** — Capitoli: *Capitolo 20* – *Capitolo 23* · Nucleo tematico: La perdita dell'innocenza sotto le bombe, i compromessi morali per sopravvivere e la memoria dei caduti · Attività speciale: Mappa Topografica o Tattica
- **Blocco 8** — Capitoli: *Capitolo 24* – *Capitolo 27* · Nucleo tematico: La disumanizzazione nei campi di lavoro (Gulag), la forza del patto fraterno e il prezzo della libertà · Attività speciale: Processo in Aula / Dibattito (Debate)
- **Blocco 9** — Capitoli: *Capitolo 28* – *Epilogo* · Nucleo tematico: La resistenza estrema nella fortezza assediata, il ricongiungimento e il giudizio della Storia · Attività speciale: Dossier Investigativo / Caccia all'Indizio
