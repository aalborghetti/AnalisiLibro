# Dati del Libro

- **Titolo:** La sfolgorante luce di due stelle rosse. Il caso dei quaderni di Viktor e Nadya
- **Autore:** Davide Morosinotto
- **Anno di pubblicazione:** 2017
- **Editore:** Mondadori
- **Genere:** Romanzo storico di formazione e avventura
- **Ambientazione:** Leningrado e Unione Sovietica, giugno – novembre 1941 (con cornice d'indagine nel dicembre 1946)
- **Target scolastico:** Scuola secondaria di primo grado (classe seconda media, 12-13 anni)
- **Unità didattiche:** 9 blocchi narrativi (28 capitoli, rapporti NKVD e conclusione)

## Piano delle Unità Didattiche

- **Blocco 1** — Capitoli: *Prologo* – *Capitolo 3* · Nucleo tematico: L'inizio della guerra a Leningrado, la passione per l'arte e i primi segreti · Attività speciale: Mappa a confronto (L'Ermitage e il barak)
- **Blocco 2** — Capitoli: *Capitolo 4* – *Capitolo 7* · Nucleo tematico: La guardia sui tetti, il sacrificio della famiglia e la partenza · Attività speciale: Dibattito e processo in classe
- **Blocco 3** — Capitoli: *Capitolo 8* – *Capitolo 10* · Nucleo tematico: La separazione alla stazione, la vita sul vagone bestiame e l'unione dei ragazzi · Attività speciale: Il rapporto investigativo sulla stazione
- **Blocco 4** — Capitoli: *Capitolo 11* – *Capitolo 13* · Nucleo tematico: La fatica nel kolkhoz sul Volga, l'attesa a Mga e la passione per gli scacchi · Attività speciale: Scheda illustrata del kolkhoz e della scacchiera
- **Blocco 5** — Capitoli: *Capitolo 14* – *Capitolo 15* · Nucleo tematico: Le notizie di guerra, il segreto di Klara e la speranza che non muore · Attività speciale: La prima pagina del giornalino clandestino
- **Blocco 6** — Capitoli: *Capitolo 16* – *Capitolo 19* · Nucleo tematico: L'arrivo a Shlisselburg, la fortezza di Oreshek e la ricerca della verità · Attività speciale: Lo stemma segreto dei sopravvissuti
- **Blocco 7** — Capitoli: *Capitolo 20* – *Capitolo 23* · Nucleo tematico: L'ospedale nella cattedrale, l'attacco nemico e il coraggio di Nadya · Attività speciale: La mappa strategica del lago Ladoga
- **Blocco 8** — Capitoli: *Capitolo 24* – *Capitolo 27* · Nucleo tematico: La fame a Mosca, la dura prova del campo di lavoro e la fuga notturna · Attività speciale: La difesa dei ragazzi in tribunale
- **Blocco 9** — Capitoli: *Capitolo 28* – *Epilogo* · Nucleo tematico: La fortezza assediata, il ricongiungimento dei gemelli e il verdetto finale · Attività speciale: La sentenza del colonnello Smirnov
