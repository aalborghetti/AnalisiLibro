# SCHEDA DIDATTICA DI LETTURA E COMPRENSIONE
## *La sfolgorante luce di due stelle rosse* di Davide Morosinotto
### Unità Didattica 8 (Blocco 8): *Capitolo 24* – *Capitolo 27*

> ### 🌊 Nel ventre del Gulag e la fuga nella notte gelata
> «La libertà ha sempre un buon odore.»  
> Considerati dispersi nel caos della guerra, Viktor e i compagni cadono nell'incubo di un campo di lavoro forzato sulle sponde del bacino di Rybinsk. Tra i turni massacranti con le carriole di ghiaia, i morsi della fame e un cunicolo clandestino scavato sotto il reticolato, la lealtà e l'amicizia si dimostrano più forti di qualsiasi prigione.

---

## 1. Comprensione del Testo

### A. Domande a risposta aperta
*Rispondi sul tuo quaderno in modo chiaro e completo, facendo riferimento a ciò che hai letto nel testo.*

1. **La fame a Mosca e lo scontro con Lev:**  
   Nel Capitolo 24, dopo essere stati derubati di tutti i soldi a Mosca, Lev affamato strappa due pagnotte a una passante per strada. Perché Viktor lo affronta a pugni per fermarlo e quale regola morale vuole difendere?

2. **L'inganno del treno e l'arrivo a Rybinsk:**  
   Convinti di salire su un treno operaio diretto a nord, i ragazzi scoprono la verità da un bibliotecario di bordo. Qual è la reale destinazione del convoglio e cosa succede quando Viktor cerca di spiegare che sono solo dei ragazzi?

3. **La legge delle carriole e il patto con Mikhail:**  
   Nel campo di lavoro forzato i detenuti devono spostare enormi quantità di ghiaia per la centrale idroelettrica. Quale accordo stringe Viktor con Mikhail e cosa promette di rivelargli quest'ultimo sul convoglio 76?

4. **Il tunnel sotto la baracca 5:**  
   Nel Capitolo 26 alcuni prigionieri completano un cunicolo sotterraneo per fuggire sotto il filo spinato. Cosa pretendono in cambio prima di far passare i ragazzi e cosa riesce a salvare Viktor a ogni costo?

5. **L'astuzia delle latrine nella notte di caccia:**  
   Quando scatta l'allarme e i cani delle guardie si lanciano sulle loro tracce nel bosco, Viktor ha un'intuizione disgustosa ma geniale. Dove si nascondono i ragazzi e perché quel nascondiglio inganna i segugi?

---

### B. Vero o Falso? (Attenzione ai dettagli)
*Indica se ciascuna affermazione è Vera (V) o Falsa (F). Correggi le affermazioni false sul tuo quaderno.*

| Affermazione | V | F |
| :--- | :---: | :---: |
| 1. A Mosca Lev sottrae il pane a una passante perché i ragazzi sono rimasti senza un soldo e tormentati dalla fame. | | |
| 2. Giunti a Rybinsk, i comandanti del campo capiscono subito l'errore e rilasciano i ragazzi su un comodo treno passeggeri. | | |
| 3. Nel campo di Rybinsk le ragazze e i ragazzi della brigata alloggiano insieme nella medesima baracca per proteggersi. | | |
| 4. Mikhail consegna a Viktor un coltellino da tasca in cambio dell'aiuto e della protezione del gruppo. | | |
| 5. Durante l'inseguimento notturno i cani delle guardie raggiungono i fuggitivi nel bosco riconducendoli in catene nel recinto. | | |

---

## 2. Analisi dei Personaggi e Riflessione
*Rispondi alle seguenti domande sul tuo quaderno, riflettendo bene sui comportamenti dei protagonisti.*

1. **Il riscatto morale di Lev:**  
   A Mosca Lev scivola nel furto per disperazione, ma nel campo di Rybinsk la fatica comune e la protezione del piccolo Ilya lo trasformano in un pilastro della brigata. Come giudichi questo cambiamento di Lev?

2. **La prova difficile di Viktor:**  
   Nel campo di lavoro Viktor deve farsi duro: minaccia Mikhail, pretende disciplina e organizza la fuga. Come fa a non trasformarsi in un prepotente, mantenendo intatto il proprio affetto per gli amici?

---

## 3. Officina di Scrittura Creativa ed Empatia
*Svolgi la seguente attività di scrittura sul tuo quaderno.*

Immagina di essere **Klara** mentre strisci nel buio della galleria stretta e fangosa sotto la baracca 5, con il timore continuo che le sentinelle scoprano la botola. Sei già fuggita una volta dalla Germania nazista e ora stai scappando da un campo di lavoro sovietico. Scrivi sul tuo quaderno una pagina di riflessione in prima persona: racconta la paura soffocante del buio, la voglia disperata di rivedere il cielo aperto e la fiducia incrollabile che ti lega a Viktor.

---

## 4. Laboratorio Lessicale e Modi di Dire
*Associa ciascun vocabolo o espressione d'autore al suo significato nel contesto del racconto (indica sul quaderno la combinazione corretta numero-lettera).*

| Termine o Modo di Dire | Abbinamento | Significato Contestuale |
| :--- | :---: | :---: |
| 1. **Gulag** | | A. Persona condannata alla prigione non per reati comuni, ma per le sue idee o per aver criticato il governo. |
| 2. **Quota di lavoro** | | B. Sistema dei campi di lavoro correttivo e forzato nell'Unione Sovietica. |
| 3. **Prigioniero politico** | | C. Quantità minima di lavoro o pietre da scavare imposta ogni giorno per avere la razione di cibo. |
| 4. **Lavoro forzato** | | D. Attività pesantissima imposta con la forza ai prigionieri in condizioni disumane. |
| 5. **Complicità** | | E. Accordo e collaborazione attiva tra più persone per compiere insieme un'azione segreta o rischiosa. |

---

## 5. Attività Speciale "Fuori dagli Schemi"

**Il Piano Tattico di Fuga dalla Baracca 5**  
Nel Capitolo 26 e 27 i ragazzi affrontano uno dei momenti più rischiosi del romanzo: l'evasione notturna dal campo di lavoro forzato di Rybinsk attraverso un cunicolo sotterraneo.  
Progetta e descrivi sul tuo quaderno il **Piano Tattico di Fuga**:
1. *La pianta della fuga:* disegna uno schema del percorso (la baracca 5 con la botola segreta sul pavimento, la galleria scavata nel fango, il passaggio sotto la doppia recinzione di filo spinato, il capanno delle latrine e l'imbocco del bosco di betulle);
2. *La scheda operativa in 3 punti:*
   - **L'orario e il segnale:** quando muoversi (alle tre di notte durante il cambio della guardia) e quale segnale attendere;
   - **L'equipaggiamento essenziale:** cosa portare (i quaderni protetti sotto la giubba, il coltellino di Mikhail, le provviste per la marcia) e cosa abbandonare per muoversi veloci;
   - **Il piano d'emergenza:** l'astuzia per neutralizzare i cani da presa se scatta la sirena d'allarme.

---

### GUIDA E RIASSUNTO PER IL DOCENTE

#### Riassunto sintetico dei capitoli
- **Capitolo 24 (settembre 1941 - Viktor):** A Mosca Lev sottrae pane a una passante dopo essere stato derubato dei soldi; Viktor lo affronta a pugni per ribadire la dignità del gruppo. Con i sette compagni rimasti (Klara, Lev, Flavio, Mikhail, Marya, Ilya) sale su un convoglio merci sperando di raggiungere il fronte settentrionale.
- **Capitolo 25:** Un bibliotecario svela che il convoglio è diretto al famigerato Gulag della centrale idroelettrica GES di Rybinsk. All'arrivo le guardie percuotono Viktor e immatricolano tutti come forzati. Nelle baracche regna la legge dei criminali comuni; i ragazzi formano una squadra per spingere le carriole di ghiaia e raggiungere le quote alimentari. Viktor ottiene la cooperazione di Mikhail, che promette indicazioni preziose sul treno 76 in cambio di protezione.
- **Capitolo 26:** Klara sottrae generi alimentari dalle cucine; Lev e Flavio prendono contatto con i detenuti politici ("Articolo 58") che stanno ultimando un cunicolo sotterraneo sotto la baracca 5. Mikhail cede a Viktor un coltello a serramanico.
- **Capitolo 27:** Durante la notte scatta l'evasione attraverso la botola; i gestori del tunnel derubano i ragazzi delle ultime provviste e scarpe, ma Viktor salva i quaderni rossi. All'esterno risuona la sirena d'allarme; braccati dai cani da presa, i ragazzi riparano nella fossa biologica del capanno delle latrine: l'odore acre confonde i segugi dell'NKVD. Le autorità archiviano i loro nomi fittizi come deceduti, consentendo ai sette compagni di intraprendere a piedi la marcia verso Leningrado.

#### Soluzioni ed elementi chiave di correzione
- **1.A Domande aperte:**
  1. *La fame a Mosca:* Lev agisce per fame estrema; Viktor lo ferma duramente perché non vuole che la disperazione li trasformi in delinquenti e distrugga i loro principi.
  2. *L'inganno di Rybinsk:* Il treno trasporta forzati alla centrale idroelettrica di Rybinsk; le guardie respingono le proteste con la violenza e li rinchiudono nel campo.
  3. *La legge delle carriole:* Si alternano alla spinta delle carriole sostenendo i compagni più deboli; Mikhail baratta le sue informazioni sul treno 76 in cambio di protezione.
  4. *Il tunnel sotto la baracca 5:* I prigionieri pretendono scarpe e viveri come pedaggio; Viktor cede le provviste ma difende i quaderni a costo della vita.
  5. *L'astuzia delle latrine:* Si immergono nel pozzo delle latrine; l'odore pungente azzera l'olfatto dei cani poliziotto consentendo la fuga.
- **1.B Vero o Falso:**
  1. **VERO.** Il furto è un gesto disperato causato dalla fame dopo il furto del denaro.
  2. **FALSO.** Vengono rinchiusi con la forza nei reparti di lavoro forzato.
  3. **FALSO.** I settori maschili e femminili del lager sono rigorosamente divisi dal filo spinato.
  4. **VERO.** Il baratto del coltello suggella l'alleanza tra Viktor e Mikhail.
  5. **FALSO.** I ragazzi eludono l'inseguimento grazie all'astuzia delle latrine.
- **2. Analisi dei Personaggi:**
  1. *Il riscatto di Lev:* La colpa per il furto a Mosca si trasforma in generosità; la forza di Lev diventa protezione affettuosa per il piccolo Ilya e per Klara.
  2. *Viktor:* Usa fermezza solo per mantenere unita la brigata e salvare tutti; non agisce per prepotenza ma per responsabilità fraterna.
- **3. Officina di Scrittura:** Verificare la resa dell'angoscia nel tunnel, la complessità delle origini di Klara e il forte anelito alla libertà.
- **4. Laboratorio Lessicale:** Combinazione corretta: `1-B, 2-C, 3-A, 4-D, 5-E`.
- **5. Attività Speciale:** Valutare la precisione nello schema grafico dei luoghi, la coerenza strategica della scheda operativa e la conoscenza dei dettagli del testo (la botola nella baracca 5, il baratto con i prigionieri politici e l'inganno delle latrine per sviare i cani).
