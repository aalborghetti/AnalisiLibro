# SCHEDA DIDATTICA DI LETTURA E COMPRENSIONE
## *La sfolgorante luce di due stelle rosse* di Davide Morosinotto
### Unità Didattica 8 (Blocco 8): *Capitolo 24* – *Capitolo 27*

---

**Nome e Cognome dello studente:** ________________________________________  
**Classe:** ____________________  **Data:** ____________________  

---

> ### 🌊 Nel ventre del Gulag e la fuga nella notte gelata
> «La libertà ha sempre un buon odore.»  
> Considerati dispersi o inghiottiti dal caos della ritirata, Viktor e i suoi compagni cadono nell'inferno di un campo di lavoro forzato sulle sponde del "mare di Rybinsk". Tra le fatiche estenuanti della ghiaia, la morsa della fame e un cunicolo clandestino scavato sotto il reticolato, la lealtà tra fratelli si dimostra più forte di qualsiasi reclusione.

---

## 1. Comprensione del Testo

### A. Domande a risposta aperta
*Rispondi in modo completo, motivando le tue risposte con riferimenti precisi al testo.*

1. **La disperazione a Mosca e lo scontro con Lev:**  
   Nel Capitolo 24, dopo il furto del denaro subito a Mosca, Lev cede alla fame e aggredisce una donna per impadronirsi di due pagnotte. Perché Viktor reagisce con durezza percuotendo l'amico e quale dilemma morale lacera i ragazzi in quel frangente?
   
_________________________________________________________________________________________  
_________________________________________________________________________________________  
_________________________________________________________________________________________  

2. **L'inganno del treno e l'arrivo a Rybinsk:**  
   Convinti di salire su un treno operaio verso nord, i sette fuggiaschi scoprono la verità da un bibliotecario di bordo. Qual è la reale destinazione del convoglio e come reagiscono le sentinelle del Gulag quando Viktor tenta di spiegare l'errore di persona?
   
_________________________________________________________________________________________  
_________________________________________________________________________________________  
_________________________________________________________________________________________  

3. **La legge delle carriole e il patto con Mikhail:**  
   Per soddisfare le disumane quote giornaliere di ghiaia per la centrale idroelettrica GES ed evitare la fame, i ragazzi si uniscono in una brigata affiatata. Quale accordo stringe Viktor con Mikhail e cosa promette di rivelargli quest'ultimo sul convoglio 76?
   
_________________________________________________________________________________________  
_________________________________________________________________________________________  
_________________________________________________________________________________________  

4. **Il budello sotto la baracca 5:**  
   Nel Capitolo 26 i prigionieri politici "Articolo 58" completano un tunnel sotterraneo sotto la baracca 5. A quale pesante pedaggio vengono sottoposti i ragazzi prima di infilarsi nel cunicolo e cosa riesce a difendere Viktor a ogni costo?
   
_________________________________________________________________________________________  
_________________________________________________________________________________________  
_________________________________________________________________________________________  

5. **L'astuzia delle latrine nella notte di caccia:**  
   Quando scatta l'allarme e i cani dell'NKVD si lanciano sulle loro tracce nel bosco, Viktor ha un'intuizione disgustosa quanto geniale. Dove si rifugiano i ragazzi e perché quel nascondiglio impedisce ai segugi di stanarli?
   
_________________________________________________________________________________________  
_________________________________________________________________________________________  
_________________________________________________________________________________________  

---

### B. Vero o Falso? (Attenzione ai dettagli)
*Indica se l'affermazione è Vera [V] o Falsa [F]. Se è Falsa, correggila brevemente sulle righe sottostanti.*

| Affermazione | V | F |
| :--- | :---: | :---: |
| 1. A Mosca Lev sottrae con la forza due filoni di pane a una passante per sfamare i compagni rimasti senza denaro. | [ ] | [ ] |
| 2. Giunti a Rybinsk, i comandanti del campo si scusano per l'errore di immatricolazione e rilasciano i ragazzi su un treno passeggeri. | [ ] | [ ] |
| 3. Nel Gulag le ragazze e i ragazzi della brigata alloggiano insieme nella medesima baracca per proteggersi reciprocamente. | [ ] | [ ] |
| 4. Mikhail consegna a Viktor un coltello a serramanico in cambio della promessa di ricevere calzature adatte alla marcia. | [ ] | [ ] |
| 5. Durante l'inseguimento notturno i cani da presa dell'NKVD raggiungono i fuggitivi nel bosco riconducendoli in catene nel recinto. | [ ] | [ ] |

**Correzione delle affermazioni false:**  
_________________________________________________________________________________________  
_________________________________________________________________________________________  
_________________________________________________________________________________________  

---

## 2. Analisi dei Personaggi e Riflessione

1. **La redenzione morale di Lev:**  
   A Mosca Lev scivola nella delinquenza comune per disperazione; nel lager di Rybinsk, tuttavia, la fatica condivisa e la protezione del piccolo Ilya lo trasformano in un pilastro della brigata. Come si compie il riscatto morale di questo personaggio?
   
_________________________________________________________________________________________  
_________________________________________________________________________________________  
_________________________________________________________________________________________  

2. **Il confine della violenza (La prova di Viktor):**  
   Nel Gulag Viktor è costretto a indurirsi: minaccia Mikhail, impone la disciplina con maniere brusche e pianifica la fuga. In che modo il ragazzo evita di trasformarsi in un aguzzino cinico, preservando il proprio nucleo etico?
   
_________________________________________________________________________________________  
_________________________________________________________________________________________  
_________________________________________________________________________________________  

---

## 3. Officina di Scrittura Creativa ed Empatia

*Mettiti nei panni di uno dei protagonisti.*

Immagina di essere **Klara** mentre strisci nel buio soffocante del tunnel sotto la baracca 5, con il fango gelido che ti intride i vestiti e il timore che le sentinelle scoprano la botola. Sei fuggita due volte: dalla Germania nazista che ha perseguitato la tua famiglia e ora da un lager sovietico che ti considera una spia. Scrivi una pagina di riflessione interiore: racconta la disperata voglia di rivedere il cielo aperto, la solidarietà fraterna che ti lega a Viktor e la fede ostinata nella meta di Leningrado.

_________________________________________________________________________________________  
_________________________________________________________________________________________  
_________________________________________________________________________________________  
_________________________________________________________________________________________  
_________________________________________________________________________________________  

---

## 4. Laboratorio Lessicale e Modi di Dire

*Associa ciascun vocabolo o espressione d'autore al suo significato nel contesto del racconto.*

| Termine o Modo di Dire | Abbinamento | Significato Contestuale |
| :--- | :---: | :--- |
| 1. **Gulag** | [   ] | A. Articolo del codice penale sovietico che puniva severamente le presunte attività controrivoluzionarie e politiche. |
| 2. **Quota di lavoro** | [   ] | B. Sistema amministrativo centrale dei campi di lavoro correttivo e rieducativo forzato nell'URSS. |
| 3. **Articolo 58** | [   ] | C. Quantitativo minimo giornaliero di produzione o scavo imposto ai forzati per aver diritto alla razione di pane. |
| 4. **Forzato** | [   ] | D. Individuo privato della libertà personale e condannato all'esecuzione coatta di lavori pesanti in condizioni estreme. |
| 5. **Complicità** | [   ] | E. Partecipazione attiva e concorde insieme ad altri individui al compimento di un'azione clandestina o proibita. |

---

## 5. Attività Speciale "Fuori dagli Schemi"

**Processo in Aula / Dibattito (Debate): L'Evasione dal Gulag e lo Stato di Necessità**  
Nel fascicolo di indagine Smirnov accusa Viktor e i suoi complici di evasione aggravata (art. 188), cospirazione con prigionieri politici e porto di armi improprie (il coltello da caccia).  
Simulate un **Processo Penale Straordinario**:
1. *La Pubblica Accusa dell'NKVD:* Dimostra che la fuga da un insediamento produttivo di Stato in tempo di guerra indebolisce la Patria e costituisce insubordinazione intollerabile.
2. *Il Collegio di Difesa:* Sostiene che i ragazzi sono stati deportati senza regolare processo per mera disfunzione burocratica e che l'evasione era l'unico mezzo per sfuggire alla morte per denutrizione e sfinimento (*stato di necessità*).
3. *La Corte:* Pronuncia il giudizio finale motivato e sigilla la delibera con il timbro di rito.

[SPAZIO PER IL TUO DISEGNO / RILIEVO GRAFICO]

---

### GUIDA E RIASSUNTO PER IL DOCENTE

#### Riassunto sintetico dei capitoli
- **Capitolo 24 (settembre 1941 - Viktor):** A Mosca Lev sottrae pane a una passante dopo essere stato derubato dei soldi; Viktor lo affronta a pugni per ribadire la dignità del gruppo. Con i sette compagni rimasti (Klara, Lev, Flavio, Mikhail, Marya, Ilya) sale su un convoglio merci sperando di raggiungere il fronte settentrionale.
- **Capitolo 25:** Un bibliotecario svela che il convoglio è diretto al famigerato Gulag della centrale idroelettrica GES di Rybinsk. All'arrivo le guardie percuotono Viktor e immatricolano tutti come forzati. Nelle baracche regna la legge dei criminali comuni; i ragazzi formano una squadra per spingere le carriole di ghiaia e raggiungere le quote alimentari. Viktor ottiene la cooperazione di Mikhail, che promette indicazioni preziose sul treno 76 in cambio di protezione.
- **Capitolo 26:** Klara sottrae generi alimentari dalle cucine; Lev e Flavio prendono contatto con i detenuti politici ("Articolo 58") che stanno ultimando un cunicolo sotterraneo sotto la baracca 5. Mikhail cede a Viktor un coltello a serramanico.
- **Capitolo 27:** Durante la notte scatta l'evasione attraverso la botola; i gestori del tunnel derubano i ragazzi delle ultime provviste e scarpe, ma Viktor salva i quaderni rossi. All'esterno risuona la sirena d'allarme; braccati dai cani da presa, i ragazzi riparano nella fossa biologica del capanno delle latrine: l'odore acre confonde i segugi dell'NKVD. Le autorità archiviano i loro nomi fittizi come deceduti, consentendo ai sette compagni di intraprendere a piedi la marcia verso Leningrado.

#### Soluzioni ed elementi chiave di correzione
- **1.A Domande aperte:**
  1. *La disperazione a Mosca:* Lev compie un atto disperato per sfamare i compagni affamati; Viktor lo percuote perché non vuole che la miseria cancelli i principi morali e li assimili a criminali comuni.
  2. *L'inganno del treno:* Il convoglio è un treno deportati per i lavori forzati alla centrale idroelettrica di Rybinsk; alle proteste di Viktor la guardia risponde con un colpo di calcio del fucile, ribadendo l'arbitrio totale del lager.
  3. *La legge delle carriole:* Spartiscono a rotazione i turni di spinta per colmare i deficit dei compagni più deboli; Mikhail baratta le sue notizie sul treno 76 in cambio della tutela fisica da parte della brigata.
  4. *Il budello sotto la baracca 5:* Gli Articolo 58 esigono compensi in cibo e vestiti; Viktor subisce la perquisizione e la perdita delle calzature di ricambio ma riesce a custodire con le unghie i diari.
  5. *L'astuzia delle latrine:* Si immergono nel lezzo della fossa biologica all'aperto; le esalazioni violente saturano i recettori olfattivi dei cani da presa costringendo le pattuglie a deviare.
- **1.B Vero o Falso:**
  1. **VERO.** Lo scippo del pane è un gesto disperato nato dalla fame assoluta dopo il furto del denaro.
  2. **FALSO.** Vengono internati con la forza nel campo di lavoro forzato di Rybinsk.
  3. **FALSO.** I settori maschili e femminili del lager sono tassativamente separati dal filo spinato.
  4. **VERO.** Il baratto del coltello consolida l'alleanza per l'evasione.
  5. **FALSO.** I fuggitivi eludono la cattura proprio grazie allo stratagemma delle latrine.
- **2. Analisi dei Personaggi:**
  1. *Redenzione di Lev:* Il senso di colpa per il furto a Mosca si trasforma in dedizione comunitaria nel lager; la forza bruta di Lev diventa protezione generosa per il piccolo Ilya e per Klara.
  2. *Il comando di Viktor:* Impiega l'intimidazione solo per prevenire la disgregazione della brigata; il suo rigore è finalizzato alla salvaguardia comune e non alla prevaricazione individuale.
- **3. Officina di Scrittura:** Verificare la resa dell'angoscia claustrofobica del cunicolo, la complessità dell'identità di Klara e il contrasto tra il gelo della terra e l'anelito alla libertà.
- **4. Laboratorio Lessicale:** Combinazione corretta: `1-B, 2-C, 3-A, 4-D, 5-E`.
- **5. Attività Speciale:** Valutare la padronanza nell'applicazione del principio dello stato di necessità (art. 54 c.p.) a fronte della violenza arbitraria della burocrazia concentrazionaria.
