# SCHEDA DIDATTICA DI LETTURA E COMPRENSIONE
## *La sfolgorante luce di due stelle rosse* di Davide Morosinotto
### Unità Didattica 1 (Blocco 1): *Prologo* – *Capitolo 3*

---

**Nome e Cognome dello studente:** ________________________________________  
**Classe:** ____________________  **Data:** ____________________  

---

> ### 🌊 Quando la Storia bussa alla porta
> «Non c'è niente di più importante della cultura. Gli uomini possono morire, ma l'arte vive per sempre. I giovani del futuro ci ringrazieranno per quello che noi faremo oggi.»  
> Benvenuti a Leningrado, nell'estate del 1941. In queste prime pagine farete la conoscenza di due gemelli dodicenni, Nadya e Viktor, e scoprirete come una domenica di festa possa trasformarsi, con un semplice annuncio alla radio, nell'inizio di una grande avventura per la sopravvivenza.

---

## 1. Comprensione del Testo

### A. Domande a risposta aperta
*Rispondi sul tuo quaderno in modo chiaro e completo, facendo riferimento a ciò che hai letto nel testo.*

1. **Uno strano lettore nell'ombra:**  
   Prima ancora che inizi il diario di Nadya, scopriamo che nel dicembre 1946 i quaderni dei due fratelli sono finiti sulla scrivania del colonnello Smirnov. Chi è quest'uomo, quale incarico gli è stato affidato e perché la sua presenza ci fa capire fin dall'inizio che la storia dei gemelli sarà piena di pericoli?

2. **Due reazioni opposte alla guerra:**  
   Nel Capitolo 2, dopo l'annuncio alla radio dell'attacco tedesco, Viktor e Nadya reagiscono in modo completamente diverso. Come reagisce ciascuno di loro e da cosa nasce questa differenza?

3. **Salvare i quadri o combattere?:**  
   Quando il direttore dell'Ermitage, il dottor Orbeli, spiega che bisogna imballare e mettere al sicuro i quadri del museo, Viktor protesta dicendo che in guerra ci sono cose più importanti dell'arte. Come gli risponde il direttore?

4. **La verità nascosta:**  
   Nel Capitolo 3 la radio ufficiale parla di grandi vittorie, ma camminando per Leningrado Nadya nota molti particolari allarmanti. Quali comportamenti delle persone e quali scene le fanno capire che il pericolo è ormai vicinissimo?

5. **La paura del quaderno:**  
   Quando la mamma accompagna i gemelli ai *baraki* operai dallo "zio" Dmitry, nonna Olga si arrabbia tantissimo vedendo che Nadya scrive su un quaderno. Perché l'anziana donna è terrorizzata dall'idea che compaiano nomi di persone su quelle pagine?

---

### B. Vero o Falso? (Attenzione ai dettagli)
*Indica se ciascuna affermazione è Vera (V) o Falsa (F). Correggi le affermazioni false sul tuo quaderno.*

| Affermazione | V | F |
| :--- | :---: | :---: |
| 1. Il papà regala il quaderno ai gemelli dicendo che la spirale a sinistra è comoda per chi scrive con la mano sinistra come Nadya. | | |
| 2. A mezzogiorno del 22 giugno l'impiegato Vladimir si stupisce che alla radio parli Molotov anziché Stalin, intuendo che la situazione è grave. | | |
| 3. Durante le esercitazioni dei Giovani Pionieri, i ragazzi devono portare secchi d'acqua nei sottotetti per spegnere eventuali incendi causati dalle bombe. | | |
| 4. I soldati della Milizia visti da Nadya sfilano sui camion con divise nuove fiammanti e armi moderne. | | |
| 5. Nei *baraki* degli operai ogni famiglia ha una stanza tutta per sé, chiusa da una porta solida che assicura la massima riservatezza. | | |

---

## 2. Analisi dei Personaggi e Riflessione
*Rispondi alle seguenti domande sul tuo quaderno, riflettendo bene sui comportamenti dei protagonisti.*

1. **Viktor e Nadya, due gemelli diversi:**  
   Pur essendo gemelli e molto legati, Viktor e Nadya hanno caratteri e passioni differenti (lo si nota persino dagli strumenti che usano: penna stilografica blu per Nadya, matita rossa per Viktor). Descrivi le differenze tra i due fratelli e spiega in che modo si completano e si aiutano a vicenda.

2. **La preoccupazione dei genitori:**  
   Osserva il comportamento del papà e della mamma tra il 22 e il 24 giugno. Quali sentimenti provano i genitori, divisi tra il dovere di proteggere le opere del museo e il desiderio di mettere al sicuro i propri figli?

---

## 3. Officina di Scrittura Creativa ed Empatia
*Svolgi la seguente attività di scrittura sul tuo quaderno.*

Immagina di essere **il papà o la mamma di Viktor e Nadya** nella notte tra il 22 e il 23 giugno 1941. Ti trovi nelle grandi sale dell'Ermitage a imballare i dipinti per salvarli dalle bombe, mentre i tuoi figli sono rimasti a casa da soli. Scrivi sul tuo quaderno una pagina di diario in prima persona: racconta la stanchezza, la paura per quello che accadrà alla città e la promessa che vorresti fare ai tuoi ragazzi.

---

## 4. Laboratorio Lessicale e Modi di Dire
*Associa ciascun vocabolo o espressione d'autore al suo significato nel contesto del racconto (indica sul quaderno la combinazione corretta numero-lettera).*

| Termine o Modo di Dire | Abbinamento | Significato Contestuale |
| :--- | :---: | :--- |
| 1. **Fare bisboccia** | | A. Tagliandi speciali distribuiti dallo Stato ai cittadini per ricevere la giusta porzione di cibo in tempo di guerra. |
| 2. **Perfidia** | | B. Grandi capannoni in legno dove alloggiano insieme molti operai e famiglie, senza veri muri di divisione. |
| 3. **Tessere del razionamento** | | C. Allontanamento obbligato dalla propria città o terra natale, spesso per punizione politica. |
| 4. **Esilio** | | D. Festeggiare allegramente mangiando, bevendo in compagnia e facendo tardi la notte. |
| 5. **Baraki** | | E. Malvagità e slealtà di chi tradisce un patto colpendo l'altro a tradimento e senza preavviso. |

---

## 5. Attività Speciale "Fuori dagli Schemi"

**Mappa a confronto: Dalle sale dorate dell'Ermitage alla vita nei Baraki**  
Nel Blocco 1 i protagonisti si muovono tra due ambienti completamente opposti di Leningrado: il grandioso **Palazzo d'Inverno (Museo dell'Ermitage)** e i disadorni **Baraki operai** vicino alla fabbrica.  
Sul tuo quaderno, realizza un disegno schematico dei due luoghi a confronto:
- A sinistra disegna la pianta o la vista del percorso dei ragazzi all'Ermitage (la piazza, i saloni con le cornici vuote, lo studio del direttore);
- A destra disegna la sistemazione dentro il *barak* (l'ingresso unico, il corridoio, le tovaglie usate come pareti per dividere i letti e l'orto all'esterno).  
Aggiungi una **legenda con almeno 3 simboli** per indicare dove avvengono i momenti più importanti.

---

### GUIDA E RIASSUNTO PER IL DOCENTE

#### Riassunto sintetico dei capitoli
Il romanzo si apre con un prologo in medias res (il tredicesimo compleanno di Viktor sulla Neva ghiacciata) e con il fascicolo del colonnello dell'NKVD Valery Smirnov (dicembre 1946), incaricato di esaminare i quaderni sequestrati ai gemelli Danilov per stabilire se siano "Innocenti" o "Colpevoli".
- **Capitolo 1 (22 giugno 1941):** È la domenica successiva alla festa del solstizio. Nadya racconta la vita nella *kommunalka* in vicolo Stolyarny e la passeggiata fino all'Ermitage, dove i genitori lavorano con il direttore Iosif Orbeli. Il padre regala ai figli un quaderno ad anelli con la scusa della spirale per mancini: Nadya scrive in blu, Viktor in rosso.
- **Capitolo 2 (22 giugno 1941):** A mezzogiorno il discorso radiofonico di Molotov annuncia l'invasione nazista. Viktor esulta con fervore patriottico, mentre Nadya piange di terrore. Orbeli avvia l'evacuazione dei capolavori, ribadendo che l'arte è eterna mentre gli uomini passano. I ragazzi tornano soli in una città in preda al panico.
- **Capitolo 3 (24 giugno 1941):** Mentre la propaganda proclama false vittorie, i Giovani Pionieri portano secchi d'acqua nei sottotetti antincendio. La madre accompagna i figli ai *baraki* operai dallo "zio" Dmitry. Durante il tragitto incrociano camion di soldati disarmati. Al *barak*, nonna Olga sorprende Nadya a scrivere e si infuria temendo perquisizioni della polizia segreta.

#### Soluzioni ed elementi chiave di correzione
- **1.A Domande aperte:**
  1. *Uno strano lettore nell'ombra:* Smirnov è un ufficiale della polizia politica sovietica (NKVD). Nel 1946 deve giudicare i quaderni come prove legali; la sua presenza fa capire che ogni annotazione dei ragazzi è stata esaminata come possibile reato.
  2. *Due reazioni opposte alla guerra:* Viktor è cresciuto con i racconti eroici dei Pionieri e immagina la gloria; Nadya pensa subito ai pericoli concreti e ha paura per la famiglia.
  3. *Salvare i quadri o combattere?:* Orbeli spiega che l'arte rappresenta la memoria e l'identità di un popolo: salvare i quadri significa custodire la civiltà per le future generazioni.
  4. *La verità nascosta:* Code notturne per il cibo alle quattro del mattino, addestramento sui tetti e soldati mandati al fronte senza armi né divise adeguate.
  5. *La paura del quaderno:* Nel regime staliniano c'era la paura continua di essere spiati o denunciati; annotare nomi e pensieri poteva mettere in pericolo tutta la famiglia.
- **1.B Vero o Falso:**
  1. **VERO.** È Nadya a essere mancina; la scusa della spirale serve al papà per donare il quaderno.
  2. **VERO.** Il discorso di Molotov al posto di Stalin insospettisce subito i cittadini.
  3. **VERO.** I ragazzi portano secchi d'acqua nei sottotetti per spegnere eventuali bombe incendiarie.
  4. **FALSO.** I soldati della Milizia partono su camion scoperti, senza divise e privi di armi moderne.
  5. **FALSO.** I *baraki* sono grandi spazi comuni dove la privacy non esiste, divisi solo da stoffe appese.
- **2. Analisi dei Personaggi:**
  1. *Viktor e Nadya:* Nadya è riflessiva e attenta ai sentimenti; Viktor è pratico, impulsivo e fiducioso. Insieme formano una squadra equilibrata in cui ciascuno compensa i limiti dell'altro.
  2. *I genitori Danilov:* Vivono un momento doloroso: sentono il dovere di tutelare il patrimonio artistico dell'Ermitage, ma sono angosciati per l'incolumità dei figli.
- **3. Officina di Scrittura:** Verificare la capacità di immedesimazione nella voce di un genitore, l'espressione delle preoccupazioni e il senso di protezione per i figli.
- **4. Laboratorio Lessicale:** Combinazione corretta: `1-D, 2-E, 3-A, 4-C, 5-B`.
- **5. Attività Speciale:** Valutare la comprensione del contrasto tra i due ambienti e l'uso chiaro dei simboli nella mappa.
