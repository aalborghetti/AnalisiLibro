# SCHEDA DIDATTICA DI LETTURA E COMPRENSIONE
## *La sfolgorante luce di due stelle rosse* di Davide Morosinotto
### Unità Didattica 1 (Blocco 1): *Prologo* – *Capitolo 3*

---

**Nome e Cognome dello studente:** ________________________________________  
**Classe:** ____________________  **Data:** ____________________  

---

> ### 🌊 Quando la Storia bussa alla porta
> «Non c'è niente di più importante della cultura. Gli uomini possono morire, ma l'arte vive per sempre. I giovani del futuro ci ringrazieranno per quello che noi faremo oggi.»  
> Benvenuti a Leningrado, nell'estate del 1941. In queste prime pagine farete la conoscenza di due gemelli dodicenni, Nadya e Viktor, e scoprirete come una luminosa domenica di festa possa trasformarsi, nel giro di pochi minuti alla radio, nell'inizio di un'incredibile avventura per la sopravvivenza.

---

## 1. Comprensione del Testo

### A. Domande a risposta aperta
*Rispondi sul tuo quaderno in modo completo, motivando le tue risposte con riferimenti precisi al testo.*

1. **Uno strano lettore nell'ombra:**  
   Prima ancora che inizi il diario di Nadya, scopriamo che i quaderni sono finiti sulla scrivania del colonnello Smirnov nel dicembre 1946. Chi è quest'uomo, quale incarico gli è stato affidato dall'NKVD e in che modo la sua presenza cambia il nostro modo di leggere i diari dei due gemelli?

2. **Due sguardi opposti sulla guerra:**  
   Nel Capitolo 2, dopo l'annuncio radiofonico di Molotov sull'attacco tedesco, Viktor e Nadya reagiscono in maniera opposta. Quali sentimenti prova ciascuno dei due gemelli e da cosa derivano queste reazioni così distanti?

3. **Salvare i quadri o combattere?:**  
   Quando il direttore dell'Ermitage, il dottor Orbeli, illustra il piano di evacuazione delle opere d'arte, Viktor protesta dicendo che in un momento così tragico ci sono cose più importanti dei dipinti. Qual è la risposta di Orbeli e perché il suo punto di vista è fondamentale per comprendere il valore della cultura?

4. **Radio ufficiale contro realtà di strada:**  
   Nel Capitolo 3 la radio di Stato proclama false vittorie sul confine, ma Nadya nota molti indizi per le vie di Leningrado che rivelano una verità ben diversa. Quali comportamenti degli adulti e quali scene osservate in città fanno capire alla ragazza che il pericolo è imminente?

5. **La paura di nonna Olga nei baraki:**  
   Quando i gemelli vengono accompagnati ai *baraki* operai dallo "zio" Dmitry, nonna Olga va su tutte le furie scoprendo che Nadya annota pensieri e nomi su un quaderno. Perché l'anziana donna è terrorizzata all'idea che compaiano nomi propri su quelle pagine?

---

### B. Vero o Falso? (Attenzione ai dettagli)
*Indica se ciascuna affermazione è Vera (V) o Falsa (F). Correggi le affermazioni false sul tuo quaderno.*

| Affermazione | V | F |
| :--- | :---: | :---: |
| 1. Il papà regala il quaderno con la spirale ai gemelli perché, essendo mancino come Viktor, trova scomodo scrivere con il metallo sulla sinistra. | | |
| 2. A mezzogiorno del 22 giugno l'impiegato Vladimir Garanin si stupisce che a parlare alla radio sia Molotov anziché Stalin, intuendo che la situazione è grave. | | |
| 3. Durante l'esercitazione dei Giovani Pionieri, i ragazzi devono portare secchi di sabbia nelle cantine dei palazzi per costruire rifugi antiaerei. | | |
| 4. I soldati che Nadya vede partire sui camion verso la periferia hanno il volto cupo e non indossano divise militari né imbracciano fucili. | | |
| 5. Nei *baraki* degli operai ogni famiglia dispone di un alloggio privato ben isolato da spessi muri in mattoni che garantiscono la massima riservatezza. | | |

---

## 2. Analisi dei Personaggi e Riflessione
*Rispondi alle seguenti domande sul tuo quaderno, analizzando a fondo i personaggi e motivando le tue considerazioni.*

1. **Gemelli allo specchio (Viktor e Nadya):**  
   Pur essendo quasi identici nell'aspetto, Viktor e Nadya mostrano caratteri, passioni e persino strumenti di scrittura opposti (stilografica blu per Nadya, lapis rosso per Viktor). Analizza le loro differenze: come si completano a vicenda e in che modo l'educazione sovietica influenza l'atteggiamento di Viktor rispetto alla sensibilità critica di Nadya?

2. **Il peso invisibile degli adulti (I genitori Danilov):**  
   Osserva il comportamento del padre e della madre tra il 22 e il 24 giugno. Quale lacerante conflitto interiore vivono tra il loro dovere professionale verso il museo e l'istinto di genitori che vorrebbero proteggere i propri figli?

---

## 3. Officina di Scrittura Creativa ed Empatia
*Svolgi la seguente attività di scrittura sul tuo quaderno.*

Immagina di essere **il papà o la mamma di Viktor e Nadya** nella notte tra il 22 e il 23 giugno 1941. Sei chiuso nelle sale immense dell'Ermitage per avviare l'imballaggio dei dipinti, mentre i tuoi figli sono rimasti a casa da soli per la prima volta dopo l'annuncio della guerra. Scrivi sul tuo quaderno una pagina di diario o una lettera in prima persona in cui esprimi la tua stanchezza, il timore per il destino della città e la dolorosa domanda di Nadya (*«E a noi chi ci mette al sicuro?»*) che continua a risuonarti nella mente.

---

## 4. Laboratorio Lessicale e Modi di Dire
*Associa ciascun vocabolo o espressione d'autore al suo significato nel contesto del racconto (indica sul quaderno la combinazione corretta numero-lettera).*

| Termine o Modo di Dire | Abbinamento | Significato Contestuale |
| :--- | :---: | :--- |
| 1. **Fare bisboccia** | [   ] | A. Tessere annonarie distribuite dallo Stato ai cittadini in tempo di guerra per razionare l'acquisto di generi alimentari. |
| 2. **Perfidia** | [   ] | B. Grandi capannoni in legno destinati agli operai, privi di veri muri divisori interni tra i diversi nuclei familiari. |
| 3. **Tessere del razionamento** | [   ] | C. Allontanamento coatto e forzato dalla propria terra per motivi politici, spesso attuato su vagoni ferroviari piombati. |
| 4. **Esilio (e finestrini piombati)** | [   ] | D. Festeggiare mangiando, bevendo in allegria e facendo tardi la notte (come gli abitanti la notte del solstizio d'estate). |
| 5. **Baraki** | [   ] | E. Slealtà crudele e tradimento spietato di chi viola un patto di non aggressione colpendo alle spalle senza preavviso. |

---

## 5. Attività Speciale "Fuori dagli Schemi"

**Mappa Topografica o Tattica: Dalle sale dorate dell'Ermitage alla promiscuità dei Baraki**  
Nel Blocco 1 i protagonisti si muovono tra due ambienti architettonici e sociali antitetici di Leningrado: il monumentale **Palazzo d'Inverno (Museo dell'Ermitage)** affacciato sulla Neva e il disadorno **Barak operaio** presso la Fabbrica di Pallottole.  
Sul tuo quaderno, realizza una doppia mappa a confronto: a sinistra disegna una mappa schematica del percorso di Nadya e Viktor all'interno del Museo (la piazza, i saloni con le cornici vuote, lo studio di Orbeli); a destra ricostruisci la pianta del *barak* (l'ingresso unico, il corridoio centrale, le tovaglie usate come tramezzi, i bagni comuni e l'orto esterno dove si rifugia Nadya). Aggiungi una **legenda con almeno 4 simboli** che indichi i momenti salienti dell'azione.

---

### GUIDA E RIASSUNTO PER IL DOCENTE

#### Riassunto sintetico dei capitoli
Il romanzo si apre con un prologo in medias res (il tredicesimo compleanno di Viktor sulla Neva ghiacciata) e con il fascicolo del colonnello dell'NKVD Valery Smirnov (dicembre 1946), incaricato di esaminare i quaderni sequestrati ai gemelli Danilov per stabilire se siano "Innocenti" o "Colpevoli".
- **Capitolo 1 (22 giugno 1941):** È la domenica successiva alla festa del solstizio. Nadya racconta la vita nella *kommunalka* in vicolo Stolyarny e la passeggiata fino all'Ermitage, dove i genitori lavorano con il direttore Iosif Orbeli. Il padre regala ai figli un quaderno ad anelli con la scusa della spirale per mancini: Nadya scrive in blu, Viktor in rosso.
- **Capitolo 2 (22 giugno 1941):** A mezzogiorno il discorso radiofonico di Molotov annuncia l'invasione nazista. Viktor esulta con fervore patriottico, mentre Nadya piange di terrore. Orbeli avvia l'evacuazione dei capolavori, ribadendo che l'arte è eterna mentre gli uomini passano. I ragazzi tornano soli in una città in preda al panico.
- **Capitolo 3 (24 giugno 1941):** Mentre la propaganda proclama false vittorie, i Giovani Pionieri portano secchi d'acqua nei sottotetti antincendio. La madre accompagna i figli ai *baraki* operai dallo "zio" Dmitry. Durante il tragitto incrociano camion di soldati disarmati. Al *barak*, nonna Olga sorprende Nadya a scrivere e si infuria temendo perquisizioni della polizia segreta.

#### Soluzioni ed elementi chiave di correzione
- **1.A Domande aperte:**
  1. *Uno strano lettore nell'ombra:* Smirnov è un ufficiale della polizia politica sovietica (NKVD). Nel 1946 deve giudicare i quaderni come prove legali; la sua presenza fa capire che ogni annotazione intima dei ragazzi è stata passata al vaglio del regime come possibile reato.
  2. *Due sguardi opposti sulla guerra:* Viktor è indottrinato dalla propaganda pionieristica e sogna la gloria bellica; Nadya guarda la cartina, comprende la vicinanza del confine e teme per la sopravvivenza della famiglia.
  3. *Salvare i quadri o combattere?:* Orbeli spiega che un popolo difende non solo i confini fisici ma la propria identità culturale e la memoria artistica per le generazioni future.
  4. *Radio ufficiale contro realtà di strada:* Code notturne per il cibo fin dalle quattro del mattino, addestramento antincendio sui tetti e soldati inviati al fronte senza divise né fucili.
  5. *La paura di nonna Olga nei baraki:* Nel regime staliniano le delazioni sono continue; annotare nomi e luoghi su un quaderno espone l'intera comunità al rischio di arresto e deportazione.
- **1.B Vero o Falso:**
  1. **FALSO.** È Nadya a essere mancina come il padre; la scusa serve al genitore per donare il quaderno senza contrariare la moglie.
  2. **VERO.** Molotov parla al posto di Stalin, suscitando perplessità tra i cittadini.
  3. **FALSO.** I ragazzi portano secchi d'acqua nei sottotetti per spegnere bombe incendiarie, non sabbia nelle cantine.
  4. **VERO.** I soldati della Milizia partono su camion aperti privi di equipaggiamento regolare.
  5. **FALSO.** I *baraki* sono stanzoni collettivi privi di muri, divisi solo da stoffe e tovaglie appese.
- **2. Analisi dei Personaggi:**
  1. *Gemelli allo specchio:* Nadya (inchiostro blu) è introspettiva, amante dell'arte e lucida; Viktor (lapis rosso) è pragmatico, impulsivo e fiducioso nello Stato. Le due voci si bilanciano a vicenda.
  2. *Il peso invisibile degli adulti:* I genitori Danilov sono lacerati tra l'amore paterno e il senso di responsabilità storica per la custodia del museo; il silenzio della madre rivela la sofferenza per l'imminente distacco.
- **3. Officina di Scrittura:** Valutare la capacità di calarsi nel punto di vista genitoriale, la resa della fatica fisica all'Ermitage e l'eco emotiva delle parole di Nadya.
- **4. Laboratorio Lessicale:** Combinazione corretta: `1-D, 2-E, 3-A, 4-C, 5-B`.
- **5. Attività Speciale:** Verificare la precisione nei dettagli architettonici (Ermitage monumentale vs barak sovraffollato) e la coerenza della legenda simbolica.
