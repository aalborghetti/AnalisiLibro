# SCHEDA DIDATTICA DI LETTURA E COMPRENSIONE
## *La sfolgorante luce di due stelle rosse* di Davide Morosinotto
### Unità Didattica 2 (Blocco 2): *Capitolo 4* – *Capitolo 7*

> ### 🌊 Sui tetti della città e l'ombra della partenza
> «Rispetto a tutti gli altri voi due siete fortunati. Perché siete gemelli, vi volete bene e potrete restare sempre insieme. Questo renderà tutto più facile.»  
> Nelle notti luminose di Leningrado, tra un turno di guardia sui tetti e il suono delle sirene antiaeree, l'infanzia di Viktor e Nadya sta per cambiare per sempre. Ma quando il pericolo si avvicina, qual è il confine tra una bugia detta per proteggere e una dura verità da affrontare?

---

## 1. Comprensione del Testo

### A. Domande a risposta aperta
*Rispondi sul tuo quaderno in modo chiaro e completo, facendo riferimento a ciò che hai letto nel testo.*

1. **Una parola di troppo:**  
   Nel Capitolo 4 Nadya ricorda l'arresto improvviso di un giovane studente universitario che abitava nel loro palazzo. Qual era stata la colpa del ragazzo e cosa ci fa capire questo episodio sulla paura che si respirava in città?

2. **I dubbi di Boris sul tetto:**  
   Durante il turno di guardia antincendio sul tetto del palazzo, Boris non crede affatto alle notizie trionfali della radio. Quali fatti racconta ai compagni e perché Viktor all'inizio lo accusa di non essere un buon patriota?

3. **Una colazione speciale e dolorosa:**  
   Nel Capitolo 6 i gemelli tornano a casa e trovano una tavola imbandita con piatti insolitamente ricchi preparati dalla mamma. Perché Nadya intuisce che c'è una brutta notizia in arrivo e cosa devono comunicare i genitori?

4. **Le parole del papà nella notte:**  
   All'inizio i genitori dicono ai gemelli che la partenza con il treno sarà solo una breve vacanza estiva; a mezzanotte, però, il papà parla a Viktor in modo molto diverso. Perché gli svela la verità e cosa gli fa promettere regalandogli i cinque nuovi quaderni?

5. **Il sacrificio della mamma:**  
   Nel Capitolo 7, sotto la pioggia battente in un parco periferico, la mamma incontra una persona per fare uno scambio al mercato nero. Cosa cede la donna e perché compie questo gesto rischioso e proibito dalla legge?

---

### B. Vero o Falso? (Attenzione ai dettagli)
*Indica se ciascuna affermazione è Vera (V) o Falsa (F). Correggi le affermazioni false sul tuo quaderno.*

| Affermazione | V | F |
| :--- | :---: | :---: |
| 1. Per il turno di vedetta sui tetti, ai ragazzi vengono consegnati potenti cannocchiali militari professionali. | | |
| 2. Mentre scende per le scale, Viktor ha un forte presentimento e torna subito sul tetto, giusto in tempo per avvistare gli aerei nemici insieme a Nadya. | | |
| 3. Con la legge marziale, tutti i cittadini dai sedici anni in su possono essere chiamati a scavare trincee per la difesa della città. | | |
| 4. Nelle valigie dei figli, la mamma inserisce maglioni di lana pesanti e pezze per i piedi prevedendo che resteranno via a lungo anche in inverno. | | |
| 5. I gemelli partono sereni perché sanno che sul loro stesso treno saliranno anche gli amici Darya, Stepan e il signor Yashkin. | | |

---

## 2. Analisi dei Personaggi e Riflessione
*Rispondi alle seguenti domande sul tuo quaderno, riflettendo bene sui comportamenti dei protagonisti.*

1. **Boris, un compagno da scoprire:**  
   A scuola Boris è considerato lento, silenzioso e poco brillante. Sul tetto, però, dimostra grande senso pratico, coraggio e un forte affetto per la sua famiglia. Come cambia l'opinione che Viktor e il lettore hanno di lui?

2. **La tempesta nel cuore di Nadya:**  
   Nel Capitolo 7 Nadya si arrabbia con la mamma e accartoccia il biglietto di saluto che aveva preparato. Perché si sente tradita? E cosa le fa cambiare idea durante la notte?

---

## 3. Officina di Scrittura Creativa ed Empatia
*Svolgi la seguente attività di scrittura sul tuo quaderno.*

Nel Capitolo 7 la mamma chiede ai figli di scriverle una lettera d'addio da portare con sé durante la lontananza. Nel romanzo leggiamo il biglietto dolce di Nadya, ma non compare la lettera di **Viktor**, rimasto a lungo silenzioso sull'atlante per non farsi vedere commosso. Scrivi sul tuo quaderno il messaggio segreto di Viktor per i genitori prima di salire sul treno: esprimi il tuo orgoglio, la tristezza per il distacco e la promessa solenne di proteggere sempre tua sorella Nadya.

---

## 4. Laboratorio Lessicale e Modi di Dire
*Associa ciascun vocabolo o espressione d'autore al suo significato nel contesto del racconto (indica sul quaderno la combinazione corretta numero-lettera).*

| Termine o Modo di Dire | Abbinamento | Significato Contestuale |
| :--- | :---: | :--- |
| 1. **Blitzkrieg** | | A. Strisce di stoffa pesante usate al posto dei calzini per fasciare i piedi negli stivali contro il freddo. |
| 2. **Legge marziale** | | B. Gruppi di cittadini che si offrono volontari per aiutare l'esercito regolare a difendere la città. |
| 3. **Milizia Popolare** | | C. Tattica di "guerra lampo" rapida e a sorpresa condotta con aerei e carri armati. |
| 4. **Pezze da piedi** | | D. Fronte solcata da pieghe, tipica di chi è concentrato o molto preoccupato per qualcosa. |
| 5. **Fronte corrugata** | | E. Insieme di regole d'emergenza in tempo di guerra, come il coprifuoco notturno e controlli severi. |

---

## 5. Attività Speciale "Fuori dagli Schemi"

**Il Dibattito in classe: Le accuse contro la famiglia Danilov**  
Nelle sue note del 1946, il colonnello Smirnov elenca tre presunte "colpe" commesse dai Danilov:
1. Aver trattenuto per sé un quaderno ad anelli del museo;
2. Aver giocato con l'elastico sul tetto durante il turno di guardia;
3. Aver venduto un gioiello al mercato nero per comprare cibo.

Mettiti nei panni della Difesa della famiglia Danilov e scrivi sul tuo quaderno un breve discorso per spiegare perché queste azioni non erano reati egoisti, ma gesti dettati dal bisogno di proteggere i propri cari e aiutare la città in un momento drammatico.

---

### GUIDA E RIASSUNTO PER IL DOCENTE

#### Riassunto sintetico dei capitoli
- **Capitolo 4 (26 giugno 1941):** Nadya rammenta l'arresto notturno di uno studente e promette di proteggere il diario. Viktor descrive il primo turno di vedetta antincendio sul tetto con Yashkin, Nadya, Darya, Stepan e Boris. Con binocoli teatrali di fortuna, Boris svela la verità sull'impreparazione sovietica; Viktor si allontana per non litigare, ma un presentimento lo richiama in cima giusto in tempo per avvistare aerei nemici.
- **Capitolo 5 (27–28 giugno 1941):** La legge marziale mobilita i cittadini sopra i sedici anni per scavare trincee. La rumorosa *kommunalka* piomba in un silenzio spettrale.
- **Capitolo 6 (30 giugno – 1° luglio 1941):** I genitori offrono ai gemelli un ricco banchetto mattutino: il padre è arruolato nella Milizia, la madre resta all'Ermitage e i figli partiranno sui treni verso gli Urali. A mezzanotte il padre confessa la gravità della situazione, regala cinque quaderni rossi e fa promettere a Viktor di difendere Nadya.
- **Capitolo 7 (2 luglio 1941) e Rapporto NKVD:** La madre baratta gli ori di famiglia al mercato nero per ottenere viveri da viaggio. Nadya accoglie con sdegno la notizia che gli amici non partiranno con loro; di notte, però, scopre la sofferenza della madre e le lascia una tenera lettera. Smirnov chiude il Primo Quaderno contestando furto, negligenza e mercato nero.

#### Soluzioni ed elementi chiave di correzione
- **1.A Domande aperte:**
  1. *Una parola di troppo:* Lo studente fu arrestato per aver fatto commenti critici; l'episodio illustra il clima di sospetto e delazione alimentato dalla polizia segreta.
  2. *I dubbi di Boris sul tetto:* Boris spiega che i tedeschi avanzano velocissimi con i carri armati e che i soldati sovietici sono disorganizzati; Viktor si ribella perché ha fiducia cieca nella propaganda ufficiale.
  3. *Una colazione speciale:* Il cibo abbondante in tempo di razionamento fa presagire un addio: il papà andrà a combattere e i gemelli saranno evacuati lontano.
  4. *Le parole del papà nella notte:* Il padre capisce che Viktor deve essere consapevole del pericolo per fare da guida alla sorella e gli affida i quaderni come compito morale.
  5. *Il sacrificio della mamma:* Vende la collana nuziale per comprare provviste di viaggio per i figli; anche se proibito, lo fa per disperato amore materno.
- **1.B Vero o Falso:**
  1. **FALSO.** Ai ragazzi vengono dati solo binocoli da teatro in madreperla rimediati in casa.
  2. **VERO.** Viktor avverte un'improvvisa ansia e risale sul tetto prima dell'arrivo degli aerei.
  3. **VERO.** L'obbligo di scavare trincee riguarda tutti i cittadini dai sedici anni in su.
  4. **VERO.** La madre aggiunge indumenti pesanti e pezze di lana presagendo un inverno rigido.
  5. **FALSO.** I ragazzi scoprono con amarezza che gli amici d'infanzia resteranno a Leningrado.
- **2. Analisi dei Personaggi:**
  1. *Boris:* Si rivela lucido, privo di illusioni e capace di badare a se stesso e alla famiglia; la sua concretezza conquista il rispetto di Viktor.
  2. *Nadya:* La reazione aggressiva verso la madre è una difesa contro il dolore dell'abbandono; vedendola piangere, comprende il sacrificio dei genitori e ritrova la tenerezza.
- **3. Officina di Scrittura:** Valutare la sensibilità nell'esprimere l'affetto fraterno, l'orgoglio del ragazzo e il legame profondo con la famiglia.
- **4. Laboratorio Lessicale:** Combinazione corretta: `1-C, 2-E, 3-B, 4-A, 5-D`.
- **5. Attività Speciale:** Valutare la capacità di distinguere tra una regola formale e le necessità umane della vita reale.
