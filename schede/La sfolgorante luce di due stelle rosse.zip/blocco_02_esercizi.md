# SCHEDA DIDATTICA DI LETTURA E COMPRENSIONE
## *La sfolgorante luce di due stelle rosse* di Davide Morosinotto
### Unità Didattica 2 (Blocco 2): *Capitolo 4* – *Capitolo 7*

---

**Nome e Cognome dello studente:** ________________________________________  
**Classe:** ____________________  **Data:** ____________________  

---

> ### 🌊 Sui tetti della città e l'ombra della partenza
> «Rispetto a tutti gli altri voi due siete fortunati. Perché siete gemelli, vi volete bene e potrete restare sempre insieme. Questo renderà tutto più facile.»  
> Nelle notti bianche di Leningrado, tra un turno di vedetta sui tetti e il suono delle sirene, l'infanzia di Viktor e Nadya sta per cambiare per sempre. Ma quando la paura bussa alla porta di casa, qual è il confine tra una bugia detta per amore e una dura verità?

---

## 1. Comprensione del Testo

### A. Domande a risposta aperta
*Rispondi sul tuo quaderno in modo completo, motivando le tue risposte con riferimenti precisi al testo.*

1. **Il peso di una parola di troppo:**  
   Nel Capitolo 4 Nadya ricorda l'arresto notturno di un giovane studente universitario che abitava nel loro palazzo. Qual era stata la colpa del ragazzo e cosa rivela questo episodio sul clima di sospetto che regna a Leningrado?

2. **La verità scomoda di Boris:**  
   Durante il primo turno di vedetta antincendio sul tetto, Boris contesta apertamente i bollettini radiofonici. Quali fatti concreti cita per dimostrare che l'Armata Rossa sta arretrando e perché Viktor lo accusa di tradimento?

3. **La colazione delle cattive notizie:**  
   Nel Capitolo 6 i gemelli rientrano a casa e trovano una tavola imbandita con piatti insolitamente ricchi preparati dalla madre. Perché Nadya, anziché rallegrarsi, prova un brivido di paura e quali due annunci dolorosi stanno per fare i genitori?

4. **Le due facce del discorso paterno:**  
   I genitori descrivono inizialmente l'evacuazione sui "treni dei bambini" come una breve vacanza estiva sugli Urali; a mezzanotte, però, il padre parla ai figli in modo ben diverso. Perché prima ricorre a una bugia e cosa chiede a Viktor consegnando i cinque nuovi quaderni?

5. **Il sacrificio al mercato nero:**  
   Nel Capitolo 7, sotto una pioggia battente, la madre accompagna i gemelli in un parco periferico. Cosa accade in quel luogo, quale bene prezioso sacrifica la donna e quale severo reato si consuma secondo le leggi sovietiche?

---

### B. Vero o Falso? (Attenzione ai dettagli)
*Indica se ciascuna affermazione è Vera (V) o Falsa (F). Correggi le affermazioni false sul tuo quaderno.*

| Affermazione | V | F |
| :--- | :---: | :---: |
| 1. Per il turno di vedetta sui tetti il comitato di quartiere fornisce puntualmente a ogni squadra mappe militari e binocoli professionali. | | |
| 2. Mentre si trova ai piani bassi, Viktor avverte una sensazione di allarme per la sorella e torna di corsa in terrazza poco prima che Nadya avvisti aerei nemici. | | |
| 3. Con la proclamazione della legge marziale tutti i ragazzi dai dodici anni in su sono obbligati a scavare trincee difensive attorno alla città. | | |
| 4. Ispezionando i bagagli dei figli, la madre toglie gli abiti estivi leggeri per fare posto a maglioni di lana pesanti e pezze da piedi. | | |
| 5. I gemelli accettano con gioia la partenza perché sanno che saliranno sul convoglio assieme agli amici Darya, Stepan e al signor Yashkin. | | |

---

## 2. Analisi dei Personaggi e Riflessione
*Rispondi alle seguenti domande sul tuo quaderno, analizzando a fondo i personaggi e motivando le tue considerazioni.*

1. **La maturità nascosta di Boris:**  
   A scuola Boris è considerato lento, silenzioso e poco incline allo studio. Sul tetto, tuttavia, dimostra una lucidità sorprendente sulla guerra e rivela una toccante dedizione familiare. Come muta la percezione di questo personaggio agli occhi di Viktor e del lettore?

2. **La tempesta interiore di Nadya:**  
   Nel Capitolo 7 Nadya passa dall'affetto alla rabbia violenta contro la madre, accartocciando la lettera d'addio che aveva preparato. Analizza i suoi sentimenti: perché si sente tradita e cosa la induce a cambiare atteggiamento nel cuore della notte?

---

## 3. Officina di Scrittura Creativa ed Empatia
*Svolgi la seguente attività di scrittura sul tuo quaderno.*

Nel Capitolo 7 la madre chiede ai figli di scriverle una lettera d'addio da custodire durante la loro lontananza. Nel romanzo leggiamo il biglietto con le "cose allegre" di Nadya, ma non compare la lettera di **Viktor**, rimasto a lungo chino sull'atlante per dissimulare la commozione. Scrivi sul tuo quaderno il messaggio segreto di Viktor per i genitori prima di salire sul treno: esprimi il suo orgoglio di Pioniere, la nostalgia che già lo stringe e la solenne promessa di non abbandonare mai Nadya.

---

## 4. Laboratorio Lessicale e Modi di Dire
*Associa ciascun vocabolo o espressione d'autore al suo significato nel contesto del racconto (indica sul quaderno la combinazione corretta numero-lettera).*

| Termine o Modo di Dire | Abbinamento | Significato Contestuale |
| :--- | :---: | :--- |
| 1. **Blitzkrieg** | [   ] | A. Strisce rettangolari di tessuto usate al posto dei calzini per fasciare i piedi negli stivali contro il gelo. |
| 2. **Legge marziale** | [   ] | B. Formazioni di cittadini arruolati rapidamente per affiancare l'esercito regolare nella difesa della città. |
| 3. **Milizia Popolare** | [   ] | C. Tattica bellica basata sulla rapidità fulminea di mezzi corazzati e aviazione per travolgere il nemico di sorpresa. |
| 4. **Pezze da piedi** | [   ] | D. Presentare rughe e pieghe sulla fronte, indice di intensa concentrazione o cupa preoccupazione. |
| 5. **Fronte corrugata** | [   ] | E. Ordinamento d'emergenza che sospende le tutele civili e impone rigide restrizioni, tra cui il coprifuoco notturno. |

---

## 5. Attività Speciale "Fuori dagli Schemi"

**Processo in Aula / Dibattito (Debate): L'Accusa di Smirnov contro la Famiglia Danilov**  
Nelle annotazioni di fine Primo Quaderno (dicembre 1946), il colonnello Smirnov elenca tre presunti reati:
1. *Furto ai danni dello Stato:* il quaderno ad anelli dell'Ermitage trattenuto per uso privato.
2. *Negligenza di vedetta in tempo di guerra:* aver giocato a *rezinochki* (salto dell'elastico) sul tetto.
3. *Commercio illegale al mercato nero:* lo scambio dei gioielli materni per procurare cibo ai figli.

Organizzate un dibattito tra due collegi: **L'Accusa (Ispettorato NKVD)**, che difende il rigore inflessibile della legge in una città assediata, e **La Difesa della Famiglia Danilov**, che evidenzia lo stato di necessità, l'età dei ragazzi e il loro contributo attivo alla difesa civile. Concludete con una sentenza motivata e disegnate sul vostro quaderno i timbri regolamentari di Smirnov.

---

### GUIDA E RIASSUNTO PER IL DOCENTE

#### Riassunto sintetico dei capitoli
- **Capitolo 4 (26 giugno 1941):** Nadya rammenta l'arresto notturno di uno studente e promette di proteggere il diario. Viktor descrive il primo turno di vedetta antincendio sul tetto con Yashkin, Nadya, Darya, Stepan e Boris. Con binocoli teatrali di fortuna, Boris svela la verità sull'impreparazione sovietica; Viktor si allontana per non litigare, ma un presentimento lo richiama in cima giusto in tempo per avvistare aerei nemici.
- **Capitolo 5 (27–28 giugno 1941):** La legge marziale mobilita i cittadini sopra i sedici anni per scavare trincee. La rumorosa *kommunalka* piomba in un silenzio spettrale.
- **Capitolo 6 (30 giugno – 1° luglio 1941):** I genitori offrono ai gemelli un ricco banchetto mattutino: il padre è arruolato nella Milizia, la madre resta all'Ermitage e i figli partiranno sui treni verso gli Urali. A mezzanotte il padre confessa la gravità della situazione, regala cinque quaderni rossi e fa promettere a Viktor di difendere Nadya.
- **Capitolo 7 (2 luglio 1941) e Rapporto NKVD:** La madre baratta gli ori di famiglia al mercato nero per ottenere viveri da viaggio. Nadya accoglie con sdegno la notizia che gli amici non partiranno con loro; di notte, però, scopre la sofferenza della madre e le lascia una tenera lettera. Smirnov chiude il Primo Quaderno contestando furto, negligenza e mercato nero.

#### Soluzioni ed elementi chiave di correzione
- **1.A Domande aperte:**
  1. *Il peso di una parola di troppo:* Lo studente fu arrestato per aver criticato le autorità; l'episodio illustra il clima di delazione e paura costante dell'NKVD.
  2. *La verità scomoda di Boris:* Boris cita l'efficacia della *blitzkrieg*, l'avanzata inarrestabile della Wehrmacht e la debolezza dei reparti sovietici; Viktor lo accusa di tradimento per difendere la fede negli slogan ufficiali.
  3. *La colazione delle cattive notizie:* Il cibo raffinato in tempo di carestia segnala un pasto d'addio: il padre andrà al fronte nella Milizia e i gemelli dovranno essere evacuati.
  4. *Le due facce del discorso paterno:* All'inizio rassicurano i figli per evitare il panico; nella notte il padre rivela la verità per responsabilizzare Viktor e sigillare il patto tra gemelli.
  5. *Il sacrificio al mercato nero:* La madre vende la collana nuziale d'oro per ottenere cioccolato e gallette; la legge sovietica puniva severamente il mercato nero (art. 78).
- **1.B Vero o Falso:**
  1. **FALSO.** Yashkin procura solo fogli volanti e binocoli da teatro di madreperla.
  2. **VERO.** Viktor avverte un presentimento e rientra in terrazza un istante prima dell'avvistamento.
  3. **FALSO.** L'obbligo di scavo delle trincee scatta a sedici anni, non a dodici.
  4. **VERO.** La madre inserisce indumenti invernali e pezze da piedi presagendo un lungo inverno.
  5. **FALSO.** I ragazzi scoprono con sconcerto che gli amici d'infanzia resteranno a Leningrado.
- **2. Analisi dei Personaggi:**
  1. *La maturità di Boris:* Dimostra lucidità geopolitica e spirito pratico; gestisce la casa da solo ed è immune alla retorica di regime.
  2. *La tempesta di Nadya:* La rabbia è una reazione di difesa contro l'abbandono; il pianto materno le rivela il sacrificio silenzioso dei genitori.
- **3. Officina di Scrittura:** Verificare la voce di Viktor: orgoglio pionieristico, timore nascosto per il padre e determinazione a tutelare Nadya.
- **4. Laboratorio Lessicale:** Combinazione corretta: `1-C, 2-E, 3-B, 4-A, 5-D`.
- **5. Attività Speciale:** Valutare la pertinenza giuridica e morale nel contrapporre la fredda norma bellica al dramma umano dei civili.
