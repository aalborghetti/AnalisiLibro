# SCHEDA DIDATTICA DI LETTURA E COMPRENSIONE
## *La sfolgorante luce di due stelle rosse* di Davide Morosinotto
### Unità Didattica 5 (Blocco 5): *Capitolo 14* – *Capitolo 15*

---

**Nome e Cognome dello studente:** ________________________________________  
**Classe:** ____________________  **Data:** ____________________  

---

> ### 🌊 Le crepe nella verità e il "nemico interno"
> «I giornali non raccontano le storie minute, ma quelle grandi, dei popoli. E sono storie che bisogna saper capire.»  
> Nel silenzio operoso della campagna sul Volga, un ritaglio di giornale del 19 luglio cala come una scure sulle speranze di Viktor. Quando le fonti ufficiali cancellano l'esistenza di centinaia di vite innocenti, l'istinto di ribellione si fa strada: fidarsi degli altri diventa un rischio mortale, ma è anche l'unica chiave per non perdersi.

---

## 1. Comprensione del Testo

### A. Domande a risposta aperta
*Rispondi in modo completo, motivando le tue risposte con riferimenti precisi al testo.*

1. **La lingua cifrata della "Pravda":**  
   Il 26 luglio il direttore Khasanov insegna a Viktor a decifrare la retorica dei bollettini bellici. Quale significato reale si cela dietro formule celebrative come "fiera battaglia" o "resistenza valorosa"?
   
_________________________________________________________________________________________  
_________________________________________________________________________________________  
_________________________________________________________________________________________  

2. **La notizia che gela il sangue:**  
   Il 4 agosto Khasanov mostra a Viktor una copia spiegazzata della *Leningradskaya Pravda* del 19 luglio. Quale tragico annuncio contiene l'articolo riguardo al treno 76 e qual è l'immediata reazione emotiva del ragazzo?
   
_________________________________________________________________________________________  
_________________________________________________________________________________________  
_________________________________________________________________________________________  

3. **Il rifiuto ostinato di Viktor:**  
   La sera stessa gli amici del kolkhoz (Kostya, Lev, Klara, Ilya e Flavio) si stringono attorno a Viktor per sostenerlo nel lutto. Perché Viktor respinge fermamente le condoglianze e su quale convinzione fonda la certezza che Nadya sia ancora viva?
   
_________________________________________________________________________________________  
_________________________________________________________________________________________  
_________________________________________________________________________________________  

4. **Il segreto di Klara e il dramma dei tedeschi del Volga:**  
   All'alba seguente Klara sveglia Viktor proponendogli un piano per fuggire lungo il fiume Volga. Qual è la vera identità della ragazza e perché la sua permanenza nel kolkhoz è diventata estremamente pericolosa?
   
_________________________________________________________________________________________  
_________________________________________________________________________________________  
_________________________________________________________________________________________  

5. **La morsa su Leningrado:**  
   Studiando le cartine geografiche con l'aiuto di Khasanov e Klara, Viktor comprende la manovra delle armate naziste guidate dal generale Leeb. Quali due capisaldi devono conquistare i tedeschi per stringere d'assedio Leningrado e tagliare ogni via di rifornimento?
   
_________________________________________________________________________________________  
_________________________________________________________________________________________  
_________________________________________________________________________________________  

---

### B. Vero o Falso? (Attenzione ai dettagli)
*Indica se l'affermazione è Vera [V] o Falsa [F]. Se è Falsa, correggila brevemente sulle righe sottostanti.*

| Affermazione | V | F |
| :--- | :---: | :---: |
| 1. Ricevuta la notizia del giornale, Viktor rimane impassibile e beve d'un fiato il liquore offerto dal direttore senza mostrare turbamento. | [ ] | [ ] |
| 2. Klara viaggia sul convoglio 77 sotto falso nome perché la sua famiglia di origine tedesca è perseguitata dall'NKVD dopo l'inizio della guerra. | [ ] | [ ] |
| 3. Il rapporto conclusivo di Smirnov sul Secondo Quaderno giudica Viktor un fedele cittadino sovietico meritevole di un'onorificenza al merito. | [ ] | [ ] |
| 4. L'articolo della *Pravda* del 19 luglio riferisce che il treno 76 è stato centrato da un bombardamento a Mga senza lasciare alcun superstite. | [ ] | [ ] |
| 5. Viktor e Klara concordano di attendere il termine della mietitura del grano per fuggire dal kolkhoz a bordo di una chiatta sul Volga. | [ ] | [ ] |

**Correzione delle affermazioni false:**  
_________________________________________________________________________________________  
_________________________________________________________________________________________  
_________________________________________________________________________________________  

---

## 2. Analisi dei Personaggi e Riflessione

1. **Il legame simbiotico tra fratelli:**  
   Di fronte alla testimonianza stampata del giornale e alla pietà dei compagni, Viktor ripete: *«Se mia sorella fosse morta, io lo saprei»*. Rifletti su questa affermazione: si tratta di una suggestione affettiva, di un meccanismo di rifiuto psicologico o della forza indomabile della speranza?
   
_________________________________________________________________________________________  
_________________________________________________________________________________________  
_________________________________________________________________________________________  

2. **La persecuzione degli innocenti (La vicenda di Klara):**  
   Sebbene i genitori di Klara fossero comunisti fuggiti dalla Germania, le loro origini diventano un marchio d'infamia agli occhi del regime staliniano. In che modo la parabola di Klara mostra l'ingiustizia delle colpe collettive in tempo di guerra?
   
_________________________________________________________________________________________  
_________________________________________________________________________________________  
_________________________________________________________________________________________  

---

## 3. Officina di Scrittura Creativa ed Empatia

*Mettiti nei panni di uno dei protagonisti.*

Immagina di essere **Klara** nella notte in cui decidi di confidarti con Viktor accanto alla staccionata del kolkhoz. Temi che il capobrigata Garayev ti abbia sentita canticchiare una ninnananna in tedesco e sai che il tuo tempo sta per scadere. Scrivi una pagina del tuo diario segreto in prima persona: racconta la paura costante di essere smascherata, le ragioni che ti spingono a fidarti di Viktor e il desiderio tenace di raggiungere Leningrado per ritrovare la tua libertà.

_________________________________________________________________________________________  
_________________________________________________________________________________________  
_________________________________________________________________________________________  
_________________________________________________________________________________________  
_________________________________________________________________________________________  

---

## 4. Laboratorio Lessicale e Modi di Dire

*Associa ciascun vocabolo o espressione d'autore al suo significato nel contesto del racconto.*

| Termine o Modo di Dire | Abbinamento | Significato Contestuale |
| :--- | :---: | :--- |
| 1. **Disfattismo** | [   ] | A. Manovra tattica volta a circondare completamente un centro abitato per bloccare ogni soccorso. |
| 2. **Decifrare** | [   ] | B. Diffusione di sfiducia, pessimismo e critiche sull'esito delle operazioni belliche di una nazione. |
| 3. **Accerchiamento** | [   ] | C. Interpretare un messaggio coperto o una notizia retorica per estrarne il significato reale nascosto. |
| 4. **Rastrellamento** | [   ] | D. Ispezione minuziosa e forzata di un territorio compiuta da reparti armati per catturare fuggitivi. |
| 5. **Ninnananna** | [   ] | E. Canto infantile dolce e melodico tramandato oralmente dalle madri per rassicurare i piccoli. |

---

## 5. Attività Speciale "Fuori dagli Schemi"

**Redazione Giornalistica d'Epoca: La "Controgazzetta" Clandestina dei Ragazzi**  
Mentre la *Leningradskaya Pravda* celebra la memoria dei caduti del treno 76 dandoli tutti per morti, i lettori sanno che i ragazzi sono vivi e intrappolati a Shlisselburg!  
Crea la prima pagina di un **foglio clandestino di controinformazione**:
1. *Titolo di apertura a caratteri cubitali:* uno slogan che metta a nudo le menzogne della censura di Partito.
2. *Articolo di inchiesta:* la vera storia dei vagoni bloccati a Mga, dell'incendio notturno e del trasferimento al lago Ladoga.
3. *Intervista a Viktor Danilov:* le dichiarazioni del ragazzo che smentisce la versione ufficiale e annuncia la propria marcia per ricongiungersi con la sorella gemella.

[SPAZIO PER IL TUO DISEGNO / RILIEVO GRAFICO]

---

### GUIDA E RIASSUNTO PER IL DOCENTE

#### Riassunto sintetico dei capitoli
- **Capitolo 14 (26 luglio – 4 agosto 1941 - Viktor):** Tre settimane trascorrono senza notizie. Khasanov spiega a Viktor come decifrare la prosa della *Pravda*: espressioni celebrative mascherano ritirate disastrose e massacri. Il 4 agosto il direttore convoca Viktor e gli mostra il giornale del 19 luglio: un trafiletto dichiara che il treno 76 è stato bombardato nei pressi di Mga senza superstiti. Viktor, sconvolto, versa il bicchiere di vodka ma rifiuta di credere alla morte di Nadya, facendo appello al legame intimo tra gemelli.
- **Capitolo 15 (5 agosto in poi - Viktor):** Nella notte Klara si confida con Viktor: rivela di essere tedesca di nascita (figlia di rifugiati comunisti bavaresi perseguitati dall'NKVD) e di rischiare l'arresto immediato. Propone di sottrarre una chiatta a motore sul Volga al termine del raccolto per risalire il fiume verso nord. Monitorando la mappa militare, Viktor apprende che la Wehrmacht punta a espugnare Mga e Shlisselburg per sigillare l'accerchiamento di Leningrado. Nel **Rapporto di fine Secondo Quaderno** (dicembre 1946) Smirnov elenca le violazioni di Viktor (abuso di veicoli, diserzione dal lavoro, favoreggiamento e disfattismo), considerandolo altamente indiziato.

#### Soluzioni ed elementi chiave di correzione
- **1.A Domande aperte:**
  1. *La lingua cifrata della Pravda:* Le comunicazioni governative alterano la realtà per scongiurare il panico: "fiera battaglia" cela pesanti sconfitte; "resistenza valorosa" indica battaglioni distrutti dal nemico.
  2. *La notizia che gela il sangue:* La testata dichiara il convoglio 76 annientato da incursioni aeree senza superstiti; Viktor attraversa un primo momento di paralisi per poi arroccarsi nel rifiuto categorico.
  3. *Il rifiuto ostinato di Viktor:* Nega l'evidenza poiché è convinto che un legame profondo come quello gemellare gli avrebbe segnalato la scomparsa della sorella; l'illusione diventa la molla vitale per non cedere alla disperazione.
  4. *Il segreto di Klara:* È figlia di militanti tedeschi emigrati in Russia; dopo l'avvio delle ostilità tutti i residenti di etnia tedesca sono considerati spie; teme che Garayev la denunci per averla udita cantare in tedesco.
  5. *La strategia dell'accerchiamento:* Conquistare Mga (snodo ferroviario chiave) e Shlisselburg (sbocco fluviale della Neva sul lago Ladoga) per troncare qualunque collegamento di Leningrado con l'entroterra.
- **1.B Vero o Falso:**
  1. **FALSO.** Viktor è in preda allo shock e rovescia goffamente il liquore sul tappeto dell'abitazione.
  2. **VERO.** Klara usa documenti contraffatti per evitare la deportazione dell'NKVD contro i cittadini tedeschi.
  3. **FALSO.** Smirnov contesta a Viktor numerosi reati gravi ed esprime un giudizio severamente colpevolista.
  4. **VERO.** L'articolo ufficiale sancisce la perdita totale del treno 76 senza superstiti.
  5. **VERO.** I due pianificano di dileguarsi via fiume approfittando della fine della stagione di mietitura.
- **2. Analisi dei Personaggi:**
  1. *Il legame simbiotico:* La fede incrollabile di Viktor funge da scudo psicologico primario: per un adolescente traumatizzato dalla guerra, la certezza della sopravvivenza della gemella è l'unica ragione per continuare a lottare.
  2. *La vicenda di Klara:* Dimostra l'assurdità del sospetto totalitario: l'appartenenza etnica prevale sull'onestà e sull'adesione ideologica, costringendo una minorenne alla clandestinità permanente.
- **3. Officina di Scrittura:** Verificare la modulazione stilistica: tensione per la sorveglianza, timore della delazione e slancio di fiducia verso Viktor.
- **4. Laboratorio Lessicale:** Combinazione corretta: `1-B, 2-C, 3-A, 4-D, 5-E`.
- **5. Attività Speciale:** Valutare la capacità di articolare un testo di controinformazione efficace, con titolazioni persuasive e argomentazioni documentate.
