# SCHEDA DIDATTICA DI LETTURA E COMPRENSIONE
## *La sfolgorante luce di due stelle rosse* di Davide Morosinotto
### Unità Didattica 5 (Blocco 5): *Capitolo 14* – *Capitolo 15*

> ### 🌊 Le crepe nella verità e il "nemico interno"
> «I giornali non raccontano le storie minute, ma quelle grandi, dei popoli. E sono storie che bisogna saper capire.»  
> Nella quiete operosa della campagna sul Volga, un ritaglio di giornale del 19 luglio cala come una scure sulle speranze di Viktor. Quando le notizie ufficiali sembrano cancellare ogni traccia di Nadya, l'istinto di ribellione si fa strada: fidarsi degli amici diventa rischioso, ma è l'unico modo per non perdersi d'animo.

---

## 1. Comprensione del Testo

### A. Domande a risposta aperta
*Rispondi sul tuo quaderno in modo chiaro e completo, facendo riferimento a ciò che hai letto nel testo.*

1. **Come leggere i giornali di guerra:**  
   Il 26 luglio il direttore Khasanov insegna a Viktor a leggere tra le righe degli articoli della "Pravda". Cosa nascondono formule celebrative come "fiera battaglia" o "resistenza valorosa"?

2. **Una notizia che gela il sangue:**  
   Il 4 agosto Khasanov mostra a Viktor una copia spiegazzata della *Leningradskaya Pravda* del 19 luglio. Quale tragico annuncio contiene l'articolo riguardo al treno 76 e come reagisce il ragazzo?

3. **Un rifiuto ostinato:**  
   La sera stessa gli amici del kolkhoz si stringono attorno a Viktor per sostenerlo nel momento del dolore. Perché Viktor rifiuta con tanta fermezza le loro condoglianze e su quale convinzione fonda la certezza che Nadya sia ancora viva?

4. **Il segreto di Klara:**  
   All'alba seguente Klara sveglia Viktor proponendogli un piano per fuggire lungo il fiume Volga. Qual è la vera identità della ragazza e perché la sua presenza nel kolkhoz è diventata estremamente pericolosa?

5. **L'avanzata su Leningrado:**  
   Studiando le cartine geografiche con l'aiuto di Khasanov e Klara, Viktor comprende la manovra delle truppe nemiche. Quali due luoghi strategici vogliono conquistare i tedeschi per isolare Leningrado e tagliare ogni via di rifornimento?

---

### B. Vero o Falso? (Attenzione ai dettagli)
*Indica se ciascuna affermazione è Vera (V) o Falsa (F). Correggi le affermazioni false sul tuo quaderno.*

| Affermazione | V | F |
| :--- | :---: | :---: |
| 1. Quando legge la notizia sul giornale, Viktor rimane impassibile e non versa neppure una lacrima. | | |
| 2. Klara viaggia sul convoglio 77 con documenti falsi perché la sua famiglia di origine tedesca rischia di essere arrestata. | | |
| 3. Nel suo rapporto del 1946, Smirnov scrive che Viktor era un cittadino esemplare che non meritava alcuna accusa. | | |
| 4. L'articolo della *Pravda* del 19 luglio riferisce che il treno 76 è stato bombardato a Mga senza lasciare alcun superstite. | | |
| 5. Viktor e Klara decidono di fuggire insieme lungo il Volga approfittando della fine del raccolto estivo. | | |

---

## 2. Analisi dei Personaggi e Riflessione
*Rispondi alle seguenti domande sul tuo quaderno, riflettendo bene sui comportamenti dei protagonisti.*

1. **La forza della speranza:**  
   Di fronte alla notizia stampata sul giornale e alle condoglianze degli amici, Viktor ripete: *«Se mia sorella fosse morta, io lo saprei»*. Perché Viktor si rifiuta con tanta forza di credere alla notizia ufficiale? È solo un'illusione o è il suo modo per trovare il coraggio di continuare a lottare?

2. **La paura di Klara:**  
   I genitori di Klara erano comunisti fuggiti dalla Germania, eppure per colpa delle sue origini tedesche la ragazza viene considerata una nemica della Russia. In che modo la vicenda di Klara ci mostra quanto siano ingiusti i pregiudizi in tempo di guerra?

---

## 3. Officina di Scrittura Creativa ed Empatia
*Svolgi la seguente attività di scrittura sul tuo quaderno.*

Immagina di essere **Klara** nella notte in cui decidi di confidarti con Viktor accanto alla staccionata della fattoria. Temi che il capobrigata Garayev ti abbia sentita cantare una canzoncina in tedesco e sai che il tuo tempo sta per scadere. Scrivi sul tuo quaderno una pagina del tuo diario segreto in prima persona: racconta la paura di essere smascherata, le ragioni che ti spingono a fidarti di Viktor e il desiderio tenace di raggiungere Leningrado per riconquistare la libertà.

---

## 4. Laboratorio Lessicale e Modi di Dire
*Associa ciascun vocabolo o espressione d'autore al suo significato nel contesto del racconto (indica sul quaderno la combinazione corretta numero-lettera).*

| Termine o Modo di Dire | Abbinamento | Significato Contestuale |
| :--- | :---: | :---: |
| 1. **Disfattismo** | | A. Manovra con cui un esercito circonda completamente una città per bloccare soccorsi e rifornimenti. |
| 2. **Decifrare** | | B. Diffusione di sfiducia, paura e pessimismo sull'esito della guerra. |
| 3. **Accerchiamento** | | C. Riuscire a comprendere il vero significato nascosto dietro parole difficili o ingannevoli. |
| 4. **Coprifuoco** | | D. Divieto imposto dalle autorità di circolare per le strade durante la notte per ragioni di sicurezza e difesa. |
| 5. **Ninnananna** | | E. Dolce canzoncina cantata per far addormentare i bambini e rassicurarli. |

---

## 5. Attività Speciale "Fuori dagli Schemi"

**La prima pagina del Giornalino Clandestino**  
I giornali ufficiali dicono che tutti i passeggeri del treno 76 sono morti nel bombardamento, ma noi sappiamo che i ragazzi sono vivi a Shlisselburg!  
Crea sul tuo quaderno la prima pagina di un **foglio di notizie segreto** realizzato dai ragazzi:
1. *Un titolo a caratteri grandi:* inventa uno slogan forte che smentisca le bugie della propaganda;
2. *Un breve articolo:* spiega come sono andate realmente le cose a Mga e dove si trovano ora i ragazzi;
3. *Un'intervista a Viktor:* trascrivi le parole del ragazzo che promette di mettersi in viaggio per ritrovare sua sorella.

---

### GUIDA E RIASSUNTO PER IL DOCENTE

#### Riassunto sintetico dei capitoli
- **Capitolo 14 (26 luglio – 4 agosto 1941 - Viktor):** Tre settimane trascorrono senza notizie. Khasanov spiega a Viktor come decifrare la prosa della *Pravda*: espressioni celebrative mascherano ritirate disastrose e massacri. Il 4 agosto il direttore convoca Viktor e gli mostra il giornale del 19 luglio: un trafiletto dichiara che il treno 76 è stato bombardato nei pressi di Mga senza superstiti. Viktor, sconvolto, versa il bicchiere di vodka ma rifiuta di credere alla morte di Nadya, facendo appello al legame intimo tra gemelli.
- **Capitolo 15 (5 agosto in poi - Viktor):** Nella notte Klara si confida con Viktor: rivela di essere tedesca di nascita (figlia di rifugiati comunisti bavaresi perseguitati dall'NKVD) e di rischiare l'arresto immediato. Propone di sottrarre una chiatta a motore sul Volga al termine del raccolto per risalire il fiume verso nord. Monitorando la mappa militare, Viktor apprende che la Wehrmacht punta a espugnare Mga e Shlisselburg per sigillare l'accerchiamento di Leningrado. Nel **Rapporto di fine Secondo Quaderno** (dicembre 1946) Smirnov elenca le violazioni di Viktor (abuso di veicoli, diserzione dal lavoro, favoreggiamento e disfattismo), considerandolo altamente indiziato.

#### Soluzioni ed elementi chiave di correzione
- **1.A Domande aperte:**
  1. *Come leggere i giornali di guerra:* Le comunicazioni nascondono la realtà: "fiera battaglia" cela una grave sconfitta; "resistenza valorosa" indica un reparto spazzato via dall'artiglieria nemica.
  2. *Una notizia che gela il sangue:* La notizia dichiara che il treno 76 è stato distrutto senza superstiti; Viktor attraversa un primo momento di choc per poi rifiutare la versione ufficiale.
  3. *Un rifiuto ostinato:* Nega l'evidenza convinto che il legame con la gemella gli avrebbe fatto percepire la sua scomparsa; questo rifiuto è la molla vitale per continuare a lottare.
  4. *Il segreto di Klara:* È nata in Germania da genitori comunisti; con la guerra tutti i cittadini di etnia tedesca sono visti come traditori e spie; rischia la prigione o la deportazione.
  5. *L'avanzata su Leningrado:* Conquistare Mga e Shlisselburg per sigillare l'anello intorno a Leningrado e tagliare ogni via d'acqua e ferroviaria.
- **1.B Vero o Falso:**
  1. **FALSO.** Viktor è sconvolto dalla notizia e fa cadere a terra il bicchiere.
  2. **VERO.** Klara si nasconde sotto una falsa identità per evitare la prigione.
  3. **FALSO.** Smirnov elenca numerose accuse e considera Viktor un ribelle colpevole.
  4. **VERO.** L'articolo ufficiale dichiara che non ci sono stati superstiti a Mga.
  5. **VERO.** I due pianificano di fuggire insieme via fiume a fine mietitura.
- **2. Analisi dei Personaggi:**
  1. *La forza della speranza:* La convinzione di Viktor non è semplice illusione, ma una difesa emotiva necessaria per non farsi schiacciare dalla disperazione e per darsi una missione vitale.
  2. *La vicenda di Klara:* Mette a nudo l'ingiustizia delle colpe collettive, dove l'origine familiare conta più della condotta reale e dell'onestà della persona.
- **3. Officina di Scrittura:** Verificare la resa psicologica della paura di Klara, il timore della denuncia e la decisione di fidarsi di Viktor.
- **4. Laboratorio Lessicale:** Combinazione corretta: `1-B, 2-C, 3-A, 4-D, 5-E`.
- **5. Attività Speciale:** Valutare la creatività nella stesura del notiziario e la chiarezza nell'esporre i fatti reali contro le bugie della censura.
