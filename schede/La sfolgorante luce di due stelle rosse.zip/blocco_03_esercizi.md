# SCHEDA DIDATTICA DI LETTURA E COMPRENSIONE
## *La sfolgorante luce di due stelle rosse* di Davide Morosinotto
### Unità Didattica 3 (Blocco 3): *Capitolo 8* – *Capitolo 10*

> ### 🌊 Due numeri diversi sul dorso della mano
> «Avevo detto a papà che mi sarei preso cura di mia sorella. Che non l'avrei abbandonata. Invece...»  
> Alla stazione Sortirovochnaya di Leningrado bastano un timbro a inchiostro sulla pelle e un errore burocratico per dividere Nadya e Viktor. Rimasto solo su un carro bestiame diretto verso l'ignoto, Viktor scoprirà cosa significa farsi coraggio e guidare un gruppo di compagni impauriti.

---

## 1. Comprensione del Testo

### A. Domande a risposta aperta
*Rispondi sul tuo quaderno in modo chiaro e completo, facendo riferimento a ciò che hai letto nel testo.*

1. **Un regalo inaspettato:**  
   La mattina della partenza il papà consegna ai gemelli alcuni rubli, orecchini per Nadya e una piccola icona sacra d'argento per Viktor. Perché Viktor all'inizio rimane sorpreso da questo dono e quale valore acquisterà l'oggetto durante il viaggio?

2. **La divisione alla stazione:**  
   Alla stazione di Leningrado un funzionario scrive sulla mano di Nadya il numero 76 e su quella di Viktor il 77. Per quale motivo banale i due gemelli vengono separati e perché i soldati impediscono loro di riunirsi?

3. **L'inganno di Mikhail:**  
   Quando il treno 77 si mette in marcia e affianca il treno 76 ancora fermo, Viktor nota una sbavatura d'inchiostro sulla mano del compagno Mikhail. Cosa ha fatto Mikhail e perché Viktor si scaglia contro di lui con tanta rabbia?

4. **Dagli scontri alla solidarietà:**  
   Nel Capitolo 10, durante una sosta in aperta campagna, il corpulento Lev minaccia un ragazzino per rubargli le provviste. Come interviene Viktor, quale gesto compie per dare l'esempio e come viene organizzata la condivisione del cibo?

5. **Una parola d'ordine che cambia tutto:**  
   Durante la cena nel vagone, Lev riconosce Viktor avendolo visto ai *baraki*. Perché Viktor decide di fidarsi e nomina lo "zio Dmitry"? Quale effetto immediato produce questo nome su Lev?

---

### B. Vero o Falso? (Attenzione ai dettagli)
*Indica se ciascuna affermazione è Vera (V) o Falsa (F). Correggi le affermazioni false sul tuo quaderno.*

| Affermazione | V | F |
| :--- | :---: | :---: |
| 1. Ai cancelli della stazione i genitori riescono ad accompagnare i figli fin dentro lo scompartimento per sistemare i bagagli. | | |
| 2. Prima di essere divisi, Nadya riesce a passare al fratello dal finestrino tre quaderni rossi e le matite. | | |
| 3. Il convoglio 77 è formato da carri bestiame bui, freddi e senza sedili, usati solitamente per il trasporto merci. | | |
| 4. Kostya aiuta Viktor a fare l'inventario del cibo presente nel vagone per dividerlo in parti eque per tutti. | | |
| 5. Durante la sosta notturna in campagna, i soldati di scorta distribuiscono a ogni ragazzo una scodella di zuppa calda. | | |

---

## 2. Analisi dei Personaggi e Riflessione
*Rispondi alle seguenti domande sul tuo quaderno, riflettendo bene sui comportamenti dei protagonisti.*

1. **La crescita di Viktor:**  
   All'inizio del viaggio Viktor si sente disperato e in colpa per aver perso la sorella. Come riesce a superare lo sconforto e a diventare un punto di riferimento per gli altri ragazzi spaventati?

2. **Fare squadra nel vagone:**  
   Nel carro bestiame si incontrano ragazzi molto diversi: Kostya (intelligente e ordinato), Lev (forte e impulsivo) e Klara (decisa e pratica). In che modo le loro qualità si uniscono per superare le difficoltà del viaggio?

---

## 3. Officina di Scrittura Creativa ed Empatia
*Svolgi la seguente attività di scrittura sul tuo quaderno.*

Immagina di essere **Nadya** sul treno passeggeri 76 subito dopo la partenza da Leningrado. Dal finestrino impolverato hai visto sfilare il treno 77 e hai scorto tuo fratello Viktor trattenuto dai soldati. Scrivi sul tuo quaderno una pagina di diario in prima persona: racconta lo smarrimento di trovarti sola senza il tuo gemello, il rimpianto per non avergli stretto la mano e la promessa che fai a te stessa di fare qualsiasi cosa pur di ritrovarlo.

---

## 4. Laboratorio Lessicale e Modi di Dire
*Associa ciascun vocabolo o espressione d'autore al suo significato nel contesto del racconto (indica sul quaderno la combinazione corretta numero-lettera).*

| Termine o Modo di Dire | Abbinamento | Significato Contestuale |
| :--- | :---: | :--- |
| 1. **Sortirovochnaya** | | A. Piccola immagine sacra dipinta su una tavoletta di legno secondo la tradizione religiosa russa. |
| 2. **Carro bestiame** | | B. Persona che collabora con lealtà pensando al bene di tutti prima che al proprio interesse. |
| 3. **Icona** | | C. Grande stazione merci dove i vagoni dei treni vengono divisi e indirizzati su binari diversi. |
| 4. **Burocrazia** | | D. Vagone ferroviario merci in legno, privo di sedili e riscaldamento, riadattato per trasportare persone. |
| 5. **Spirito di squadra** | | E. Insieme di regole rigide e timbri d'ufficio che spesso dimenticano i bisogni reali della gente. |

---

## 5. Attività Speciale "Fuori dagli Schemi"

**Il Rapporto Investigativo: Il mistero della separazione alla stazione**  
Immagina di essere un giovane investigatore incaricato di ricostruire l'incidente avvenuto alla stazione Sortirovochnaya che ha portato alla separazione di Viktor e Nadya.  
Scrivi sul tuo quaderno un breve **Verbale d'Inchiesta**:
1. *La ricostruzione dei fatti:* descrivi la folla ai cancelli, la fretta dell'impiegato al bancone dei timbri e il momento in cui i posti del treno 76 si sono esauriti;
2. *L'indizio chiave:* spiega il trucco del numero di matricola cancellato da Mikhail per salire sul treno 77;
3. *Le testimonianze:* inserisci una breve dichiarazione di Kostya o di Lev che hanno assistito alla scena.

---

### GUIDA E RIASSUNTO PER IL DOCENTE

#### Riassunto sintetico dei capitoli
- **Capitolo 8 (3 luglio 1941):** All'alba il padre dona a Nadya gli orecchini d'argento e a Viktor un'icona antica, raccomandandogli di custodirla con cura. Alla stazione Sortirovochnaya la folla è incontenibile; i genitori vengono bloccati dai soldati. Al tavolo delle registrazioni il funzionario esaurisce i posti del treno 76: a Nadya tocca il 76, a Viktor il 77. Separati brutalmente dalle guardie, i gemelli salgono su convogli distinti.
- **Capitolo 9:** Il treno 77 è formato da carri bestiame bui e sporchi. Affiancando il treno 76 sui binari, Viktor scopre che Mikhail ha cancellato il numero 76 per salire sul 77: la rabbia per lo scambio mancato scatena una rissa furente.
- **Capitolo 10 (4–5 luglio 1941):** In aperta campagna, durante una fermata notturna, Lev tenta di rubare viveri a un bambino; Viktor interviene fermamente e convince tutti a mettere in comune il cibo, supportato da Kostya e Klara. Parlando con Lev, Viktor nomina "Dmitry": la parola d'ordine scioglie l'ostilità del ragazzo, cementando l'intesa del gruppo.

#### Soluzioni ed elementi chiave di correzione
- **1.A Domande aperte:**
  1. *Un regalo inaspettato:* Viktor è educato secondo le idee sovietiche che vedevano la religione con diffidenza; l'icona ha però un valore affettivo enorme e si rivelerà un bene prezioso da custodire.
  2. *La divisione alla stazione:* L'anziano impiegato finisce i posti del treno 76 esattamente dopo Nadya; le guardie applicano gli ordini rigidamente e impediscono ai gemelli di restare uniti.
  3. *L'inganno di Mikhail:* Mikhail ha cancellato il proprio numero per non salire sul treno 76; Viktor capisce che al suo posto avrebbe potuto esserci lui accanto alla sorella.
  4. *Dagli scontri alla solidarietà:* Viktor ferma Lev condividendo per primo le proprie scorte e dimostrando che solo collaborando tutti potranno salvarsi.
  5. *Una parola d'ordine:* Dmitry è un operaio stimato e temuto nei quartieri popolari; il suo nome fa capire a Lev che Viktor è un compagno di cui fidarsi.
- **1.B Vero o Falso:**
  1. **FALSO.** I genitori vengono fermati ai cancelli dalle sentinelle armate.
  2. **VERO.** Nadya passa a Viktor i quaderni e le matite prima del blocco.
  3. **VERO.** Il treno 77 è un convoglio merci per bestiame (*teplushka*), buio e spartano.
  4. **VERO.** Kostya gestisce le provviste per assicurare una spartizione corretta a tutti.
  5. **FALSO.** I soldati non offrono alcun pasto; i ragazzi mangiano solo ciò che condividono.
- **2. Analisi dei Personaggi:**
  1. *Crescita di Viktor:* Il dolore per la sorella si trasforma in senso di responsabilità: Viktor impara a dominare la rabbia e a proteggere i compagni più indifesi.
  2. *Fare squadra:* Kostya porta metodo e intelligenza, Lev forza e determinazione, Klara prontezza pratica. La cooperazione si rivela l'unica arma vincente.
- **3. Officina di Scrittura:** Verificare la resa emotiva dello smarrimento di Nadya e la tenacia nel voler ritrovare il fratello.
- **4. Laboratorio Lessicale:** Combinazione corretta: `1-C, 2-D, 3-A, 4-E, 5-B`.
- **5. Attività Speciale:** Valutare la chiarezza nella ricostruzione dei fatti e la coerenza degli indizi inseriti.
