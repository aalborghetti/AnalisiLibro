# SCHEDA DIDATTICA DI LETTURA E COMPRENSIONE
## *La sfolgorante luce di due stelle rosse* di Davide Morosinotto
### Unità Didattica 3 (Blocco 3): *Capitolo 8* – *Capitolo 10*

---

**Nome e Cognome dello studente:** ________________________________________  
**Classe:** ____________________  **Data:** ____________________  

---

> ### 🌊 Due numeri diversi sul dorso della mano
> «Avevo detto a papà che mi sarei preso cura di mia sorella. Che non l'avrei abbandonata. Invece...»  
> Alla stazione Sortirovochnaya di Leningrado bastano la fine di un foglio di carta e un numero tracciato a inchiostro sulla pelle per spezzare una promessa solenne. Rimasto solo su un carro bestiame verso l'ignoto, Viktor dovrà scoprire sulla propria pelle cosa significa guidare un gruppo di coetanei spaventati.

---

## 1. Comprensione del Testo

### A. Domande a risposta aperta
*Rispondi in modo completo, motivando le tue risposte con riferimenti precisi al testo.*

1. **Un'eredità inaspettata:**  
   La mattina della partenza il padre consegna ai gemelli rubli, orecchini per Nadya e una piccola icona sacra d'argento per Viktor. Perché Viktor resta perplesso di fronte a quel regalo e quale valore pratico e affettivo assume l'oggetto?
   
_________________________________________________________________________________________  
_________________________________________________________________________________________  
_________________________________________________________________________________________  

2. **La trappola burocratica della stazione:**  
   Alla stazione Sortirovochnaya un funzionario scrive sulla mano di Nadya il numero 76 e su quella di Viktor il 77. Per quale motivo puramente casuale i due gemelli vengono divisi e perché i soldati impediscono loro di ricongiungersi?
   
_________________________________________________________________________________________  
_________________________________________________________________________________________  
_________________________________________________________________________________________  

3. **L'inganno di Mikhail e la collera di Viktor:**  
   Quando il treno 77 si avvia, affianca il convoglio 76 ancora fermo e Viktor scorge sulla mano del compagno Mikhail una sbavatura d'inchiostro. Cosa ha fatto Mikhail e perché Viktor gli si scaglia contro con tanta furia?
   
_________________________________________________________________________________________  
_________________________________________________________________________________________  
_________________________________________________________________________________________  

4. **Dagli slogan alla solidarietà concreta:**  
   Nel Capitolo 10, durante una sosta notturna in campagna, il corpulento Lev minaccia un bambino per sottrargli le provviste. Come interviene Viktor, quale gesto compie per dare l'esempio e come viene riorganizzata la distribuzione del cibo?
   
_________________________________________________________________________________________  
_________________________________________________________________________________________  
_________________________________________________________________________________________  

5. **Il nome che apre una porta:**  
   Durante la cena comune nel vagone, Lev riconosce Viktor avendolo visto ai *baraki*. Perché Viktor decide di contravvenire alla prudenza nominando lo "zio Dmitry" e quale effetto immediato sortisce questa confessione su Lev?
   
_________________________________________________________________________________________  
_________________________________________________________________________________________  
_________________________________________________________________________________________  

---

### B. Vero o Falso? (Attenzione ai dettagli)
*Indica se l'affermazione è Vera [V] o Falsa [F]. Se è Falsa, correggila brevemente sulle righe sottostanti.*

| Affermazione | V | F |
| :--- | :---: | :---: |
| 1. Ai cancelli della stazione Sortirovochnaya i genitori accompagnano i figli fino al binario sistemando personalmente le sacche sui vagoni. | [ ] | [ ] |
| 2. Prima della separazione, Nadya riesce a passare al fratello attraverso il finestrino tre quaderni rossi e i suoi lapis. | [ ] | [ ] |
| 3. A differenza del convoglio 76 (composto da carrozze passeggeri), il treno 77 è formato da carri bestiame bui, freddi e sprovvisti di sedili. | [ ] | [ ] |
| 4. Kostya aiuta Viktor a redigere l'inventario del cibo presente nel vagone per pianificare una spartizione equa per tutti. | [ ] | [ ] |
| 5. Durante la sosta nella campagna russa, i soldati di scorta distribuiscono a ogni bambino una razione abbondante di minestra calda e pane fresco. | [ ] | [ ] |

**Correzione delle affermazioni false:**  
_________________________________________________________________________________________  
_________________________________________________________________________________________  
_________________________________________________________________________________________  

---

## 2. Analisi dei Personaggi e Riflessione

1. **La nascita del leader (L'evoluzione di Viktor):**  
   All'inizio del viaggio Viktor si definisce insensibile "come un sasso", ma lo strazio per la perdita di Nadya lo costringe a reagire. Analizza come trasforma lo sconforto e il senso di colpa in determinazione protettiva verso i compagni del vagone.
   
_________________________________________________________________________________________  
_________________________________________________________________________________________  
_________________________________________________________________________________________  

2. **La squadra del carro bestiame (Lev, Kostya, Klara):**  
   Attorno a Viktor si raccolgono figure dai tratti eterogenei: il metodico Kostya, il rude Lev e la risoluta Klara. Quali competenze e fragilità apporta ciascuno al gruppo e in che modo la cooperazione diventa l'unica via di salvezza?
   
_________________________________________________________________________________________  
_________________________________________________________________________________________  
_________________________________________________________________________________________  

---

## 3. Officina di Scrittura Creativa ed Empatia

*Mettiti nei panni di uno dei protagonisti.*

Immagina di essere **Nadya** a bordo del treno passeggeri numero 76 subito dopo la partenza da Leningrado. Attraverso i vetri polverosi hai visto sfilare il treno 77 e hai scorto Viktor trattenuto a forza dalle sentinelle. Scrivi una pagina di diario in prima persona: descrivi lo sgomento nel trovarti sola senza il tuo gemello, il rimpianto per non avergli stretto la mano un'ultima volta e il patto interiore che stringi con te stessa per sopravvivere.

_________________________________________________________________________________________  
_________________________________________________________________________________________  
_________________________________________________________________________________________  
_________________________________________________________________________________________  
_________________________________________________________________________________________  

---

## 4. Laboratorio Lessicale e Modi di Dire

*Associa ciascun vocabolo o espressione d'autore al suo significato nel contesto del racconto.*

| Termine o Modo di Dire | Abbinamento | Significato Contestuale |
| :--- | :---: | :--- |
| 1. **Sortirovochnaya** | [   ] | A. Quadro sacro dipinto su tavola lignea secondo la tradizione cristiana ortodossa russa. |
| 2. **Carro bestiame** | [   ] | B. Persona che antepone l'interesse comune all'egoismo individuale agendo con lealtà verso i compagni. |
| 3. **Icona** | [   ] | C. Grande scalo ferroviario di smistamento merci dove vengono composti e indirizzati i convogli. |
| 4. **Burocrazia** | [   ] | D. Vagone ferroviario merci non riscaldato e privo di finestrini, riadattato per il trasporto forzato di persone. |
| 5. **Spirito collettivo** | [   ] | E. Insieme rigido di norme, uffici e procedure amministrative che spesso ignora le necessità umane degli individui. |

---

## 5. Attività Speciale "Fuori dagli Schemi"

**Dossier Investigativo / Caccia all'Indizio: Il Mistero della Separazione alla Stazione Sortirovochnaya**  
Immagina di essere un commissario d'inchiesta che deve ricostruire l'incidente della separazione dei gemelli Danilov.  
Redigi un **Rapporto Informativo** che comprenda:
1. La mappa schematica dell'atrio della stazione (l'ingresso sbarrato, il tavolo dei timbri, la colonna con la divisione dei binari 76 e 77).
2. L'esame delle prove materiali: il timbro ad anilina sulla pelle di Nadya (76) e Viktor (77), il foglio esaurito del capostazione, il trucco di Mikhail che ha cancellato il numero.
3. Le testimonianze raccolte: le dichiarazioni di Kostya, Lev e della guardia alla porta.

[SPAZIO PER IL TUO DISEGNO / RILIEVO GRAFICO]

---

### GUIDA E RIASSUNTO PER IL DOCENTE

#### Riassunto sintetico dei capitoli
- **Capitolo 8 (3 luglio 1941):** All'alba il padre dona a Nadya gli orecchini d'argento e a Viktor un'icona antica, raccomandandogli di custodirla con cura. Alla stazione Sortirovochnaya la folla è incontenibile; i genitori vengono bloccati dai soldati. Al tavolo delle registrazioni il funzionario esaurisce i posti del treno 76: a Nadya tocca il 76, a Viktor il 77. Separati brutalmente dalle guardie, i gemelli salgono su convogli distinti.
- **Capitolo 9:** Il treno 77 è formato da carri bestiame bui e sporchi. Affiancando il treno 76 sui binari, Viktor scopre che Mikhail ha cancellato il numero 76 per salire sul 77: la rabbia per lo scambio mancato scatena una rissa furente.
- **Capitolo 10 (4–5 luglio 1941):** In aperta campagna, durante una fermata notturna, Lev tenta di rubare viveri a un bambino; Viktor interviene fermamente e convince tutti a mettere in comune il cibo, supportato da Kostya e Klara. Parlando con Lev, Viktor nomina "Dmitry": la parola d'ordine scioglie l'ostilità del ragazzo, cementando l'intesa del gruppo.

#### Soluzioni ed elementi chiave di correzione
- **1.A Domande aperte:**
  1. *Un'eredità inaspettata:* Da bravo Pioniere Viktor considera la religione una superstizione superata; il padre la consegna come bene prezioso da barattare nei momenti estremi e come memoria familiare.
  2. *La trappola burocratica:* L'anziano funzionario esaurisce i posti del treno 76 proprio tra Nadya e Viktor; le guardie applicano gli ordini alla lettera impedendo qualsiasi eccezione.
  3. *L'inganno di Mikhail:* Mikhail ha alterato il numero per evitare il treno 76; Viktor comprende che al suo posto avrebbe potuto salire lui accanto alla sorella.
  4. *Solidarietà concreta:* Viktor blocca Lev offrendo la propria sacca per primo, dimostrando coerenza con gli ideali e inaugurando la cassa comune.
  5. *Il nome dello "zio Dmitry":* Dmitry è una figura autorevole e temuta nel quartiere operaio; nominarlo conferisce a Viktor rispetto e protezione agli occhi di Lev.
- **1.B Vero o Falso:**
  1. **FALSO.** I genitori vengono fermati ai cancelli dai cordoni armati della Milizia.
  2. **VERO.** Nadya consegna al fratello i quaderni rossi e le matite prima del blocco.
  3. **VERO.** Il treno 77 è un convoglio merci per bestiame (*teplushka*), freddo e privo di servizi.
  4. **VERO.** Kostya assume il ruolo di contabile per la razionalizzazione delle scorte.
  5. **FALSO.** Nessuna razione viene fornita dall'esercito; i ragazzi sopravvivono condividendo il proprio cibo.
- **2. Analisi dei Personaggi:**
  1. *Evoluzione di Viktor:* Il dolore per Nadya si tramuta in responsabilità etica; Viktor impara a dominare l'aggressività e a farsi carico dei più deboli.
  2. *La squadra del vagone:* Kostya garantisce metodo, Lev porta forza e conoscenza della strada, Klara prontezza e senso pratico.
- **3. Officina di Scrittura:** Valutare la sensibilità nel restituire lo smarrimento di Nadya, l'angoscia della solitudine e la risolutezza a non abbattersi.
- **4. Laboratorio Lessicale:** Combinazione corretta: `1-C, 2-D, 3-A, 4-E, 5-B`.
- **5. Attività Speciale:** Verificare la chiarezza investigativa nella ricostruzione spaziale della stazione e l'analisi critica delle testimonianze.
