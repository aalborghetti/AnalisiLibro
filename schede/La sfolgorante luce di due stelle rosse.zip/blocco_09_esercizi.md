# SCHEDA DIDATTICA DI LETTURA E COMPRENSIONE
## *La sfolgorante luce di due stelle rosse* di Davide Morosinotto
### Unità Didattica 9 (Blocco 9): *Capitolo 28* – *Epilogo*

---

**Nome e Cognome dello studente:** ________________________________________  
**Classe:** ____________________  **Data:** ____________________  

---

> ### 🌊 La sfolgorante luce di due stelle rosse
> «Due stelle che brillano vicine nel buio della notte non si perdono mai. Perché la loro luce non viene dal cielo, ma da quello che hanno dentro.»  
> Sulle acque ghiacciate del lago Ladoga e tra le mura leggendarie della fortezza di Oreshek, la lunga separazione giunge al suo compimento. Nel cuore del primo terribile inverno dell'assedio di Leningrado, Viktor e Nadya si ritrovano dove tutto è cominciato: all'Ermitage, custodi fedeli della memoria, della bellezza e della verità storica.

---

## 1. Comprensione del Testo

### A. Domande a risposta aperta
*Rispondi in modo completo, motivando le tue risposte con riferimenti precisi al testo.*

1. **La marcia attraverso il fronte e l'approdo a Shlisselburg:**  
   Nel Capitolo 28 Viktor, Klara e i compagni superstiti raggiungono la regione del lago Ladoga dopo aver oltrepassato linee nemiche e paludi gelate. Come apprendono che i ragazzi del treno 76 non sono morti a Mga, ma si sono asserragliati all'interno della fortezza di Oreshek?
   
_________________________________________________________________________________________  
_________________________________________________________________________________________  
_________________________________________________________________________________________  

2. **La traversata della Neva ghiacciata e l'abbraccio:**  
   Descrivi il drammatico attraversamento del braccio di fiume gelato compiuto da Viktor per raggiungere l'isolotto della fortezza assediata: come avviene il ricongiungimento con Nadya e quale valore simbolico assume la riconsegna dei quaderni rossi?
   
_________________________________________________________________________________________  
_________________________________________________________________________________________  
_________________________________________________________________________________________  

3. **Il bastione d'acciaio nella bufera:**  
   Quali condizioni di vita estreme affrontano i difensori e i ragazzi all'interno di Oreshek durante i cinquecento giorni di bombardamenti tedeschi e come riescono a resistere senza mai cedere il forte agli invasori?
   
_________________________________________________________________________________________  
_________________________________________________________________________________________  
_________________________________________________________________________________________  

4. **Il ritorno a Leningrado e l'Ermitage ferito:**  
   Nell'Epilogo i gemelli compiono la traversata della celebre "Strada della Vita" sul lago Ladoga congelato per rientrare a Leningrado. Cosa trovano all'interno del Museo dell'Ermitage ghiacciato e quale triste e gloriosa notizia apprendono sul destino del loro papà?
   
_________________________________________________________________________________________  
_________________________________________________________________________________________  
_________________________________________________________________________________________  

5. **Il verdetto finale del colonnello Smirnov:**  
   Nel dicembre 1946, terminata la lettura approfondita di tutti i quaderni, il colonnello Valery Smirnov prende la sua decisione definitiva. Quale dei due timbri di legno imprime sui verbali dell'NKVD e quale profonda motivazione morale guida il suo verdetto?
   
_________________________________________________________________________________________  
_________________________________________________________________________________________  
_________________________________________________________________________________________  

---

### B. Vero o Falso? (Attenzione ai dettagli)
*Indica se l'affermazione è Vera [V] o Falsa [F]. Se è Falsa, correggila brevemente sulle righe sottostanti.*

| Affermazione | V | F |
| :--- | :---: | :---: |
| 1. La guarnigione sovietica asserragliata nella fortezza di Oreshek si arrende alle truppe tedesche poche settimane dopo l'inizio dell'assedio. | [ ] | [ ] |
| 2. Rivedendosi nei sotterranei della fortezza, Viktor e Nadya riconoscono subito la scrittura blu e rossa incrociata sulle pagine dei diari. | [ ] | [ ] |
| 3. La cosiddetta "Strada della Vita" era una pista tracciata sulla spessa coltre di ghiaccio del lago Ladoga per rifornire la popolazione assediata di Leningrado. | [ ] | [ ] |
| 4. Al rientro nella loro città, i gemelli riabbracciano il padre che li accoglie intatto e festante nelle sale monumentali del museo. | [ ] | [ ] |
| 5. Al termine dell'indagine nel 1946, il colonnello Smirnov imprime il timbro "Innocente" riconoscendo l'autentico valore morale e umano della testimonianza dei ragazzi. | [ ] | [ ] |

**Correzione delle affermazioni false:**  
_________________________________________________________________________________________  
_________________________________________________________________________________________  
_________________________________________________________________________________________  

---

## 2. Analisi dei Personaggi e Riflessione

1. **Il senso di una promessa mantenuta:**  
   All'inizio del romanzo il padre aveva chiesto a Viktor di proteggere la sorella e ai due gemelli di non separarsi mai. Analizza come quella promessa, infranta dal caso burocratico alla stazione Sortirovochnaya, sia diventata la bussola etica che ha guidato entrambi attraverso mille chilometri di orrori senza smarrire l'umanità.
   
_________________________________________________________________________________________  
_________________________________________________________________________________________  
_________________________________________________________________________________________  

2. **La scrittura come scudo contro la barbarie:**  
   I quaderni rossi di Viktor e Nadya sopravvivono alle bombe, al fango del kolkhoz, al filo spinato del Gulag e all'inquisizione dell'NKVD. Quale messaggio trasmette l'autore sul potere della parola scritta e della memoria storica rispetto alla violenza cieca della guerra?
   
_________________________________________________________________________________________  
_________________________________________________________________________________________  
_________________________________________________________________________________________  

---

## 3. Officina di Scrittura Creativa ed Empatia

*Mettiti nei panni di uno dei protagonisti.*

Immagina di essere **Viktor e Nadya** seduti insieme su una panca di legno nelle sale vuote e ghiacciate dell'Ermitage, nel dicembre 1941, durante il primo rigido inverno dell'assedio. Fuori scendono i fiocchi di neve sulla piazza del Palazzo d'Inverno e nella penombra illuminate il quaderno aperto con una candela. Scrivi la pagina conclusiva del diario a quattro mani: alternate la voce di Nadya (in blu, introspettiva e poetica) e quella di Viktor (in rosso, pragmatica e risoluta), ripercorrendo il cammino compiuto e rinnovando la fede nella vittoria della vita.

_________________________________________________________________________________________  
_________________________________________________________________________________________  
_________________________________________________________________________________________  
_________________________________________________________________________________________  
_________________________________________________________________________________________  

---

## 4. Laboratorio Lessicale e Modi di Dire

*Associa ciascun vocabolo o espressione d'autore al suo significato nel contesto del racconto.*

| Termine o Modo di Dire | Abbinamento | Significato Contestuale |
| :--- | :---: | :--- |
| 1. **Strada della Vita** | [   ] | A. Conclusione narrativa di un'opera letteraria in cui si sciolgono i nodi della trama e si rivela il destino dei personaggi. |
| 2. **Epilogo** | [   ] | B. Camminamento scavato nel terreno a ridosso del fronte difensivo per consentire la manovra protetta dei combattenti. |
| 3. **Strada gelata (Ladoga)** | [   ] | C. Pista invernale aperta sulla crosta ghiacciata del lago Ladoga per recare farina, viveri e medicinali agli assediati. |
| 4. **Baluardo** | [   ] | D. Pronuncia solenne e motivata con cui un'autorità giudiziaria conclude un'istruttoria dichiarando la colpevolezza o l'innocenza. |
| 5. **Verdetto** | [   ] | E. Punto di resistenza fortificato o baluardo insormontabile che respinge con tenacia l'urto delle truppe nemiche. |

---

## 5. Attività Speciale "Fuori dagli Schemi"

**Dossier Investigativo / Caccia all'Indizio: L'Archiviazione del Caso Danilov (Leningrado, Dicembre 1946)**  
Sulla scrivania del colonnello Valery Gavriilovich Smirnov giacciono i quaderni macchiati di inchiostro, sangue e fango, insieme alle perizie grafologiche e alle note informative.  
Componi la **Relazione Finale d'Ufficio** dell'inquirente:
1. *I capi d'accusa estinti:* spiega perché reati formali come l'evasione dal campo di Rybinsk, l'uso di documenti falsi e il disfattismo vengono sanati dall'insussistenza del dolo e dal supremo valore civile dimostrato dai ragazzi.
2. *La valutazione della testimonianza:* descrivi come la voce limpida dei due gemelli abbia convinto il funzionario della loro totale lealtà alla verità e alla memoria patria.
3. Disegna nel riquadro sottostante il **Fascicolo Ministeriale dell'NKVD** con l'impronta scarlatta del timbro finale **«INNOCENTE»** e la firma autografa del colonnello Smirnov.

[SPAZIO PER IL TUO DISEGNO / RILIEVO GRAFICO]

---

### GUIDA E RIASSUNTO PER IL DOCENTE

#### Riassunto sintetico dei capitoli
- **Capitolo 28 (novembre 1941 - Viktor e Nadya):** Viktor, Klara e i superstiti della brigata superano le linee tedesche tra le paludi ghiacciate e approdano a Shlisselburg, appurando che la chiesa di San Nicola è distrutta ma che la guarnigione sovietica e i ragazzi superstiti del treno 76 resistono imperterriti nella fortezza di Oreshek. Con una traversata notturna sulla crosta ghiacciata della Neva battuta dalle mitragliatrici nemiche, Viktor raggiunge i sotterranei dell'isola e riabbraccia Nadya, riconsegnandole i quaderni rossi.
- **Epilogo e Conclusione:** Oreshek resiste per quasi 500 giorni di assedio ininterrotto, proteggendo la riva meridionale del lago. Durante il rigido inverno del 1941-42 i ragazzi vengono evacuati attraverso la "Strada della Vita" sul lago Ladoga ghiacciato e fanno ritorno a Leningrado. All'Ermitage ritrovano la madre stremata e il direttore Orbeli tra i saloni deserti e gelidi; apprendono che il padre è caduto da eroe nei ranghi della Milizia Popolare difendendo le trincee di Pulkovo.
- **Cornice Giudiziaria (Leningrado, 24 dicembre 1946):** Il colonnello Smirnov dell'NKVD termina l'esame dei quaderni. Consapevole delle contraddizioni del regime ma profondamente commosso dall'onestà, dalla fratellanza e dal sacrificio di Viktor e Nadya, ripone il timbro "Colpevole" e imprime con fermezza il timbro **«INNOCENTE»**, secretando il fascicolo e salvando i gemelli dalla repressione staliniana.

#### Soluzioni ed elementi chiave di correzione
- **1.A Domande aperte:**
  1. *L'approdo a Shlisselburg:* Scorgono la fortezza di Oreshek isolata tra le acque che continua a sparare contro le postazioni naziste, capendo che i compagni hanno trovato scampo sull'isolotto.
  2. *La traversata della Neva:* Viktor avanza carponi sul ghiaccio sottile sfidando i proiettori tedeschi; il ricongiungimento sancisce il trionfo della lealtà fraterna sulla disgregazione della guerra.
  3. *Il bastione d'acciaio:* I difensori patiscono il congelamento, la penuria estrema di cibo e il fuoco incessante dei mortai, ma la posizione insulare e la determinazione collettiva impediscono ai nazisti di espugnare la rocca.
  4. *L'Ermitage ferito:* Trovano i saloni gelati con le cornici vuote alle pareti e la madre provata ma viva; apprendono il sacrificio del padre caduto al fronte a difesa della città.
  5. *Il verdetto di Smirnov:* Sceglie il timbro "Innocente" poiché riconosce che i presunti reati furono imposti dallo stato di necessità e che la testimonianza dei ragazzi incarna la parte migliore e più nobile della nazione.
- **1.B Vero o Falso:**
  1. **FALSO.** La fortezza di Oreshek non capitola mai resistendo a oltranza per quasi cinquecento giorni.
  2. **VERO.** I due colori d'inchiostro sovrapposti confermano la ricomposizione del diario comune.
  3. **VERO.** La "Strada della Vita" sul Ladoga consentì il transito dei camion di soccorso durante il blocco.
  4. **FALSO.** Il padre muore in combattimento nelle trincee della Milizia Popolare.
  5. **VERO.** Smirnov archivia il caso con la formula di piena innocenza.
- **2. Analisi dei Personaggi:**
  1. *Il valore della promessa:* Il patto infantile si sublima in imperativo categorico: la fedeltà al fratello diventa scudo contro la barbarie e motivo di riscatto per tutti i compagni di viaggio.
  2. *La scrittura e la memoria:* Il diario rappresenta l'affermazione della verità soggettiva contro la propaganda di Stato e la violenza della guerra: finché c'è testimonianza, la persona non è cancellata.
- **3. Officina di Scrittura:** Verificare la capacità di intrecciare le due voci (il lirismo sensibile di Nadya e la concretezza protettiva di Viktor) sullo sfondo della Leningrado assediata.
- **4. Laboratorio Lessicale:** Combinazione corretta: `1-C, 2-A, 3-C, 4-E, 5-D` (o `3-B` per trincea).
- **5. Attività Speciale:** Valutare la coerenza giuridica e storica della motivazione dell'inquirente e l'efficacia visiva del dossier ministeriale con il timbro di innocenza.
