# SCHEDA DIDATTICA DI LETTURA E COMPRENSIONE
## *La sfolgorante luce di due stelle rosse* di Davide Morosinotto
### Unità Didattica 9 (Blocco 9): *Capitolo 28* – *Epilogo*

---

**Nome e Cognome dello studente:** ________________________________________  
**Classe:** ____________________  **Data:** ____________________  

---

> ### 🌊 La sfolgorante luce di due stelle rosse
> «Due stelle che brillano vicine nel buio della notte non si perdono mai. Perché la loro luce non viene dal cielo, ma da quello che hanno dentro.»  
> Sulle acque ghiacciate del lago Ladoga e tra le mura leggendarie della fortezza di Oreshek, la lunga separazione giunge al suo compimento. Nel cuore del primo terribile inverno dell'assedio di Leningrado, Viktor e Nadya si ritrovano dove tutto è cominciato: all'Ermitage, custodi fedeli della memoria, della bellezza e della verità storica.

---

## 1. Comprensione del Testo

### A. Domande a risposta aperta
*Rispondi sul tuo quaderno in modo chiaro e completo, facendo riferimento a ciò che hai letto nel testo.*

1. **L'approdo a Shlisselburg:**  
   Nel Capitolo 28 Viktor, Klara e i compagni superstiti raggiungono la regione del lago Ladoga dopo una marcia faticosa tra fango e paludi gelate. Come scoprono che Nadya e gli altri ragazzi del treno 76 sono vivi dentro la fortezza di Oreshek?

2. **La traversata sul fiume gelato e l'abbraccio:**  
   Racconta la notte in cui Viktor attraversa a carponi la superficie ghiacciata della Neva per raggiungere la fortezza isolata: come avviene il ricongiungimento con Nadya e cosa significa per loro riavere tra le mani i quaderni rossi?

3. **Cinquecento giorni di resistenza:**  
   Quali condizioni di vita estreme affrontano i difensori e i ragazzi dentro Oreshek durante i cinquecento giorni di assedio ininterrotto e come riescono a resistere senza mai cedere la fortezza?

4. **Il ritorno a Leningrado e l'Ermitage ferito:**  
   Nell'Epilogo i gemelli compiono la traversata della celebre "Strada della Vita" sul lago Ladoga congelato per rientrare a Leningrado. Chi ritrovano al Museo dell'Ermitage e quale triste ma gloriosa notizia apprendono sul loro papà?

5. **Il verdetto finale del colonnello Smirnov:**  
   Nel dicembre 1946, dopo aver letto attentamente tutti i quaderni, il colonnello Smirnov prende la sua decisione definitiva. Quale dei due timbri imprime sui verbali dell'NKVD e quale profonda motivazione morale guida la sua scelta?

---

### B. Vero o Falso? (Attenzione ai dettagli)
*Indica se ciascuna affermazione è Vera (V) o Falsa (F). Correggi le affermazioni false sul tuo quaderno.*

| Affermazione | V | F |
| :--- | :---: | :---: |
| 1. La guarnigione sovietica asserragliata nella fortezza di Oreshek si arrende alle truppe nemiche poche settimane dopo l'inizio dell'assedio. | | |
| 2. Rivedendosi nei sotterranei della fortezza, Viktor e Nadya ricominciano a scrivere insieme sui quaderni incrociando l'inchiostro blu e rosso. | | |
| 3. La celebre "Strada della Vita" era una pista tracciata sulla spessa coltre di ghiaccio del lago Ladoga per rifornire la popolazione assediata di Leningrado. | | |
| 4. Al rientro nella loro città, i gemelli riabbracciano il padre che li accoglie sano e salvo nelle sale monumentali del museo. | | |
| 5. Al termine dell'indagine nel 1946, il colonnello Smirnov imprime il timbro "Innocente" riconoscendo il valore morale e umano del diario dei ragazzi. | | |

---

## 2. Analisi dei Personaggi e Riflessione
*Rispondi alle seguenti domande sul tuo quaderno, riflettendo bene sui comportamenti dei protagonisti.*

1. **Il senso di una promessa mantenuta:**  
   All'inizio del romanzo il papà aveva chiesto a Viktor di proteggere la sorella e ai due gemelli di restare uniti. In che modo quella promessa ha aiutato entrambi a superare pericoli spaventosi senza perdere mai il coraggio e l'umanità?

2. **La forza della memoria e della scrittura:**  
   I quaderni rossi di Viktor e Nadya sono sopravvissuti alle bombe, al fango, al filo spinato del campo di lavoro e alle indagini della polizia segreta. Secondo te perché per l'autore è così importante ricordare che la parola scritta può sconfiggere la violenza e la dimenticanza?

---

## 3. Officina di Scrittura Creativa ed Empatia
*Svolgi la seguente attività di scrittura sul tuo quaderno.*

Immagina di trovarti nelle sale vuote e ghiacciate dell'Ermitage nel dicembre 1941, durante il primo rigidissimo inverno dell'assedio, mentre fuori scendono i fiocchi di neve sulla piazza del Palazzo d'Inverno e una candela illumina il quaderno. Scegli se immedesimarti nella voce di **Viktor** (con la matita rossa, concreto e protettivo) oppure in quella di **Nadya** (con la penna blu, riflessiva e attenta ai sentimenti) mentre siede accanto al fratello: scrivi sul tuo quaderno la pagina conclusiva del diario, ripensando al lungo cammino percorso per ritrovarvi e rinnovando la fede nella speranza e nella vita. *(Se preferisci, puoi anche svolgere l'attività a quattro mani con un compagno, alternando le due voci!).*

---

## 4. Laboratorio Lessicale e Modi di Dire
*Associa ciascun vocabolo o espressione d'autore al suo significato nel contesto del racconto (indica sul quaderno la combinazione corretta numero-lettera).*

| Termine o Modo di Dire | Abbinamento | Significato Contestuale |
| :--- | :---: | :--- |
| 1. **Strada della Vita** | | A. Parte conclusiva di un libro in cui si tirano le somme della vicenda e si svela il destino finale dei personaggi. |
| 2. **Epilogo** | | B. Camminamento scavato nel terreno a ridosso del fronte per consentire il passaggio protetto dei soldati. |
| 3. **Camminamento di trincea** | | C. Pista invernale aperta sulla crosta ghiacciata del lago Ladoga per portare farina e soccorsi agli assediati. |
| 4. **Baluardo** | | D. Decisione finale e solenne con cui un'autorità giudiziaria conclude un'indagine dichiarando l'innocenza o la colpevolezza. |
| 5. **Verdetto** | | E. Punto di difesa fortificato o roccaforte che resiste con tenacia all'assalto nemico. |

---

## 5. Attività Speciale "Fuori dagli Schemi"

**La Decisione Finale del Colonnello Smirnov (Leningrado, Dicembre 1946)**  
Sulla scrivania del colonnello Smirnov ci sono i quaderni macchiati di inchiostro, sangue e fango, insieme alle perizie e alle note informative.  
Componi sul tuo quaderno la **Dichiarazione Ufficiale di Chiusura dell'Inchiesta**:
1. *I chiarimenti sulle accuse:* spiega perché i ragazzi non sono né spie né nemici dello Stato, ma solo giovani coraggiosi che hanno cercato di sopravvivere alla guerra;
2. *Cosa ti ha colpito:* descrivi cosa ha commosso l'ufficiale leggendo le parole scritte da Viktor e Nadya e la loro lealtà reciproca;
3. *Il verdetto:* disegna sul tuo quaderno l'impronta del timbro rettangolare **«INNOCENTE»** e apponi la firma del colonnello Smirnov.

---

### GUIDA E RIASSUNTO PER IL DOCENTE

#### Riassunto sintetico dei capitoli
- **Capitolo 28 (novembre 1941 - Viktor e Nadya):** Viktor, Klara e i superstiti della brigata superano le linee tedesche tra le paludi ghiacciate e approdano a Shlisselburg, appurando che la chiesa di San Nicola è distrutta ma che la guarnigione sovietica e i ragazzi superstiti del treno 76 resistono imperterriti nella fortezza di Oreshek. Con una traversata notturna sulla crosta ghiacciata della Neva battuta dalle mitragliatrici nemiche, Viktor raggiunge i sotterranei dell'isola e riabbraccia Nadya, riconsegnandole i quaderni rossi.
- **Epilogo e Conclusione:** Oreshek resiste per quasi 500 giorni di assedio ininterrotto, proteggendo la riva meridionale del lago. Durante il rigido inverno del 1941-42 i ragazzi vengono evacuati attraverso la "Strada della Vita" sul lago Ladoga ghiacciato e fanno ritorno a Leningrado. All'Ermitage ritrovano la madre stremata e il direttore Orbeli tra i saloni deserti e gelidi; apprendono che il padre è caduto da eroe nei ranghi della Milizia Popolare difendendo le trincee di Pulkovo.
- **Cornice Giudiziaria (Leningrado, 24 dicembre 1946):** Il colonnello Smirnov dell'NKVD termina l'esame dei quaderni. Consapevole delle contraddizioni del regime ma profondamente commosso dall'onestà, dalla fratellanza e dal sacrificio di Viktor e Nadya, ripone il timbro "Colpevole" e imprime con fermezza il timbro **«INNOCENTE»**, secretando il fascicolo e salvando i gemelli dalla repressione staliniana.

#### Soluzioni ed elementi chiave di correzione
- **1.A Domande aperte:**
  1. *L'approdo a Shlisselburg:* Scorgono la fortezza di Oreshek circondata dalle acque che continua a sparare contro le postazioni tedesche, capendo che i compagni hanno trovato rifugio sull'isolotto.
  2. *La traversata della Neva:* Viktor avanza sul ghiaccio sottile sfidando i proiettori nemici; il ricongiungimento sancisce la vittoria della fedeltà fraterna sulla violenza della guerra.
  3. *Cinquecento giorni di resistenza:* I difensori sopportano il freddo siberiano, la fame estrema e i continui tiri d'artiglieria, ma la posizione isolata e il coraggio collettivo impediscono la caduta del forte.
  4. *Il ritorno all'Ermitage:* Trovano i saloni gelati con le cornici vuote e la madre provata ma viva; apprendono che il padre è caduto da eroe nelle trincee della Milizia Popolare.
  5. *Il verdetto di Smirnov:* Sceglie il timbro "Innocente" riconoscendo che i ragazzi hanno agito per pura necessità e incarnano la parte più nobile della nazione.
- **1.B Vero o Falso:**
  1. **FALSO.** La fortezza di Oreshek non capitola mai resistendo a oltranza per quasi cinquecento giorni.
  2. **VERO.** I due colori d'inchiostro sovrapposti confermano la ricomposizione del diario comune.
  3. **VERO.** La "Strada della Vita" sul Ladoga permise il transito dei camion di soccorso durante il blocco.
  4. **FALSO.** Il padre muore in combattimento nelle trincee difensive della città.
  5. **VERO.** Smirnov archivia il caso con la formula di piena innocenza.
- **2. Analisi dei Personaggi:**
  1. *Il valore della promessa:* Il patto stretto prima della partenza diventa una guida morale: la lealtà al fratello dà la forza di non arrendersi e riscatta anche i compagni di viaggio.
  2. *La memoria e la scrittura:* Il diario rappresenta il trionfo della testimonianza e della dignità umana contro la violenza della guerra e la censura del regime.
- **3. Officina di Scrittura:** Verificare la capacità di far emergere la voce scelta (il tono riflessivo di Nadya o la determinazione protettiva di Viktor, oppure l'armonia delle due voci alternate), la consapevolezza del valore della riunione familiare e il contrasto tra il gelo della guerra e il calore del loro legame.
- **4. Laboratorio Lessicale:** Combinazione corretta: `1-C, 2-A, 3-B, 4-E, 5-D`.
- **5. Attività Speciale:** Valutare la sensibilità nel cogliere il cambiamento del colonnello e la chiarezza nell'argomentare l'innocenza dei gemelli.
