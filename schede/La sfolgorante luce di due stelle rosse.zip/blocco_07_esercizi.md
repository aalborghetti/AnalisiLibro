# SCHEDA DIDATTICA DI LETTURA E COMPRENSIONE
## *La sfolgorante luce di due stelle rosse* di Davide Morosinotto
### Unità Didattica 7 (Blocco 7): *Capitolo 20* – *Capitolo 23*

---

**Nome e Cognome dello studente:** ________________________________________  
**Classe:** ____________________  **Data:** ____________________  

---

> ### 🌊 Sotto la pioggia di ferro e fuoco a Shlisselburg
> «Ogni cosa è distrutta. Ma io sono ancora viva. Aspetterò sotto la prima neve, come la brace nascosta da un velo di cenere. Io sono Nadya. E sono qui.»  
> Quando gli aerei e i carri armati tedeschi assaltano Shlisselburg, per i sopravvissuti del treno 76 comincia la prova più straziante. Tra le macerie della chiesa di San Nicola e la paura dell'occupazione nemica, la promessa di Viktor di andarla a cercare diventa per Nadya l'unico raggio di luce nel buio della guerra.

---

## 1. Comprensione del Testo

### A. Domande a risposta aperta
*Rispondi sul tuo quaderno in modo chiaro e completo, facendo riferimento a ciò che hai letto nel testo.*

1. **La certezza di Nadya:**  
   Nel Capitolo 20 Nadya spiega perché è assolutamente sicura che Viktor sia in viaggio per cercarla. Quale ragionamento fa la ragazza riflettendo sulla falsa notizia del bombardamento del treno 76 sentita alla radio?

2. **L'ospedale nella cattedrale:**  
   Con l'arrivo dei soldati della 48ª Armata, Shlisselburg diventa la prima linea del fronte. Quale compito svolge Nadya accanto ai medici militari e cosa le spiega l'ufficiale con gli occhiali mostrando le cartine dell'accerchiamento?

3. **La notte dell'attacco su San Nicola:**  
   La notte del 7 settembre l'aviazione nemica colpisce duramente la chiesa di San Nicola. In che modo fortunato Nadya, Boris, Anna e Lilya scampano alla morte e cosa vedono all'uscita dal rifugio?

4. **L'appello dei ventiquattro nel fienile:**  
   Fuggiti dal villaggio in fiamme, i superstiti trovano riparo in un fienile diroccato vicino al fiume. Per quale motivo Nadya decide di scrivere con cura sul quaderno l'elenco nominativo di tutti i presenti?

5. **I dubbi del colonnello Smirnov:**  
   Nel rapporto che chiude il Terzo Quaderno (dicembre 1946), cosa prova l'ufficiale Smirnov davanti al diario di Nadya? Perché fa fatica a considerarla colpevole?

---

### B. Vero o Falso? (Attenzione ai dettagli)
*Indica se ciascuna affermazione è Vera (V) o Falsa (F). Correggi le affermazioni false sul tuo quaderno.*

| Affermazione | V | F |
| :--- | :---: | :---: |
| 1. Salita in cima all'edificio, Nadya vede all'orizzonte i lampi luminosi dell'artiglieria che investe la periferia di Leningrado. | | |
| 2. I soldati della 48ª Armata scappano all'alba senza offrire alcuna resistenza all'avanzata delle truppe corazzate nemiche. | | |
| 3. Nadya e i suoi compagni evitano il crollo della chiesa perché si erano arrampicati su una solida libreria nello studio del parroco. | | |
| 4. La giovane mamma Irina e il piccolo Pyotr arrivano sani e salvi a Mosca dopo aver superato le linee nemiche. | | |
| 5. Nel rifugio del fienile Nadya ribadisce con forza sul diario la certezza che Viktor arriverà presto a prenderla. | | |

---

## 2. Analisi dei Personaggi e Riflessione
*Rispondi alle seguenti domande sul tuo quaderno, riflettendo bene sui comportamenti dei protagonisti.*

1. **Nadya diventa grande:**  
   A Shlisselburg Nadya non è più la ragazzina spensierata delle vacanze estive: medica i soldati feriti, protegge i più piccoli e tiene viva la speranza di tutti. In che modo queste esperienze dolorose fanno maturare il suo carattere?

2. **Il dilemma del colonnello Smirnov:**  
   Il colonnello dell'NKVD è un uomo severo abituato a cercare nemici dello Stato ovunque. Perché leggendo le parole limpide e sincere di Nadya comincia a provare rispetto e commozione per lei?

---

## 3. Officina di Scrittura Creativa ed Empatia
*Svolgi la seguente attività di scrittura sul tuo quaderno.*

Immagina di essere **Boris** nel fienile diroccato vicino al fiume, subito dopo il terribile bombardamento della chiesa. Hai protetto Nadya facendola scendere dalla libreria e hai recuperato i quaderni rossi dalle macerie fumanti. Scrivi sul tuo quaderno una pagina di riflessione in prima persona: racconta la paura vissuta durante il crollo, cosa provi a essere diventato lo scudo protettivo dei tuoi compagni e la speranza di rivedere un giorno la pace.

---

## 4. Laboratorio Lessicale e Modi di Dire
*Associa ciascun vocabolo o espressione d'autore al suo significato nel contesto del racconto (indica sul quaderno la combinazione corretta numero-lettera).*

| Termine o Modo di Dire | Abbinamento | Significato Contestuale |
| :--- | :---: | :--- |
| 1. **Panzer** | | A. Condizione di blocco militare totale in cui una città viene circondata dal nemico per prenderla per fame. |
| 2. **Retrovie** | | B. Temuto carro armato pesante dell'esercito tedesco, dotato di corazza spessa e cannone potente. |
| 3. **Assedio** | | C. Ispezione metodica casa per casa compiuta da soldati nemici per catturare o eliminare partigiani. |
| 4. **Ospedale da campo** | | D. Zona situata alle spalle della prima linea del fronte, adibita all'alloggio, ai rifornimenti e ai comandi. |
| 5. **Rastrellamento** | | E. Presidio medico di emergenza allestito in fretta vicino al fronte per prestare le prime cure ai feriti. |

---

## 5. Attività Speciale "Fuori dagli Schemi"

**La Mappa Strategica del Basso Ladoga**  
Nel Blocco 7 la geografia di guerra decide il destino di milioni di persone: l'occupazione di Mga e l'assalto a Shlisselburg chiudono la morsa attorno a Leningrado.  
Disegna sul tuo quaderno una **Mappa Strategica dell'Area del Basso Ladoga**:
1. *I punti geografici:* traccia la riva meridionale del grande **lago Ladoga** e l'inizio del fiume **Neva** che scorre verso Leningrado;
2. *I luoghi chiave:* posiziona la stazione di **Mga**, il paese di **Shlisselburg** e l'isolotto con la fortezza di **Oreshek**;
3. *I movimenti e i rifugi:* indica con frecce l'avanzata delle truppe corazzate tedesche e cerchia il fienile dove si sono nascosti i ventiquattro superstiti. Aggiungi una legenda chiara.

---

### GUIDA E RIASSUNTO PER IL DOCENTE

#### Riassunto sintetico dei capitoli
- **Capitolo 20 (20–25 agosto 1941 - Nadya):** Nadya deduce che Viktor, saputo del trafiletto sul treno 76, non accetterà mai la sua morte e verrà a cercarla. A Shlisselburg comincia l'evacuazione civile; la notte del 25 agosto le bombe colpiscono la periferia di Leningrado. Dalla sommità della chiesa Nadya osserva i bagliori del fronte.
- **Capitolo 21 (26–27 agosto 1941):** I fanti della 48ª Armata allestiscono il quartier generale e l'ospedale nella cattedrale. Nadya funge da "infermierina" medicando i feriti, mentre un tenente le illustra sulle carte l'imminente chiusura della sacca di Leningrado da parte delle divisioni corazzate naziste.
- **Capitolo 22 (Viktor):** Viktor rievoca parallelamente la fuga da Kazan con Klara, Lev, Flavio e Mikhail, la sosta caotica a Mosca e il tragico equivoco ferroviario che li catapulta come forzati nel Gulag di Rybinsk, da cui riescono a evadere nella notte scavando un tunnel e rifugiandosi nelle latrine per sviare i segugi dell'NKVD.
- **Capitolo 23 (7–9 settembre 1941 - Nadya) e Rapporto NKVD:** I bombardieri tedeschi sventrano la sagrestia di San Nicola; Nadya, Boris, Anna e Lilya si salvano per miracolo nell'ufficio parrocchiale. Il villaggio cade sotto i rastrellamenti nazisti. Nadya e i sopravvissuti riparano in un fienile semidiroccato: lì compila la lista dei 24 scampati, giurando fiducia in Viktor. Smirnov chiude il Terzo Quaderno riconoscendo la tragica grandezza delle memorie ma rimandando il verdetto.

#### Soluzioni ed elementi chiave di correzione
- **1.A Domande aperte:**
  1. *La certezza di Nadya:* Sa che Viktor conosce il numero del convoglio (76); credendo nella loro speciale intesa, è sicura che considererà falsa la notizia ufficiale e si metterà sulle sue tracce.
  2. *L'ospedale nella cattedrale:* Nadya disinfetta le ferite, lava le bende e conforta i soldati; l'ufficiale le mostra che la caduta di Shlisselburg isolerà completamente Leningrado.
  3. *La notte dell'attacco su San Nicola:* Si salvano perché Boris e Nadya erano saliti sulla libreria dello studio del parroco; uscendo trovano polvere soffocante, crateri di bombe e distruzione.
  4. *L'appello dei ventiquattro:* Registra i nomi dei superstiti affinché rimanga testimonianza della loro esistenza nel caso venissero scoperti dalle pattuglie nemiche.
  5. *I dubbi del colonnello Smirnov:* L'inquirente è toccato dalla dignità e dalla sincerità del racconto; il diario fa vacillare le sue certezze burocratiche.
- **1.B Vero o Falso:**
  1. **VERO.** Dalla sommità della chiesa scorge il cielo notturno illuminato dalle esplosioni.
  2. **FALSO.** La guarnigione sovietica resiste con grande coraggio e difende i feriti fino alla fine.
  3. **VERO.** La posizione sopraelevata sulla libreria li ripara dalle travi che crollano.
  4. **FALSO.** Irina e il bambino vengono colpiti a morte da un'esplosione durante la fuga.
  5. **VERO.** Nadya chiude il terzo quaderno ribadendo la certezza che il fratello la troverà.
- **2. Analisi dei Personaggi:**
  1. *Nadya:* La sofferenza la fa crescere in fretta: supera la paura per farsi carico dei più deboli, diventando una presenza rassicurante per tutti.
  2. *Smirnov:* La freddezza del funzionario di polizia entra in crisi di fronte all'eroismo genuino e all'onestà dei due ragazzi.
- **3. Officina di Scrittura:** Verificare la resa introspettiva di Boris: senso di protezione paterna, orgoglio per aver aiutato i compagni e speranza nella pace.
- **4. Laboratorio Lessicale:** Combinazione corretta: `1-B, 2-D, 3-A, 4-E, 5-C`.
- **5. Attività Speciale:** Valutare la correttezza della mappa (Ladoga, Neva, Mga, Shlisselburg) e la precisione della legenda.
