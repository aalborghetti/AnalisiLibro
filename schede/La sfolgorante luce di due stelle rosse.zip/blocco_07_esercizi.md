# SCHEDA DIDATTICA DI LETTURA E COMPRENSIONE
## *La sfolgorante luce di due stelle rosse* di Davide Morosinotto
### Unità Didattica 7 (Blocco 7): *Capitolo 20* – *Capitolo 23*

---

**Nome e Cognome dello studente:** ________________________________________  
**Classe:** ____________________  **Data:** ____________________  

---

> ### 🌊 Sotto la pioggia di ferro e fuoco a Shlisselburg
> «Ogni cosa è distrutta. Ma io sono ancora viva. Aspetterò sotto la prima neve, come la brace nascosta da un velo di cenere. Io sono Nadya. E sono qui.»  
> Quando i bombardieri Junkers e i carri armati tedeschi assaltano Shlisselburg, per i sopravvissuti del treno 76 comincia la prova più straziante. Tra le macerie fumanti della chiesa di San Nicola e la paura dell'occupazione nemica, la promessa di Viktor di andarla a cercare diventa per Nadya l'unico raggio di luce nel buio della guerra.

---

## 1. Comprensione del Testo

### A. Domande a risposta aperta
*Rispondi sul tuo quaderno in modo completo, motivando le tue risposte con riferimenti precisi al testo.*

1. **La deduzione logica di Nadya:**  
   Nel Capitolo 20 Nadya spiega per quale ragione è assolutamente certa che Viktor sia in viaggio per cercarla. Quale ragionamento affettivo e razionale compie la ragazza riguardo alla notizia del bombardamento del treno 76 diffusa dalla radio?

2. **L'ospedale da campo nella cattedrale:**  
   Con l'arrivo della 48ª Armata, Shlisselburg si trasforma da retrovia a prima linea. Quale ruolo assume Nadya accanto ai medici militari e cosa le spiega l'ufficiale con gli occhiali d'oro mostrando le mappe dell'accerchiamento?

3. **La notte dell'attacco su San Nicola:**  
   La notte del 7 settembre l'aviazione tedesca demolisce la chiesa di San Nicola. In che modo fortunoso Nadya, Boris, Anna e Lilya scampano alla morte e quale desolazione si trovano davanti all'uscita dal rifugio?

4. **L'appello dei ventiquattro nella cascina:**  
   Fuggiti dal centro del villaggio in fiamme, i superstiti trovano ricovero in un fienile diroccato lungo il fiume. Per quale motivo Nadya decide di compilare meticolosamente sul quaderno l'elenco nominativo di tutti i presenti?

5. **Il tormento del colonnello Smirnov:**  
   Nel rapporto che chiude il Terzo Quaderno (dicembre 1946), Smirnov riflette sul diario di Nadya. Quale profondo dilemma morale traspare dalle sue annotazioni di fronte ai due timbri posti sulla scrivania?

---

### B. Vero o Falso? (Attenzione ai dettagli)
*Indica se ciascuna affermazione è Vera (V) o Falsa (F). Correggi le affermazioni false sul tuo quaderno.*

| Affermazione | V | F |
| :--- | :---: | :---: |
| 1. Arrampicatasi sulla cima dell'edificio, Nadya scorge all'orizzonte i lampi luminosi dell'artiglieria che investe la periferia di Leningrado. | | |
| 2. I soldati della 48ª Armata si danno alla fuga all'alba senza offrire alcuna resistenza all'avanzata delle truppe corazzate nemiche. | | |
| 3. Nadya e i suoi compagni evitano il crollo della sagrestia perché si erano spostati nello studio del pope per osservare l'esterno. | | |
| 4. La giovane madre Irina e il piccolo Pyotr giungono sani e salvi a Mosca dopo aver attraversato le linee tedesche. | | |
| 5. Nel rifugio del fienile Nadya ribadisce con forza sul diario la certezza che Viktor arriverà presto a prenderla. | | |

---

## 2. Analisi dei Personaggi e Riflessione
*Rispondi alle seguenti domande sul tuo quaderno, analizzando a fondo i personaggi e motivando le tue considerazioni.*

1. **La trasformazione di Nadya (La forza morale del gruppo):**  
   A Shlisselburg Nadya non è più la ragazzina spensierata delle vacanze estive: presta soccorso ai soldati agonizzanti, protegge i più piccoli e tiene viva la speranza. In che modo la vicinanza della morte forgia la sua tempra e ne fa una guida autorevole?

2. **La frattura interiore del colonnello Smirnov:**  
   Leggendo le pagine del Terzo Quaderno, Smirnov non riesce a rimanere un impassibile censore burocratico. Quale contrasto si manifesta nell'inquirente tra il dovere d'ufficio verso il partito e la commozione di fronte al coraggio dei giovani Danilov?

---

## 3. Officina di Scrittura Creativa ed Empatia
*Svolgi la seguente attività di scrittura sul tuo quaderno.*

Immagina di essere **Boris** nel fienile diroccato vicino al fiume, subito dopo il terrificante bombardamento della chiesa. Hai protetto Nadya facendola scendere dalla libreria e hai tratto in salvo i quaderni rossi dalle macerie. Fuori la notte brucia e si odono le raffiche dei Panzer. Scrivi sul tuo quaderno una pagina di riflessione in prima persona: racconta cosa provi a essere diventato lo scudo protettivo dei tuoi compagni, tu che a scuola eri considerato da tutti un ragazzo lento e solitario.

---

## 4. Laboratorio Lessicale e Modi di Dire
*Associa ciascun vocabolo o espressione d'autore al suo significato nel contesto del racconto (indica sul quaderno la combinazione corretta numero-lettera).*

| Termine o Modo di Dire | Abbinamento | Significato Contestuale |
| :--- | :---: | :--- |
| 1. **Panzer** | [   ] | A. Condizione di blocco militare totale in cui una roccaforte viene isolata per fame e bombardamenti. |
| 2. **Retrovie** | [   ] | B. Mezzo corazzato d'assalto pesante dell'esercito tedesco, temuto per la sua corazza e bocca da fuoco. |
| 3. **Assedio** | [   ] | C. Operazione metodica casa per casa compiuta da soldati nemici per catturare o eliminare partigiani. |
| 4. **Ospedale da campo** | [   ] | D. Zona situata alle spalle della prima linea del fronte, adibita al coordinamento e all'alloggio logistico. |
| 5. **Rastrellamento** | [   ] | E. Presidio medico di emergenza allestito in tende o edifici civili a ridosso del fronte per i militari feriti. |

---

## 5. Attività Speciale "Fuori dagli Schemi"

**Mappa Topografica o Tattica: La Caduta di Shlisselburg e la Chiusura dell'Anello**  
Nel Blocco 7 la geografia di guerra decide il destino di milioni di persone: l'occupazione di Mga e l'assalto a Shlisselburg sigillano la morsa attorno a Leningrado.  
Disegna sul tuo quaderno una **Mappa Strategica dell'Area del Basso Ladoga**:
1. Traccia il profilo meridionale del **Lago Ladoga** e l'uscita del fiume **Neva** che scorre verso Leningrado.
2. Posiziona il nodo ferroviario di **Mga**, il villaggio di **Shlisselburg** e l'isolotto della fortezza di **Oreshek**.
3. Indica con frecce l'avanzata delle divisioni corazzate tedesche e cerchia i punti nevralgici: la chiesa di San Nicola bombardata, la cattedrale-ospedale e il fienile rifugio dei ventiquattro superstiti. Aggiungi una legenda chiara.

---

### GUIDA E RIASSUNTO PER IL DOCENTE

#### Riassunto sintetico dei capitoli
- **Capitolo 20 (20–25 agosto 1941 - Nadya):** Nadya deduce che Viktor, saputo del trafiletto sul treno 76, non accetterà mai la sua morte e verrà a cercarla. A Shlisselburg comincia l'evacuazione civile; la notte del 25 agosto le bombe colpiscono la periferia di Leningrado. Dalla sommità della chiesa Nadya osserva i bagliori del fronte.
- **Capitolo 21 (26–27 agosto 1941):** I fanti della 48ª Armata allestiscono il quartier generale e l'ospedale nella cattedrale. Nadya funge da "infermierina" medicando i feriti, mentre un tenente le illustra sulle carte l'imminente chiusura della sacca di Leningrado da parte delle divisioni corazzate naziste.
- **Capitolo 22 (Viktor):** Viktor rievoca parallelamente la fuga da Kazan con Klara, Lev, Flavio e Mikhail, la sosta caotica a Mosca e il tragico equivoco ferroviario che li catapulta come forzati nel Gulag di Rybinsk, da cui riescono a evadere nella notte scavando un tunnel e rifugiandosi nelle latrine per sviare i segugi dell'NKVD.
- **Capitolo 23 (7–9 settembre 1941 - Nadya) e Rapporto NKVD:** I bombardieri tedeschi sventrano la sagrestia di San Nicola; Nadya, Boris, Anna e Lilya si salvano per miracolo nell'ufficio parrocchiale. Il villaggio cade sotto i rastrellamenti nazisti. Nadya e i sopravvissuti riparano in un fienile semidiroccato: lì compila la lista dei 24 scampati, giurando fiducia in Viktor. Smirnov chiude il Terzo Quaderno riconoscendo la tragica grandezza delle memorie ma rimandando il verdetto.

#### Soluzioni ed elementi chiave di correzione
- **1.A Domande aperte:**
  1. *La deduzione di Nadya:* Sa che Viktor conosce il numero del treno (76); credendo nella sintonia fraterna, sa che il gemello considererà falsa la notizia ufficiale e si metterà sulle sue tracce.
  2. *L'ospedale nella cattedrale:* Nadya distribuisce disinfettante, lava le bende e conforta i moribondi; l'ufficiale le mostra che la caduta di Shlisselburg isolerà per terra e per fiume l'intera Leningrado.
  3. *L'attacco su San Nicola:* Si salvano perché Boris e Nadya erano saliti sulla libreria dell'ufficio parrocchiale; uscendo trovano macerie, polvere soffocante e soldati feriti straziati dal crollo.
  4. *L'appello dei ventiquattro:* Registra i nomi dei superstiti affinché rimanga memoria scritta della loro esistenza qualora venissero uccisi dalle pattuglie naziste.
  5. *Il dilemma di Smirnov:* L'inquirente è toccato dalla dignità e dalla purezza testimoniale del diario; i timbri sulla scrivania rappresentano l'arbitrio di un potere che schiaccia l'eroismo sotto il formalismo burocratico.
- **1.B Vero o Falso:**
  1. **VERO.** Dalla sommità della chiesa scorge il cielo notturno incendiato dai cannoni nemici.
  2. **FALSO.** La guarnigione sovietica oppone una resistenza disperata soccorrendo i feriti nella cattedrale.
  3. **VERO.** La posizione sopraelevata nell'ufficio del pope li ripara dal crollo diretto della volta.
  4. **FALSO.** Irina e il bambino vengono investiti da un'esplosione durante la fuga lungo la riva.
  5. **VERO.** Nadya chiude il terzo quaderno ribadendo la certezza incrollabile nel ricongiungimento.
- **2. Analisi dei Personaggi:**
  1. *Maturazione di Nadya:* Supera la dimensione dell'infanzia protetta per assumere una funzione di conforto e testimonianza storica attiva; la cura dei feriti ne sublima il coraggio.
  2. *Dilemma di Smirnov:* La freddezza dell'apparato poliziesco entra in conflitto con la coscienza dell'uomo; l'eroismo dei Danilov rende assurda qualsiasi imputazione di reato.
- **3. Officina di Scrittura:** Verificare la resa introspettiva di Boris: senso di protezione paterna, orgoglio per aver salvato i compagni e consapevolezza della tragedia circostante.
- **4. Laboratorio Lessicale:** Combinazione corretta: `1-B, 2-D, 3-A, 4-E, 5-C`.
- **5. Attività Speciale:** Valutare la correttezza topografica (Ladoga, Neva, Mga, Shlisselburg) e la precisione nel visualizzare la manovra a tenaglia delle forze d'invasione.
